SPACE MINER: BUILD & CONQUER
Version 1.0.0 - Windows 64-bit

HOW TO PLAY
-----------
1. Keep every file in this folder together (SpaceMiner.exe needs the "game" folder).
2. Double-click SpaceMiner.exe.
3. The game opens in its own window. Close the window to quit.

The launcher starts a private runtime on 127.0.0.1 (your machine only) and renders the
game with hardware-accelerated WebGL through the Chromium engine already installed with
Windows (Microsoft Edge). If no Chromium-family browser is found, your default browser
is used instead.

CONTROLS
--------
HANGAR        Drag to orbit the camera, mouse wheel to zoom, click a station terminal.
SHIP BUILDER  Pick a module from the inventory, R rotates it, click a cell to place it.
              Click an installed module to remove it. Buy expansion cells to grow the grid.
EXPEDITION    W / S            thrust forward and reverse
              A / D            strafe
              Space / C        rise and descend
              Q / E            roll
              X                brake (inertial dampeners)
              Shift            boost
              Mouse            steer
              Left mouse       fire weapons
              Right mouse      fire mining lasers
              Esc              return to the hangar

PROGRESSION
-----------
- Every 10 purchased ship expansion cells unlock exactly 1 crew slot.
- Crystals come from achievements; spend them on crew card packs (3 cards per pack).
- Active upgrades: 3 slots by default, a 4th can be purchased, a 5th drops at 1 percent
  per completed expedition (maximum 5).
- Progress saves automatically and can be exported/reset from the Settings panel.

REQUIREMENTS
------------
Windows 10 or 11 (64-bit), a GPU with WebGL 2 support, 400 MB free disk space.

LICENSE
-------
MIT. See LICENSE.txt. Third-party notice: three.js (MIT), (c) 2010-2024 three.js authors.
