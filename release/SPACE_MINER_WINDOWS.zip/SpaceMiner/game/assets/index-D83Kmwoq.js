(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Sr="160",Ah=0,yo=1,Ch=2,vc=1,yc=2,Ln=3,qn=0,qt=1,Xt=2,Vn=0,ai=1,un=2,_o=3,Mo=4,Rh=5,ii=100,Ph=101,Lh=102,So=103,xo=104,Ih=200,Dh=201,Uh=202,Nh=203,wa=204,Ta=205,Oh=206,Fh=207,kh=208,Bh=209,zh=210,Gh=211,Hh=212,Vh=213,Wh=214,Xh=0,$h=1,qh=2,ar=3,Yh=4,jh=5,Kh=6,Jh=7,_c=0,Zh=1,Qh=2,Wn=0,eu=1,tu=2,nu=3,Mc=4,iu=5,su=6,Sc=300,Gi=301,Hi=302,or=303,Aa=304,xr=306,lr=1e3,ln=1001,Ca=1002,Vt=1003,bo=1004,Or=1005,on=1006,ru=1007,ps=1008,Xn=1009,au=1010,ou=1011,$a=1012,xc=1013,zn=1014,Gn=1015,ms=1016,bc=1017,Ec=1018,oi=1020,lu=1021,vn=1023,cu=1024,hu=1025,li=1026,Vi=1027,uu=1028,wc=1029,du=1030,Tc=1031,Ac=1033,Fr=33776,kr=33777,Br=33778,zr=33779,Eo=35840,wo=35841,To=35842,Ao=35843,Cc=36196,Co=37492,Ro=37496,Po=37808,Lo=37809,Io=37810,Do=37811,Uo=37812,No=37813,Oo=37814,Fo=37815,ko=37816,Bo=37817,zo=37818,Go=37819,Ho=37820,Vo=37821,Gr=36492,Wo=36494,Xo=36495,fu=36283,$o=36284,qo=36285,Yo=36286,Rc=3e3,ci=3001,pu=3200,mu=3201,Pc=0,gu=1,cn="",dt="srgb",Un="srgb-linear",qa="display-p3",br="display-p3-linear",cr="linear",lt="srgb",hr="rec709",ur="p3",yi=7680,jo=519,vu=512,yu=513,_u=514,Lc=515,Mu=516,Su=517,xu=518,bu=519,Ko=35044,Jo="300 es",Ra=1035,Dn=2e3,dr=2001;class ji{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const s=this._listeners[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const s=i.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,e);e.target=null}}}const Ut=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Zo=1234567;const as=Math.PI/180,Wi=180/Math.PI;function vi(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Ut[n&255]+Ut[n>>8&255]+Ut[n>>16&255]+Ut[n>>24&255]+"-"+Ut[e&255]+Ut[e>>8&255]+"-"+Ut[e>>16&15|64]+Ut[e>>24&255]+"-"+Ut[t&63|128]+Ut[t>>8&255]+"-"+Ut[t>>16&255]+Ut[t>>24&255]+Ut[i&255]+Ut[i>>8&255]+Ut[i>>16&255]+Ut[i>>24&255]).toLowerCase()}function Et(n,e,t){return Math.max(e,Math.min(t,n))}function Ya(n,e){return(n%e+e)%e}function Eu(n,e,t,i,s){return i+(n-e)*(s-i)/(t-e)}function wu(n,e,t){return n!==e?(t-n)/(e-n):0}function os(n,e,t){return(1-t)*n+t*e}function Tu(n,e,t,i){return os(n,e,1-Math.exp(-t*i))}function Au(n,e=1){return e-Math.abs(Ya(n,e*2)-e)}function Cu(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*(3-2*n))}function Ru(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*n*(n*(n*6-15)+10))}function Pu(n,e){return n+Math.floor(Math.random()*(e-n+1))}function Lu(n,e){return n+Math.random()*(e-n)}function Iu(n){return n*(.5-Math.random())}function Du(n){n!==void 0&&(Zo=n);let e=Zo+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Uu(n){return n*as}function Nu(n){return n*Wi}function Pa(n){return(n&n-1)===0&&n!==0}function Ou(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function fr(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function Fu(n,e,t,i,s){const r=Math.cos,a=Math.sin,o=r(t/2),l=a(t/2),c=r((e+i)/2),h=a((e+i)/2),u=r((e-i)/2),d=a((e-i)/2),f=r((i-e)/2),g=a((i-e)/2);switch(s){case"XYX":n.set(o*h,l*u,l*d,o*c);break;case"YZY":n.set(l*d,o*h,l*u,o*c);break;case"ZXZ":n.set(l*u,l*d,o*h,o*c);break;case"XZX":n.set(o*h,l*g,l*f,o*c);break;case"YXY":n.set(l*f,o*h,l*g,o*c);break;case"ZYZ":n.set(l*g,l*f,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Oi(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function zt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}const tn={DEG2RAD:as,RAD2DEG:Wi,generateUUID:vi,clamp:Et,euclideanModulo:Ya,mapLinear:Eu,inverseLerp:wu,lerp:os,damp:Tu,pingpong:Au,smoothstep:Cu,smootherstep:Ru,randInt:Pu,randFloat:Lu,randFloatSpread:Iu,seededRandom:Du,degToRad:Uu,radToDeg:Nu,isPowerOfTwo:Pa,ceilPowerOfTwo:Ou,floorPowerOfTwo:fr,setQuaternionFromProperEuler:Fu,normalize:zt,denormalize:Oi};class ue{constructor(e=0,t=0){ue.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6],this.y=s[1]*t+s[4]*i+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Et(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),s=Math.sin(t),r=this.x-e.x,a=this.y-e.y;return this.x=r*i-a*s+e.x,this.y=r*s+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class je{constructor(e,t,i,s,r,a,o,l,c){je.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,a,o,l,c)}set(e,t,i,s,r,a,o,l,c){const h=this.elements;return h[0]=e,h[1]=s,h[2]=o,h[3]=t,h[4]=r,h[5]=l,h[6]=i,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,a=i[0],o=i[3],l=i[6],c=i[1],h=i[4],u=i[7],d=i[2],f=i[5],g=i[8],v=s[0],p=s[3],m=s[6],M=s[1],_=s[4],x=s[7],P=s[2],w=s[5],A=s[8];return r[0]=a*v+o*M+l*P,r[3]=a*p+o*_+l*w,r[6]=a*m+o*x+l*A,r[1]=c*v+h*M+u*P,r[4]=c*p+h*_+u*w,r[7]=c*m+h*x+u*A,r[2]=d*v+f*M+g*P,r[5]=d*p+f*_+g*w,r[8]=d*m+f*x+g*A,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8];return t*a*h-t*o*c-i*r*h+i*o*l+s*r*c-s*a*l}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=h*a-o*c,d=o*l-h*r,f=c*r-a*l,g=t*u+i*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=u*v,e[1]=(s*c-h*i)*v,e[2]=(o*i-s*a)*v,e[3]=d*v,e[4]=(h*t-s*l)*v,e[5]=(s*r-o*t)*v,e[6]=f*v,e[7]=(i*l-c*t)*v,e[8]=(a*t-i*r)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,s,r,a,o){const l=Math.cos(r),c=Math.sin(r);return this.set(i*l,i*c,-i*(l*a+c*o)+a+e,-s*c,s*l,-s*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Hr.makeScale(e,t)),this}rotate(e){return this.premultiply(Hr.makeRotation(-e)),this}translate(e,t){return this.premultiply(Hr.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<9;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Hr=new je;function Ic(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function pr(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function ku(){const n=pr("canvas");return n.style.display="block",n}const Qo={};function ls(n){n in Qo||(Qo[n]=!0,console.warn(n))}const el=new je().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),tl=new je().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),As={[Un]:{transfer:cr,primaries:hr,toReference:n=>n,fromReference:n=>n},[dt]:{transfer:lt,primaries:hr,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[br]:{transfer:cr,primaries:ur,toReference:n=>n.applyMatrix3(tl),fromReference:n=>n.applyMatrix3(el)},[qa]:{transfer:lt,primaries:ur,toReference:n=>n.convertSRGBToLinear().applyMatrix3(tl),fromReference:n=>n.applyMatrix3(el).convertLinearToSRGB()}},Bu=new Set([Un,br]),nt={enabled:!0,_workingColorSpace:Un,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!Bu.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,e,t){if(this.enabled===!1||e===t||!e||!t)return n;const i=As[e].toReference,s=As[t].fromReference;return s(i(n))},fromWorkingColorSpace:function(n,e){return this.convert(n,this._workingColorSpace,e)},toWorkingColorSpace:function(n,e){return this.convert(n,e,this._workingColorSpace)},getPrimaries:function(n){return As[n].primaries},getTransfer:function(n){return n===cn?cr:As[n].transfer}};function zi(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Vr(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let _i;class Dc{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{_i===void 0&&(_i=pr("canvas")),_i.width=e.width,_i.height=e.height;const i=_i.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=_i}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=pr("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const s=i.getImageData(0,0,e.width,e.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=zi(r[a]/255)*255;return i.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(zi(t[i]/255)*255):t[i]=zi(t[i]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let zu=0;class Uc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:zu++}),this.uuid=vi(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Wr(s[a].image)):r.push(Wr(s[a]))}else r=Wr(s);i.url=r}return t||(e.images[this.uuid]=i),i}}function Wr(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?Dc.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Gu=0;class Kt extends ji{constructor(e=Kt.DEFAULT_IMAGE,t=Kt.DEFAULT_MAPPING,i=ln,s=ln,r=on,a=ps,o=vn,l=Xn,c=Kt.DEFAULT_ANISOTROPY,h=cn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Gu++}),this.uuid=vi(),this.name="",this.source=new Uc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new ue(0,0),this.repeat=new ue(1,1),this.center=new ue(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new je,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(ls("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===ci?dt:cn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Sc)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case lr:e.x=e.x-Math.floor(e.x);break;case ln:e.x=e.x<0?0:1;break;case Ca:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case lr:e.y=e.y-Math.floor(e.y);break;case ln:e.y=e.y<0?0:1;break;case Ca:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return ls("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===dt?ci:Rc}set encoding(e){ls("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===ci?dt:cn}}Kt.DEFAULT_IMAGE=null;Kt.DEFAULT_MAPPING=Sc;Kt.DEFAULT_ANISOTROPY=1;class ct{constructor(e=0,t=0,i=0,s=1){ct.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,s){return this.x=e,this.y=t,this.z=i,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*s+a[12]*r,this.y=a[1]*t+a[5]*i+a[9]*s+a[13]*r,this.z=a[2]*t+a[6]*i+a[10]*s+a[14]*r,this.w=a[3]*t+a[7]*i+a[11]*s+a[15]*r,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,s,r;const l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],v=l[2],p=l[6],m=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-v)<.01&&Math.abs(g-p)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+v)<.1&&Math.abs(g+p)<.1&&Math.abs(c+f+m-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const _=(c+1)/2,x=(f+1)/2,P=(m+1)/2,w=(h+d)/4,A=(u+v)/4,N=(g+p)/4;return _>x&&_>P?_<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(_),s=w/i,r=A/i):x>P?x<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(x),i=w/s,r=N/s):P<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(P),i=A/r,s=N/r),this.set(i,s,r,t),this}let M=Math.sqrt((p-g)*(p-g)+(u-v)*(u-v)+(d-h)*(d-h));return Math.abs(M)<.001&&(M=1),this.x=(p-g)/M,this.y=(u-v)/M,this.z=(d-h)/M,this.w=Math.acos((c+f+m-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Hu extends ji{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new ct(0,0,e,t),this.scissorTest=!1,this.viewport=new ct(0,0,e,t);const s={width:e,height:t,depth:1};i.encoding!==void 0&&(ls("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===ci?dt:cn),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:on,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Kt(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){(this.width!==e||this.height!==t||this.depth!==i)&&(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new Uc(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class di extends Hu{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class Nc extends Kt{constructor(e=null,t=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=Vt,this.minFilter=Vt,this.wrapR=ln,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Vu extends Kt{constructor(e=null,t=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=Vt,this.minFilter=Vt,this.wrapR=ln,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class xn{constructor(e=0,t=0,i=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=s}static slerpFlat(e,t,i,s,r,a,o){let l=i[s+0],c=i[s+1],h=i[s+2],u=i[s+3];const d=r[a+0],f=r[a+1],g=r[a+2],v=r[a+3];if(o===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(o===1){e[t+0]=d,e[t+1]=f,e[t+2]=g,e[t+3]=v;return}if(u!==v||l!==d||c!==f||h!==g){let p=1-o;const m=l*d+c*f+h*g+u*v,M=m>=0?1:-1,_=1-m*m;if(_>Number.EPSILON){const P=Math.sqrt(_),w=Math.atan2(P,m*M);p=Math.sin(p*w)/P,o=Math.sin(o*w)/P}const x=o*M;if(l=l*p+d*x,c=c*p+f*x,h=h*p+g*x,u=u*p+v*x,p===1-o){const P=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=P,c*=P,h*=P,u*=P}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,i,s,r,a){const o=i[s],l=i[s+1],c=i[s+2],h=i[s+3],u=r[a],d=r[a+1],f=r[a+2],g=r[a+3];return e[t]=o*g+h*u+l*f-c*d,e[t+1]=l*g+h*d+c*u-o*f,e[t+2]=c*g+h*f+o*d-l*u,e[t+3]=h*g-o*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,s){return this._x=e,this._y=t,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,s=e._y,r=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(i/2),h=o(s/2),u=o(r/2),d=l(i/2),f=l(s/2),g=l(r/2);switch(a){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,s=Math.sin(i);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],s=t[4],r=t[8],a=t[1],o=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=i+o+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(a-s)*f}else if(i>o&&i>u){const f=2*Math.sqrt(1+i-o-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+a)/f,this._z=(r+c)/f}else if(o>u){const f=2*Math.sqrt(1+o-i-u);this._w=(r-c)/f,this._x=(s+a)/f,this._y=.25*f,this._z=(l+h)/f}else{const f=2*Math.sqrt(1+u-i-o);this._w=(a-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Et(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const s=Math.min(1,t/i);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,s=e._y,r=e._z,a=e._w,o=t._x,l=t._y,c=t._z,h=t._w;return this._x=i*h+a*o+s*c-r*l,this._y=s*h+a*l+r*o-i*c,this._z=r*h+a*c+i*l-s*o,this._w=a*h-i*o-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const i=this._x,s=this._y,r=this._z,a=this._w;let o=a*e._w+i*e._x+s*e._y+r*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=s,this._z=r,this;const l=1-o*o;if(l<=Number.EPSILON){const f=1-t;return this._w=f*a+t*this._w,this._x=f*i+t*this._x,this._y=f*s+t*this._y,this._z=f*r+t*this._z,this.normalize(),this}const c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=a*u+this._w*d,this._x=i*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(t*Math.cos(s),i*Math.sin(r),i*Math.cos(r),t*Math.sin(s))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class R{constructor(e=0,t=0,i=0){R.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(nl.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(nl.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6]*s,this.y=r[1]*t+r[4]*i+r[7]*s,this.z=r[2]*t+r[5]*i+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=e.elements,a=1/(r[3]*t+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*i+r[8]*s+r[12])*a,this.y=(r[1]*t+r[5]*i+r[9]*s+r[13])*a,this.z=(r[2]*t+r[6]*i+r[10]*s+r[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,s=this.z,r=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*s-o*i),h=2*(o*t-r*s),u=2*(r*i-a*t);return this.x=t+l*c+a*u-o*h,this.y=i+l*h+o*c-r*u,this.z=s+l*u+r*h-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*i+r[8]*s,this.y=r[1]*t+r[5]*i+r[9]*s,this.z=r[2]*t+r[6]*i+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,s=e.y,r=e.z,a=t.x,o=t.y,l=t.z;return this.x=s*l-r*o,this.y=r*a-i*l,this.z=i*o-s*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Xr.copy(this).projectOnVector(e),this.sub(Xr)}reflect(e){return this.sub(Xr.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Et(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,s=this.z-e.z;return t*t+i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const s=Math.sin(t)*e;return this.x=s*Math.sin(i),this.y=Math.cos(t)*e,this.z=s*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Xr=new R,nl=new xn;class Ms{constructor(e=new R(1/0,1/0,1/0),t=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(fn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(fn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=fn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const r=i.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,fn):fn.fromBufferAttribute(r,a),fn.applyMatrix4(e.matrixWorld),this.expandByPoint(fn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Cs.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Cs.copy(i.boundingBox)),Cs.applyMatrix4(e.matrixWorld),this.union(Cs)}const s=e.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,fn),fn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Qi),Rs.subVectors(this.max,Qi),Mi.subVectors(e.a,Qi),Si.subVectors(e.b,Qi),xi.subVectors(e.c,Qi),Nn.subVectors(Si,Mi),On.subVectors(xi,Si),Kn.subVectors(Mi,xi);let t=[0,-Nn.z,Nn.y,0,-On.z,On.y,0,-Kn.z,Kn.y,Nn.z,0,-Nn.x,On.z,0,-On.x,Kn.z,0,-Kn.x,-Nn.y,Nn.x,0,-On.y,On.x,0,-Kn.y,Kn.x,0];return!$r(t,Mi,Si,xi,Rs)||(t=[1,0,0,0,1,0,0,0,1],!$r(t,Mi,Si,xi,Rs))?!1:(Ps.crossVectors(Nn,On),t=[Ps.x,Ps.y,Ps.z],$r(t,Mi,Si,xi,Rs))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,fn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(fn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Tn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Tn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Tn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Tn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Tn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Tn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Tn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Tn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Tn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const Tn=[new R,new R,new R,new R,new R,new R,new R,new R],fn=new R,Cs=new Ms,Mi=new R,Si=new R,xi=new R,Nn=new R,On=new R,Kn=new R,Qi=new R,Rs=new R,Ps=new R,Jn=new R;function $r(n,e,t,i,s){for(let r=0,a=n.length-3;r<=a;r+=3){Jn.fromArray(n,r);const o=s.x*Math.abs(Jn.x)+s.y*Math.abs(Jn.y)+s.z*Math.abs(Jn.z),l=e.dot(Jn),c=t.dot(Jn),h=i.dot(Jn);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}const Wu=new Ms,es=new R,qr=new R;class Ss{constructor(e=new R,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):Wu.setFromPoints(e).getCenter(i);let s=0;for(let r=0,a=e.length;r<a;r++)s=Math.max(s,i.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;es.subVectors(e,this.center);const t=es.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),s=(i-this.radius)*.5;this.center.addScaledVector(es,s/i),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(qr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(es.copy(e.center).add(qr)),this.expandByPoint(es.copy(e.center).sub(qr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const An=new R,Yr=new R,Ls=new R,Fn=new R,jr=new R,Is=new R,Kr=new R;class ja{constructor(e=new R,t=new R(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,An)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=An.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(An.copy(this.origin).addScaledVector(this.direction,t),An.distanceToSquared(e))}distanceSqToSegment(e,t,i,s){Yr.copy(e).add(t).multiplyScalar(.5),Ls.copy(t).sub(e).normalize(),Fn.copy(this.origin).sub(Yr);const r=e.distanceTo(t)*.5,a=-this.direction.dot(Ls),o=Fn.dot(this.direction),l=-Fn.dot(Ls),c=Fn.lengthSq(),h=Math.abs(1-a*a);let u,d,f,g;if(h>0)if(u=a*l-o,d=a*o-l,g=r*h,u>=0)if(d>=-g)if(d<=g){const v=1/h;u*=v,d*=v,f=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-a*r+o)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(a*r+o)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=a>0?-r:r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Yr).addScaledVector(Ls,d),f}intersectSphere(e,t){An.subVectors(e.center,this.origin);const i=An.dot(this.direction),s=An.dot(An)-i*i,r=e.radius*e.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=i-a,l=i+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,s,r,a,o,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(i=(e.min.x-d.x)*c,s=(e.max.x-d.x)*c):(i=(e.max.x-d.x)*c,s=(e.min.x-d.x)*c),h>=0?(r=(e.min.y-d.y)*h,a=(e.max.y-d.y)*h):(r=(e.max.y-d.y)*h,a=(e.min.y-d.y)*h),i>a||r>s||((r>i||isNaN(i))&&(i=r),(a<s||isNaN(s))&&(s=a),u>=0?(o=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),i>l||o>s)||((o>i||i!==i)&&(i=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(i>=0?i:s,t)}intersectsBox(e){return this.intersectBox(e,An)!==null}intersectTriangle(e,t,i,s,r){jr.subVectors(t,e),Is.subVectors(i,e),Kr.crossVectors(jr,Is);let a=this.direction.dot(Kr),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Fn.subVectors(this.origin,e);const l=o*this.direction.dot(Is.crossVectors(Fn,Is));if(l<0)return null;const c=o*this.direction.dot(jr.cross(Fn));if(c<0||l+c>a)return null;const h=-o*Fn.dot(Kr);return h<0?null:this.at(h/a,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class pt{constructor(e,t,i,s,r,a,o,l,c,h,u,d,f,g,v,p){pt.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,a,o,l,c,h,u,d,f,g,v,p)}set(e,t,i,s,r,a,o,l,c,h,u,d,f,g,v,p){const m=this.elements;return m[0]=e,m[4]=t,m[8]=i,m[12]=s,m[1]=r,m[5]=a,m[9]=o,m[13]=l,m[2]=c,m[6]=h,m[10]=u,m[14]=d,m[3]=f,m[7]=g,m[11]=v,m[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new pt().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,s=1/bi.setFromMatrixColumn(e,0).length(),r=1/bi.setFromMatrixColumn(e,1).length(),a=1/bi.setFromMatrixColumn(e,2).length();return t[0]=i[0]*s,t[1]=i[1]*s,t[2]=i[2]*s,t[3]=0,t[4]=i[4]*r,t[5]=i[5]*r,t[6]=i[6]*r,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,s=e.y,r=e.z,a=Math.cos(i),o=Math.sin(i),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(e.order==="XYZ"){const d=a*h,f=a*u,g=o*h,v=o*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+g*c,t[5]=d-v*c,t[9]=-o*l,t[2]=v-d*c,t[6]=g+f*c,t[10]=a*l}else if(e.order==="YXZ"){const d=l*h,f=l*u,g=c*h,v=c*u;t[0]=d+v*o,t[4]=g*o-f,t[8]=a*c,t[1]=a*u,t[5]=a*h,t[9]=-o,t[2]=f*o-g,t[6]=v+d*o,t[10]=a*l}else if(e.order==="ZXY"){const d=l*h,f=l*u,g=c*h,v=c*u;t[0]=d-v*o,t[4]=-a*u,t[8]=g+f*o,t[1]=f+g*o,t[5]=a*h,t[9]=v-d*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const d=a*h,f=a*u,g=o*h,v=o*u;t[0]=l*h,t[4]=g*c-f,t[8]=d*c+v,t[1]=l*u,t[5]=v*c+d,t[9]=f*c-g,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const d=a*l,f=a*c,g=o*l,v=o*c;t[0]=l*h,t[4]=v-d*u,t[8]=g*u+f,t[1]=u,t[5]=a*h,t[9]=-o*h,t[2]=-c*h,t[6]=f*u+g,t[10]=d-v*u}else if(e.order==="XZY"){const d=a*l,f=a*c,g=o*l,v=o*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+v,t[5]=a*h,t[9]=f*u-g,t[2]=g*u-f,t[6]=o*h,t[10]=v*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Xu,e,$u)}lookAt(e,t,i){const s=this.elements;return Zt.subVectors(e,t),Zt.lengthSq()===0&&(Zt.z=1),Zt.normalize(),kn.crossVectors(i,Zt),kn.lengthSq()===0&&(Math.abs(i.z)===1?Zt.x+=1e-4:Zt.z+=1e-4,Zt.normalize(),kn.crossVectors(i,Zt)),kn.normalize(),Ds.crossVectors(Zt,kn),s[0]=kn.x,s[4]=Ds.x,s[8]=Zt.x,s[1]=kn.y,s[5]=Ds.y,s[9]=Zt.y,s[2]=kn.z,s[6]=Ds.z,s[10]=Zt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,a=i[0],o=i[4],l=i[8],c=i[12],h=i[1],u=i[5],d=i[9],f=i[13],g=i[2],v=i[6],p=i[10],m=i[14],M=i[3],_=i[7],x=i[11],P=i[15],w=s[0],A=s[4],N=s[8],y=s[12],S=s[1],D=s[5],F=s[9],X=s[13],L=s[2],B=s[6],H=s[10],Z=s[14],J=s[3],j=s[7],ee=s[11],le=s[15];return r[0]=a*w+o*S+l*L+c*J,r[4]=a*A+o*D+l*B+c*j,r[8]=a*N+o*F+l*H+c*ee,r[12]=a*y+o*X+l*Z+c*le,r[1]=h*w+u*S+d*L+f*J,r[5]=h*A+u*D+d*B+f*j,r[9]=h*N+u*F+d*H+f*ee,r[13]=h*y+u*X+d*Z+f*le,r[2]=g*w+v*S+p*L+m*J,r[6]=g*A+v*D+p*B+m*j,r[10]=g*N+v*F+p*H+m*ee,r[14]=g*y+v*X+p*Z+m*le,r[3]=M*w+_*S+x*L+P*J,r[7]=M*A+_*D+x*B+P*j,r[11]=M*N+_*F+x*H+P*ee,r[15]=M*y+_*X+x*Z+P*le,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],s=e[8],r=e[12],a=e[1],o=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],g=e[3],v=e[7],p=e[11],m=e[15];return g*(+r*l*u-s*c*u-r*o*d+i*c*d+s*o*f-i*l*f)+v*(+t*l*f-t*c*d+r*a*d-s*a*f+s*c*h-r*l*h)+p*(+t*c*u-t*o*f-r*a*u+i*a*f+r*o*h-i*c*h)+m*(-s*o*h-t*l*u+t*o*d+s*a*u-i*a*d+i*l*h)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],g=e[12],v=e[13],p=e[14],m=e[15],M=u*p*c-v*d*c+v*l*f-o*p*f-u*l*m+o*d*m,_=g*d*c-h*p*c-g*l*f+a*p*f+h*l*m-a*d*m,x=h*v*c-g*u*c+g*o*f-a*v*f-h*o*m+a*u*m,P=g*u*l-h*v*l-g*o*d+a*v*d+h*o*p-a*u*p,w=t*M+i*_+s*x+r*P;if(w===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/w;return e[0]=M*A,e[1]=(v*d*r-u*p*r-v*s*f+i*p*f+u*s*m-i*d*m)*A,e[2]=(o*p*r-v*l*r+v*s*c-i*p*c-o*s*m+i*l*m)*A,e[3]=(u*l*r-o*d*r-u*s*c+i*d*c+o*s*f-i*l*f)*A,e[4]=_*A,e[5]=(h*p*r-g*d*r+g*s*f-t*p*f-h*s*m+t*d*m)*A,e[6]=(g*l*r-a*p*r-g*s*c+t*p*c+a*s*m-t*l*m)*A,e[7]=(a*d*r-h*l*r+h*s*c-t*d*c-a*s*f+t*l*f)*A,e[8]=x*A,e[9]=(g*u*r-h*v*r-g*i*f+t*v*f+h*i*m-t*u*m)*A,e[10]=(a*v*r-g*o*r+g*i*c-t*v*c-a*i*m+t*o*m)*A,e[11]=(h*o*r-a*u*r-h*i*c+t*u*c+a*i*f-t*o*f)*A,e[12]=P*A,e[13]=(h*v*s-g*u*s+g*i*d-t*v*d-h*i*p+t*u*p)*A,e[14]=(g*o*s-a*v*s-g*i*l+t*v*l+a*i*p-t*o*p)*A,e[15]=(a*u*s-h*o*s+h*i*l-t*u*l-a*i*d+t*o*d)*A,this}scale(e){const t=this.elements,i=e.x,s=e.y,r=e.z;return t[0]*=i,t[4]*=s,t[8]*=r,t[1]*=i,t[5]*=s,t[9]*=r,t[2]*=i,t[6]*=s,t[10]*=r,t[3]*=i,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,s))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),s=Math.sin(t),r=1-i,a=e.x,o=e.y,l=e.z,c=r*a,h=r*o;return this.set(c*a+i,c*o-s*l,c*l+s*o,0,c*o+s*l,h*o+i,h*l-s*a,0,c*l-s*o,h*l+s*a,r*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,s,r,a){return this.set(1,i,r,0,e,1,a,0,t,s,1,0,0,0,0,1),this}compose(e,t,i){const s=this.elements,r=t._x,a=t._y,o=t._z,l=t._w,c=r+r,h=a+a,u=o+o,d=r*c,f=r*h,g=r*u,v=a*h,p=a*u,m=o*u,M=l*c,_=l*h,x=l*u,P=i.x,w=i.y,A=i.z;return s[0]=(1-(v+m))*P,s[1]=(f+x)*P,s[2]=(g-_)*P,s[3]=0,s[4]=(f-x)*w,s[5]=(1-(d+m))*w,s[6]=(p+M)*w,s[7]=0,s[8]=(g+_)*A,s[9]=(p-M)*A,s[10]=(1-(d+v))*A,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,i){const s=this.elements;let r=bi.set(s[0],s[1],s[2]).length();const a=bi.set(s[4],s[5],s[6]).length(),o=bi.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],pn.copy(this);const c=1/r,h=1/a,u=1/o;return pn.elements[0]*=c,pn.elements[1]*=c,pn.elements[2]*=c,pn.elements[4]*=h,pn.elements[5]*=h,pn.elements[6]*=h,pn.elements[8]*=u,pn.elements[9]*=u,pn.elements[10]*=u,t.setFromRotationMatrix(pn),i.x=r,i.y=a,i.z=o,this}makePerspective(e,t,i,s,r,a,o=Dn){const l=this.elements,c=2*r/(t-e),h=2*r/(i-s),u=(t+e)/(t-e),d=(i+s)/(i-s);let f,g;if(o===Dn)f=-(a+r)/(a-r),g=-2*a*r/(a-r);else if(o===dr)f=-a/(a-r),g=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,s,r,a,o=Dn){const l=this.elements,c=1/(t-e),h=1/(i-s),u=1/(a-r),d=(t+e)*c,f=(i+s)*h;let g,v;if(o===Dn)g=(a+r)*u,v=-2*u;else if(o===dr)g=r*u,v=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=v,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<16;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const bi=new R,pn=new pt,Xu=new R(0,0,0),$u=new R(1,1,1),kn=new R,Ds=new R,Zt=new R,il=new pt,sl=new xn;class xs{constructor(e=0,t=0,i=0,s=xs.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,s=this._order){return this._x=e,this._y=t,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const s=e.elements,r=s[0],a=s[4],o=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(Et(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Et(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Et(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Et(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Et(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Et(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return il.makeRotationFromQuaternion(e),this.setFromRotationMatrix(il,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return sl.setFromEuler(this),this.setFromQuaternion(sl,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}xs.DEFAULT_ORDER="XYZ";class Ka{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let qu=0;const rl=new R,Ei=new xn,Cn=new pt,Us=new R,ts=new R,Yu=new R,ju=new xn,al=new R(1,0,0),ol=new R(0,1,0),ll=new R(0,0,1),Ku={type:"added"},Ju={type:"removed"};class _t extends ji{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:qu++}),this.uuid=vi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=_t.DEFAULT_UP.clone();const e=new R,t=new xs,i=new xn,s=new R(1,1,1);function r(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(r),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new pt},normalMatrix:{value:new je}}),this.matrix=new pt,this.matrixWorld=new pt,this.matrixAutoUpdate=_t.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=_t.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ka,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ei.setFromAxisAngle(e,t),this.quaternion.multiply(Ei),this}rotateOnWorldAxis(e,t){return Ei.setFromAxisAngle(e,t),this.quaternion.premultiply(Ei),this}rotateX(e){return this.rotateOnAxis(al,e)}rotateY(e){return this.rotateOnAxis(ol,e)}rotateZ(e){return this.rotateOnAxis(ll,e)}translateOnAxis(e,t){return rl.copy(e).applyQuaternion(this.quaternion),this.position.add(rl.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(al,e)}translateY(e){return this.translateOnAxis(ol,e)}translateZ(e){return this.translateOnAxis(ll,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Cn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Us.copy(e):Us.set(e,t,i);const s=this.parent;this.updateWorldMatrix(!0,!1),ts.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Cn.lookAt(ts,Us,this.up):Cn.lookAt(Us,ts,this.up),this.quaternion.setFromRotationMatrix(Cn),s&&(Cn.extractRotation(s.matrixWorld),Ei.setFromRotationMatrix(Cn),this.quaternion.premultiply(Ei.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(Ku)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Ju)),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Cn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Cn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Cn),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,s=this.children.length;i<s;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ts,e,Yu),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ts,ju,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,s=t.length;i<s;i++){const r=t[i];(r.matrixWorldAutoUpdate===!0||e===!0)&&r.updateMatrixWorld(e)}}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){const s=this.children;for(let r=0,a=s.length;r<a;r++){const o=s[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];r(e.shapes,u)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(e.materials,this.material[l]));s.material=o}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(r(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),h=a(e.images),u=a(e.shapes),d=a(e.skeletons),f=a(e.animations),g=a(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),d.length>0&&(i.skeletons=d),f.length>0&&(i.animations=f),g.length>0&&(i.nodes=g)}return i.object=s,i;function a(o){const l=[];for(const c in o){const h=o[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const s=e.children[i];this.add(s.clone())}return this}}_t.DEFAULT_UP=new R(0,1,0);_t.DEFAULT_MATRIX_AUTO_UPDATE=!0;_t.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const mn=new R,Rn=new R,Jr=new R,Pn=new R,wi=new R,Ti=new R,cl=new R,Zr=new R,Qr=new R,ea=new R;let Ns=!1;class gn{constructor(e=new R,t=new R,i=new R){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,s){s.subVectors(i,t),mn.subVectors(e,t),s.cross(mn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,i,s,r){mn.subVectors(s,t),Rn.subVectors(i,t),Jr.subVectors(e,t);const a=mn.dot(mn),o=mn.dot(Rn),l=mn.dot(Jr),c=Rn.dot(Rn),h=Rn.dot(Jr),u=a*c-o*o;if(u===0)return r.set(0,0,0),null;const d=1/u,f=(c*l-o*h)*d,g=(a*h-o*l)*d;return r.set(1-f-g,g,f)}static containsPoint(e,t,i,s){return this.getBarycoord(e,t,i,s,Pn)===null?!1:Pn.x>=0&&Pn.y>=0&&Pn.x+Pn.y<=1}static getUV(e,t,i,s,r,a,o,l){return Ns===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Ns=!0),this.getInterpolation(e,t,i,s,r,a,o,l)}static getInterpolation(e,t,i,s,r,a,o,l){return this.getBarycoord(e,t,i,s,Pn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Pn.x),l.addScaledVector(a,Pn.y),l.addScaledVector(o,Pn.z),l)}static isFrontFacing(e,t,i,s){return mn.subVectors(i,t),Rn.subVectors(e,t),mn.cross(Rn).dot(s)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,s){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,i,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return mn.subVectors(this.c,this.b),Rn.subVectors(this.a,this.b),mn.cross(Rn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return gn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return gn.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,s,r){return Ns===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Ns=!0),gn.getInterpolation(e,this.a,this.b,this.c,t,i,s,r)}getInterpolation(e,t,i,s,r){return gn.getInterpolation(e,this.a,this.b,this.c,t,i,s,r)}containsPoint(e){return gn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return gn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,s=this.b,r=this.c;let a,o;wi.subVectors(s,i),Ti.subVectors(r,i),Zr.subVectors(e,i);const l=wi.dot(Zr),c=Ti.dot(Zr);if(l<=0&&c<=0)return t.copy(i);Qr.subVectors(e,s);const h=wi.dot(Qr),u=Ti.dot(Qr);if(h>=0&&u<=h)return t.copy(s);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),t.copy(i).addScaledVector(wi,a);ea.subVectors(e,r);const f=wi.dot(ea),g=Ti.dot(ea);if(g>=0&&f<=g)return t.copy(r);const v=f*c-l*g;if(v<=0&&c>=0&&g<=0)return o=c/(c-g),t.copy(i).addScaledVector(Ti,o);const p=h*g-f*u;if(p<=0&&u-h>=0&&f-g>=0)return cl.subVectors(r,s),o=(u-h)/(u-h+(f-g)),t.copy(s).addScaledVector(cl,o);const m=1/(p+v+d);return a=v*m,o=d*m,t.copy(i).addScaledVector(wi,a).addScaledVector(Ti,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Oc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Bn={h:0,s:0,l:0},Os={h:0,s:0,l:0};function ta(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class Le{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=dt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,nt.toWorkingColorSpace(this,t),this}setRGB(e,t,i,s=nt.workingColorSpace){return this.r=e,this.g=t,this.b=i,nt.toWorkingColorSpace(this,s),this}setHSL(e,t,i,s=nt.workingColorSpace){if(e=Ya(e,1),t=Et(t,0,1),i=Et(i,0,1),t===0)this.r=this.g=this.b=i;else{const r=i<=.5?i*(1+t):i+t-i*t,a=2*i-r;this.r=ta(a,r,e+1/3),this.g=ta(a,r,e),this.b=ta(a,r,e-1/3)}return nt.toWorkingColorSpace(this,s),this}setStyle(e,t=dt){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=dt){const i=Oc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=zi(e.r),this.g=zi(e.g),this.b=zi(e.b),this}copyLinearToSRGB(e){return this.r=Vr(e.r),this.g=Vr(e.g),this.b=Vr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=dt){return nt.fromWorkingColorSpace(Nt.copy(this),e),Math.round(Et(Nt.r*255,0,255))*65536+Math.round(Et(Nt.g*255,0,255))*256+Math.round(Et(Nt.b*255,0,255))}getHexString(e=dt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=nt.workingColorSpace){nt.fromWorkingColorSpace(Nt.copy(this),t);const i=Nt.r,s=Nt.g,r=Nt.b,a=Math.max(i,s,r),o=Math.min(i,s,r);let l,c;const h=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case i:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-i)/u+2;break;case r:l=(i-s)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=nt.workingColorSpace){return nt.fromWorkingColorSpace(Nt.copy(this),t),e.r=Nt.r,e.g=Nt.g,e.b=Nt.b,e}getStyle(e=dt){nt.fromWorkingColorSpace(Nt.copy(this),e);const t=Nt.r,i=Nt.g,s=Nt.b;return e!==dt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(e,t,i){return this.getHSL(Bn),this.setHSL(Bn.h+e,Bn.s+t,Bn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(Bn),e.getHSL(Os);const i=os(Bn.h,Os.h,t),s=os(Bn.s,Os.s,t),r=os(Bn.l,Os.l,t);return this.setHSL(i,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*i+r[6]*s,this.g=r[1]*t+r[4]*i+r[7]*s,this.b=r[2]*t+r[5]*i+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Nt=new Le;Le.NAMES=Oc;let Zu=0;class Ki extends ji{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Zu++}),this.uuid=vi(),this.name="",this.type="Material",this.blending=ai,this.side=qn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=wa,this.blendDst=Ta,this.blendEquation=ii,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Le(0,0,0),this.blendAlpha=0,this.depthFunc=ar,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=jo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=yi,this.stencilZFail=yi,this.stencilZPass=yi,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==ai&&(i.blending=this.blending),this.side!==qn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==wa&&(i.blendSrc=this.blendSrc),this.blendDst!==Ta&&(i.blendDst=this.blendDst),this.blendEquation!==ii&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==ar&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==jo&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==yi&&(i.stencilFail=this.stencilFail),this.stencilZFail!==yi&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==yi&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){const a=[];for(const o in r){const l=r[o];delete l.metadata,a.push(l)}return a}if(t){const r=s(e.textures),a=s(e.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const s=t.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=t[r].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Yt extends Ki{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Le(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=_c,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const xt=new R,Fs=new ue;class jt{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Ko,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Gn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[i+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Fs.fromBufferAttribute(this,t),Fs.applyMatrix3(e),this.setXY(t,Fs.x,Fs.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyMatrix3(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyMatrix4(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyNormalMatrix(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.transformDirection(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=Oi(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=zt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Oi(t,this.array)),t}setX(e,t){return this.normalized&&(t=zt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Oi(t,this.array)),t}setY(e,t){return this.normalized&&(t=zt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Oi(t,this.array)),t}setZ(e,t){return this.normalized&&(t=zt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Oi(t,this.array)),t}setW(e,t){return this.normalized&&(t=zt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=zt(t,this.array),i=zt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,s){return e*=this.itemSize,this.normalized&&(t=zt(t,this.array),i=zt(i,this.array),s=zt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this}setXYZW(e,t,i,s,r){return e*=this.itemSize,this.normalized&&(t=zt(t,this.array),i=zt(i,this.array),s=zt(s,this.array),r=zt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Ko&&(e.usage=this.usage),e}}class Fc extends jt{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class kc extends jt{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class st extends jt{constructor(e,t,i){super(new Float32Array(e),t,i)}}let Qu=0;const rn=new pt,na=new _t,Ai=new R,Qt=new Ms,ns=new Ms,Rt=new R;class It extends ji{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Qu++}),this.uuid=vi(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Ic(e)?kc:Fc)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const r=new je().getNormalMatrix(e);i.applyNormalMatrix(r),i.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return rn.makeRotationFromQuaternion(e),this.applyMatrix4(rn),this}rotateX(e){return rn.makeRotationX(e),this.applyMatrix4(rn),this}rotateY(e){return rn.makeRotationY(e),this.applyMatrix4(rn),this}rotateZ(e){return rn.makeRotationZ(e),this.applyMatrix4(rn),this}translate(e,t,i){return rn.makeTranslation(e,t,i),this.applyMatrix4(rn),this}scale(e,t,i){return rn.makeScale(e,t,i),this.applyMatrix4(rn),this}lookAt(e){return na.lookAt(e),na.updateMatrix(),this.applyMatrix4(na.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ai).negate(),this.translate(Ai.x,Ai.y,Ai.z),this}setFromPoints(e){const t=[];for(let i=0,s=e.length;i<s;i++){const r=e[i];t.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new st(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ms);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,s=t.length;i<s;i++){const r=t[i];Qt.setFromBufferAttribute(r),this.morphTargetsRelative?(Rt.addVectors(this.boundingBox.min,Qt.min),this.boundingBox.expandByPoint(Rt),Rt.addVectors(this.boundingBox.max,Qt.max),this.boundingBox.expandByPoint(Rt)):(this.boundingBox.expandByPoint(Qt.min),this.boundingBox.expandByPoint(Qt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ss);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new R,1/0);return}if(e){const i=this.boundingSphere.center;if(Qt.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const o=t[r];ns.setFromBufferAttribute(o),this.morphTargetsRelative?(Rt.addVectors(Qt.min,ns.min),Qt.expandByPoint(Rt),Rt.addVectors(Qt.max,ns.max),Qt.expandByPoint(Rt)):(Qt.expandByPoint(ns.min),Qt.expandByPoint(ns.max))}Qt.getCenter(i);let s=0;for(let r=0,a=e.count;r<a;r++)Rt.fromBufferAttribute(e,r),s=Math.max(s,i.distanceToSquared(Rt));if(t)for(let r=0,a=t.length;r<a;r++){const o=t[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Rt.fromBufferAttribute(o,c),l&&(Ai.fromBufferAttribute(e,c),Rt.add(Ai)),s=Math.max(s,i.distanceToSquared(Rt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=e.array,s=t.position.array,r=t.normal.array,a=t.uv.array,o=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new jt(new Float32Array(4*o),4));const l=this.getAttribute("tangent").array,c=[],h=[];for(let S=0;S<o;S++)c[S]=new R,h[S]=new R;const u=new R,d=new R,f=new R,g=new ue,v=new ue,p=new ue,m=new R,M=new R;function _(S,D,F){u.fromArray(s,S*3),d.fromArray(s,D*3),f.fromArray(s,F*3),g.fromArray(a,S*2),v.fromArray(a,D*2),p.fromArray(a,F*2),d.sub(u),f.sub(u),v.sub(g),p.sub(g);const X=1/(v.x*p.y-p.x*v.y);isFinite(X)&&(m.copy(d).multiplyScalar(p.y).addScaledVector(f,-v.y).multiplyScalar(X),M.copy(f).multiplyScalar(v.x).addScaledVector(d,-p.x).multiplyScalar(X),c[S].add(m),c[D].add(m),c[F].add(m),h[S].add(M),h[D].add(M),h[F].add(M))}let x=this.groups;x.length===0&&(x=[{start:0,count:i.length}]);for(let S=0,D=x.length;S<D;++S){const F=x[S],X=F.start,L=F.count;for(let B=X,H=X+L;B<H;B+=3)_(i[B+0],i[B+1],i[B+2])}const P=new R,w=new R,A=new R,N=new R;function y(S){A.fromArray(r,S*3),N.copy(A);const D=c[S];P.copy(D),P.sub(A.multiplyScalar(A.dot(D))).normalize(),w.crossVectors(N,D);const X=w.dot(h[S])<0?-1:1;l[S*4]=P.x,l[S*4+1]=P.y,l[S*4+2]=P.z,l[S*4+3]=X}for(let S=0,D=x.length;S<D;++S){const F=x[S],X=F.start,L=F.count;for(let B=X,H=X+L;B<H;B+=3)y(i[B+0]),y(i[B+1]),y(i[B+2])}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new jt(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let d=0,f=i.count;d<f;d++)i.setXYZ(d,0,0,0);const s=new R,r=new R,a=new R,o=new R,l=new R,c=new R,h=new R,u=new R;if(e)for(let d=0,f=e.count;d<f;d+=3){const g=e.getX(d+0),v=e.getX(d+1),p=e.getX(d+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,v),a.fromBufferAttribute(t,p),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),o.fromBufferAttribute(i,g),l.fromBufferAttribute(i,v),c.fromBufferAttribute(i,p),o.add(h),l.add(h),c.add(h),i.setXYZ(g,o.x,o.y,o.z),i.setXYZ(v,l.x,l.y,l.z),i.setXYZ(p,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),a.fromBufferAttribute(t,d+2),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),i.setXYZ(d+0,h.x,h.y,h.z),i.setXYZ(d+1,h.x,h.y,h.z),i.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Rt.fromBufferAttribute(e,t),Rt.normalize(),e.setXYZ(t,Rt.x,Rt.y,Rt.z)}toNonIndexed(){function e(o,l){const c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h);let f=0,g=0;for(let v=0,p=l.length;v<p;v++){o.isInterleavedBufferAttribute?f=l[v]*o.data.stride+o.offset:f=l[v]*h;for(let m=0;m<h;m++)d[g++]=c[f++]}return new jt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new It,i=this.index.array,s=this.attributes;for(const o in s){const l=s[o],c=e(l,i);t.setAttribute(o,c)}const r=this.morphAttributes;for(const o in r){const l=[],c=r[o];for(let h=0,u=c.length;h<u;h++){const d=c[h],f=e(d,i);l.push(f)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const l in i){const c=i[l];e.data.attributes[l]=c.toJSON(e.data)}const s={};let r=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(s[l]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(t));const s=e.attributes;for(const c in s){const h=s[c];this.setAttribute(c,h.clone(t))}const r=e.morphAttributes;for(const c in r){const h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,h=a.length;c<h;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const hl=new pt,Zn=new ja,ks=new Ss,ul=new R,Ci=new R,Ri=new R,Pi=new R,ia=new R,Bs=new R,zs=new ue,Gs=new ue,Hs=new ue,dl=new R,fl=new R,pl=new R,Vs=new R,Ws=new R;class oe extends _t{constructor(e=new It,t=new Yt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const s=t[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(e,t){const i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(s,e);const o=this.morphTargetInfluences;if(r&&o){Bs.set(0,0,0);for(let l=0,c=r.length;l<c;l++){const h=o[l],u=r[l];h!==0&&(ia.fromBufferAttribute(u,e),a?Bs.addScaledVector(ia,h):Bs.addScaledVector(ia.sub(t),h))}t.add(Bs)}return t}raycast(e,t){const i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),ks.copy(i.boundingSphere),ks.applyMatrix4(r),Zn.copy(e.ray).recast(e.near),!(ks.containsPoint(Zn.origin)===!1&&(Zn.intersectSphere(ks,ul)===null||Zn.origin.distanceToSquared(ul)>(e.far-e.near)**2))&&(hl.copy(r).invert(),Zn.copy(e.ray).applyMatrix4(hl),!(i.boundingBox!==null&&Zn.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,Zn)))}_computeIntersections(e,t,i){let s;const r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=d.length;g<v;g++){const p=d[g],m=a[p.materialIndex],M=Math.max(p.start,f.start),_=Math.min(o.count,Math.min(p.start+p.count,f.start+f.count));for(let x=M,P=_;x<P;x+=3){const w=o.getX(x),A=o.getX(x+1),N=o.getX(x+2);s=Xs(this,m,e,i,c,h,u,w,A,N),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=p.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),v=Math.min(o.count,f.start+f.count);for(let p=g,m=v;p<m;p+=3){const M=o.getX(p),_=o.getX(p+1),x=o.getX(p+2);s=Xs(this,a,e,i,c,h,u,M,_,x),s&&(s.faceIndex=Math.floor(p/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,v=d.length;g<v;g++){const p=d[g],m=a[p.materialIndex],M=Math.max(p.start,f.start),_=Math.min(l.count,Math.min(p.start+p.count,f.start+f.count));for(let x=M,P=_;x<P;x+=3){const w=x,A=x+1,N=x+2;s=Xs(this,m,e,i,c,h,u,w,A,N),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=p.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),v=Math.min(l.count,f.start+f.count);for(let p=g,m=v;p<m;p+=3){const M=p,_=p+1,x=p+2;s=Xs(this,a,e,i,c,h,u,M,_,x),s&&(s.faceIndex=Math.floor(p/3),t.push(s))}}}}function ed(n,e,t,i,s,r,a,o){let l;if(e.side===qt?l=i.intersectTriangle(a,r,s,!0,o):l=i.intersectTriangle(s,r,a,e.side===qn,o),l===null)return null;Ws.copy(o),Ws.applyMatrix4(n.matrixWorld);const c=t.ray.origin.distanceTo(Ws);return c<t.near||c>t.far?null:{distance:c,point:Ws.clone(),object:n}}function Xs(n,e,t,i,s,r,a,o,l,c){n.getVertexPosition(o,Ci),n.getVertexPosition(l,Ri),n.getVertexPosition(c,Pi);const h=ed(n,e,t,i,Ci,Ri,Pi,Vs);if(h){s&&(zs.fromBufferAttribute(s,o),Gs.fromBufferAttribute(s,l),Hs.fromBufferAttribute(s,c),h.uv=gn.getInterpolation(Vs,Ci,Ri,Pi,zs,Gs,Hs,new ue)),r&&(zs.fromBufferAttribute(r,o),Gs.fromBufferAttribute(r,l),Hs.fromBufferAttribute(r,c),h.uv1=gn.getInterpolation(Vs,Ci,Ri,Pi,zs,Gs,Hs,new ue),h.uv2=h.uv1),a&&(dl.fromBufferAttribute(a,o),fl.fromBufferAttribute(a,l),pl.fromBufferAttribute(a,c),h.normal=gn.getInterpolation(Vs,Ci,Ri,Pi,dl,fl,pl,new R),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new R,materialIndex:0};gn.getNormal(Ci,Ri,Pi,u.normal),h.face=u}return h}class Fe extends It{constructor(e=1,t=1,i=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const l=[],c=[],h=[],u=[];let d=0,f=0;g("z","y","x",-1,-1,i,t,e,a,r,0),g("z","y","x",1,-1,i,t,-e,a,r,1),g("x","z","y",1,1,e,i,t,s,a,2),g("x","z","y",1,-1,e,i,-t,s,a,3),g("x","y","z",1,-1,e,t,i,s,r,4),g("x","y","z",-1,-1,e,t,-i,s,r,5),this.setIndex(l),this.setAttribute("position",new st(c,3)),this.setAttribute("normal",new st(h,3)),this.setAttribute("uv",new st(u,2));function g(v,p,m,M,_,x,P,w,A,N,y){const S=x/A,D=P/N,F=x/2,X=P/2,L=w/2,B=A+1,H=N+1;let Z=0,J=0;const j=new R;for(let ee=0;ee<H;ee++){const le=ee*D-X;for(let k=0;k<B;k++){const O=k*S-F;j[v]=O*M,j[p]=le*_,j[m]=L,c.push(j.x,j.y,j.z),j[v]=0,j[p]=0,j[m]=w>0?1:-1,h.push(j.x,j.y,j.z),u.push(k/A),u.push(1-ee/N),Z+=1}}for(let ee=0;ee<N;ee++)for(let le=0;le<A;le++){const k=d+le+B*ee,O=d+le+B*(ee+1),V=d+(le+1)+B*(ee+1),Q=d+(le+1)+B*ee;l.push(k,O,Q),l.push(O,V,Q),J+=6}o.addGroup(f,J,y),f+=J,d+=Z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fe(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Xi(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const s=n[t][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=s.clone():Array.isArray(s)?e[t][i]=s.slice():e[t][i]=s}}return e}function Gt(n){const e={};for(let t=0;t<n.length;t++){const i=Xi(n[t]);for(const s in i)e[s]=i[s]}return e}function td(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function Bc(n){return n.getRenderTarget()===null?n.outputColorSpace:nt.workingColorSpace}const nd={clone:Xi,merge:Gt};var id=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,sd=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class fi extends Ki{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=id,this.fragmentShader=sd,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Xi(e.uniforms),this.uniformsGroups=td(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?t.uniforms[s]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[s]={type:"m4",value:a.toArray()}:t.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class zc extends _t{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new pt,this.projectionMatrix=new pt,this.projectionMatrixInverse=new pt,this.coordinateSystem=Dn}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class Wt extends zc{constructor(e=50,t=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Wi*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(as*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Wi*2*Math.atan(Math.tan(as*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,s,r,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(as*.5*this.fov)/this.zoom,i=2*t,s=this.aspect*i,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*s/l,t-=a.offsetY*i/c,s*=a.width/l,i*=a.height/c}const o=this.filmOffset;o!==0&&(r+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Li=-90,Ii=1;class rd extends _t{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Wt(Li,Ii,e,t);s.layers=this.layers,this.add(s);const r=new Wt(Li,Ii,e,t);r.layers=this.layers,this.add(r);const a=new Wt(Li,Ii,e,t);a.layers=this.layers,this.add(a);const o=new Wt(Li,Ii,e,t);o.layers=this.layers,this.add(o);const l=new Wt(Li,Ii,e,t);l.layers=this.layers,this.add(l);const c=new Wt(Li,Ii,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,s,r,a,o,l]=t;for(const c of t)this.remove(c);if(e===Dn)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===dr)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,s),e.render(t,r),e.setRenderTarget(i,1,s),e.render(t,a),e.setRenderTarget(i,2,s),e.render(t,o),e.setRenderTarget(i,3,s),e.render(t,l),e.setRenderTarget(i,4,s),e.render(t,c),i.texture.generateMipmaps=v,e.setRenderTarget(i,5,s),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=g,i.texture.needsPMREMUpdate=!0}}class Gc extends Kt{constructor(e,t,i,s,r,a,o,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:Gi,super(e,t,i,s,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class ad extends di{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},s=[i,i,i,i,i,i];t.encoding!==void 0&&(ls("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===ci?dt:cn),this.texture=new Gc(s,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:on}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Fe(5,5,5),r=new fi({name:"CubemapFromEquirect",uniforms:Xi(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:qt,blending:Vn});r.uniforms.tEquirect.value=t;const a=new oe(s,r),o=t.minFilter;return t.minFilter===ps&&(t.minFilter=on),new rd(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,s){const r=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,s);e.setRenderTarget(r)}}const sa=new R,od=new R,ld=new je;class ti{constructor(e=new R(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,s){return this.normal.set(e,t,i),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const s=sa.subVectors(i,t).cross(od.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(sa),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(i,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||ld.getNormalMatrix(e),s=this.coplanarPoint(sa).applyMatrix4(e),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Qn=new Ss,$s=new R;class Ja{constructor(e=new ti,t=new ti,i=new ti,s=new ti,r=new ti,a=new ti){this.planes=[e,t,i,s,r,a]}set(e,t,i,s,r,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=Dn){const i=this.planes,s=e.elements,r=s[0],a=s[1],o=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],f=s[8],g=s[9],v=s[10],p=s[11],m=s[12],M=s[13],_=s[14],x=s[15];if(i[0].setComponents(l-r,d-c,p-f,x-m).normalize(),i[1].setComponents(l+r,d+c,p+f,x+m).normalize(),i[2].setComponents(l+a,d+h,p+g,x+M).normalize(),i[3].setComponents(l-a,d-h,p-g,x-M).normalize(),i[4].setComponents(l-o,d-u,p-v,x-_).normalize(),t===Dn)i[5].setComponents(l+o,d+u,p+v,x+_).normalize();else if(t===dr)i[5].setComponents(o,u,v,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Qn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Qn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Qn)}intersectsSprite(e){return Qn.center.set(0,0,0),Qn.radius=.7071067811865476,Qn.applyMatrix4(e.matrixWorld),this.intersectsSphere(Qn)}intersectsSphere(e){const t=this.planes,i=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const s=t[i];if($s.x=s.normal.x>0?e.max.x:e.min.x,$s.y=s.normal.y>0?e.max.y:e.min.y,$s.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint($s)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Hc(){let n=null,e=!1,t=null,i=null;function s(r,a){t(r,a),i=n.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(s),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){n=r}}}function cd(n,e){const t=e.isWebGL2,i=new WeakMap;function s(c,h){const u=c.array,d=c.usage,f=u.byteLength,g=n.createBuffer();n.bindBuffer(h,g),n.bufferData(h,u,d),c.onUploadCallback();let v;if(u instanceof Float32Array)v=n.FLOAT;else if(u instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(t)v=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else v=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)v=n.SHORT;else if(u instanceof Uint32Array)v=n.UNSIGNED_INT;else if(u instanceof Int32Array)v=n.INT;else if(u instanceof Int8Array)v=n.BYTE;else if(u instanceof Uint8Array)v=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)v=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:g,type:v,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:f}}function r(c,h,u){const d=h.array,f=h._updateRange,g=h.updateRanges;if(n.bindBuffer(u,c),f.count===-1&&g.length===0&&n.bufferSubData(u,0,d),g.length!==0){for(let v=0,p=g.length;v<p;v++){const m=g[v];t?n.bufferSubData(u,m.start*d.BYTES_PER_ELEMENT,d,m.start,m.count):n.bufferSubData(u,m.start*d.BYTES_PER_ELEMENT,d.subarray(m.start,m.start+m.count))}h.clearUpdateRanges()}f.count!==-1&&(t?n.bufferSubData(u,f.offset*d.BYTES_PER_ELEMENT,d,f.offset,f.count):n.bufferSubData(u,f.offset*d.BYTES_PER_ELEMENT,d.subarray(f.offset,f.offset+f.count)),f.count=-1),h.onUploadCallback()}function a(c){return c.isInterleavedBufferAttribute&&(c=c.data),i.get(c)}function o(c){c.isInterleavedBufferAttribute&&(c=c.data);const h=i.get(c);h&&(n.deleteBuffer(h.buffer),i.delete(c))}function l(c,h){if(c.isGLBufferAttribute){const d=i.get(c);(!d||d.version<c.version)&&i.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);const u=i.get(c);if(u===void 0)i.set(c,s(c,h));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,c,h),u.version=c.version}}return{get:a,remove:o,update:l}}class pi extends It{constructor(e=1,t=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:s};const r=e/2,a=t/2,o=Math.floor(i),l=Math.floor(s),c=o+1,h=l+1,u=e/o,d=t/l,f=[],g=[],v=[],p=[];for(let m=0;m<h;m++){const M=m*d-a;for(let _=0;_<c;_++){const x=_*u-r;g.push(x,-M,0),v.push(0,0,1),p.push(_/o),p.push(1-m/l)}}for(let m=0;m<l;m++)for(let M=0;M<o;M++){const _=M+c*m,x=M+c*(m+1),P=M+1+c*(m+1),w=M+1+c*m;f.push(_,x,w),f.push(x,P,w)}this.setIndex(f),this.setAttribute("position",new st(g,3)),this.setAttribute("normal",new st(v,3)),this.setAttribute("uv",new st(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new pi(e.width,e.height,e.widthSegments,e.heightSegments)}}var hd=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,ud=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,dd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,fd=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,pd=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,md=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,gd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,vd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,yd=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,_d=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Md=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Sd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,xd=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,bd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Ed=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,wd=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Td=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Ad=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Cd=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Rd=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Pd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Ld=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Id=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Dd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Ud=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Nd=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Od=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Fd=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,kd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Bd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,zd="gl_FragColor = linearToOutputTexel( gl_FragColor );",Gd=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Hd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Vd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Wd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Xd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,$d=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,qd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Yd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,jd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Kd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Jd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Zd=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Qd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,ef=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,tf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,nf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,sf=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,rf=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,af=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,of=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lf=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,cf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,hf=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,uf=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,df=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,ff=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,pf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,mf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,gf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,vf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,yf=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,_f=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Mf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Sf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xf=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,bf=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ef=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,wf=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Tf=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Af=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Cf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Rf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Pf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Lf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,If=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Df=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Uf=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Nf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Of=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Ff=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,kf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Bf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,zf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Gf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Hf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Vf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Wf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Xf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,$f=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,qf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Yf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,jf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Kf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Jf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Zf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Qf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,ep=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,tp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,np=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ip=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,sp=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,rp=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,ap=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,op=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,lp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,cp=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const hp=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,up=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fp=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,mp=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,gp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,vp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,yp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_p=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Mp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Sp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xp=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,bp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ep=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,wp=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ap=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cp=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Rp=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pp=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Lp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Ip=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Dp=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Up=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Np=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Op=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Fp=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Bp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,zp=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Gp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Hp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Vp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Xe={alphahash_fragment:hd,alphahash_pars_fragment:ud,alphamap_fragment:dd,alphamap_pars_fragment:fd,alphatest_fragment:pd,alphatest_pars_fragment:md,aomap_fragment:gd,aomap_pars_fragment:vd,batching_pars_vertex:yd,batching_vertex:_d,begin_vertex:Md,beginnormal_vertex:Sd,bsdfs:xd,iridescence_fragment:bd,bumpmap_pars_fragment:Ed,clipping_planes_fragment:wd,clipping_planes_pars_fragment:Td,clipping_planes_pars_vertex:Ad,clipping_planes_vertex:Cd,color_fragment:Rd,color_pars_fragment:Pd,color_pars_vertex:Ld,color_vertex:Id,common:Dd,cube_uv_reflection_fragment:Ud,defaultnormal_vertex:Nd,displacementmap_pars_vertex:Od,displacementmap_vertex:Fd,emissivemap_fragment:kd,emissivemap_pars_fragment:Bd,colorspace_fragment:zd,colorspace_pars_fragment:Gd,envmap_fragment:Hd,envmap_common_pars_fragment:Vd,envmap_pars_fragment:Wd,envmap_pars_vertex:Xd,envmap_physical_pars_fragment:sf,envmap_vertex:$d,fog_vertex:qd,fog_pars_vertex:Yd,fog_fragment:jd,fog_pars_fragment:Kd,gradientmap_pars_fragment:Jd,lightmap_fragment:Zd,lightmap_pars_fragment:Qd,lights_lambert_fragment:ef,lights_lambert_pars_fragment:tf,lights_pars_begin:nf,lights_toon_fragment:rf,lights_toon_pars_fragment:af,lights_phong_fragment:of,lights_phong_pars_fragment:lf,lights_physical_fragment:cf,lights_physical_pars_fragment:hf,lights_fragment_begin:uf,lights_fragment_maps:df,lights_fragment_end:ff,logdepthbuf_fragment:pf,logdepthbuf_pars_fragment:mf,logdepthbuf_pars_vertex:gf,logdepthbuf_vertex:vf,map_fragment:yf,map_pars_fragment:_f,map_particle_fragment:Mf,map_particle_pars_fragment:Sf,metalnessmap_fragment:xf,metalnessmap_pars_fragment:bf,morphcolor_vertex:Ef,morphnormal_vertex:wf,morphtarget_pars_vertex:Tf,morphtarget_vertex:Af,normal_fragment_begin:Cf,normal_fragment_maps:Rf,normal_pars_fragment:Pf,normal_pars_vertex:Lf,normal_vertex:If,normalmap_pars_fragment:Df,clearcoat_normal_fragment_begin:Uf,clearcoat_normal_fragment_maps:Nf,clearcoat_pars_fragment:Of,iridescence_pars_fragment:Ff,opaque_fragment:kf,packing:Bf,premultiplied_alpha_fragment:zf,project_vertex:Gf,dithering_fragment:Hf,dithering_pars_fragment:Vf,roughnessmap_fragment:Wf,roughnessmap_pars_fragment:Xf,shadowmap_pars_fragment:$f,shadowmap_pars_vertex:qf,shadowmap_vertex:Yf,shadowmask_pars_fragment:jf,skinbase_vertex:Kf,skinning_pars_vertex:Jf,skinning_vertex:Zf,skinnormal_vertex:Qf,specularmap_fragment:ep,specularmap_pars_fragment:tp,tonemapping_fragment:np,tonemapping_pars_fragment:ip,transmission_fragment:sp,transmission_pars_fragment:rp,uv_pars_fragment:ap,uv_pars_vertex:op,uv_vertex:lp,worldpos_vertex:cp,background_vert:hp,background_frag:up,backgroundCube_vert:dp,backgroundCube_frag:fp,cube_vert:pp,cube_frag:mp,depth_vert:gp,depth_frag:vp,distanceRGBA_vert:yp,distanceRGBA_frag:_p,equirect_vert:Mp,equirect_frag:Sp,linedashed_vert:xp,linedashed_frag:bp,meshbasic_vert:Ep,meshbasic_frag:wp,meshlambert_vert:Tp,meshlambert_frag:Ap,meshmatcap_vert:Cp,meshmatcap_frag:Rp,meshnormal_vert:Pp,meshnormal_frag:Lp,meshphong_vert:Ip,meshphong_frag:Dp,meshphysical_vert:Up,meshphysical_frag:Np,meshtoon_vert:Op,meshtoon_frag:Fp,points_vert:kp,points_frag:Bp,shadow_vert:zp,shadow_frag:Gp,sprite_vert:Hp,sprite_frag:Vp},pe={common:{diffuse:{value:new Le(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new je}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new je}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new je}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new je},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new je},normalScale:{value:new ue(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new je},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new je}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new je}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new je}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Le(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Le(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0},uvTransform:{value:new je}},sprite:{diffuse:{value:new Le(16777215)},opacity:{value:1},center:{value:new ue(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}}},Sn={basic:{uniforms:Gt([pe.common,pe.specularmap,pe.envmap,pe.aomap,pe.lightmap,pe.fog]),vertexShader:Xe.meshbasic_vert,fragmentShader:Xe.meshbasic_frag},lambert:{uniforms:Gt([pe.common,pe.specularmap,pe.envmap,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.fog,pe.lights,{emissive:{value:new Le(0)}}]),vertexShader:Xe.meshlambert_vert,fragmentShader:Xe.meshlambert_frag},phong:{uniforms:Gt([pe.common,pe.specularmap,pe.envmap,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.fog,pe.lights,{emissive:{value:new Le(0)},specular:{value:new Le(1118481)},shininess:{value:30}}]),vertexShader:Xe.meshphong_vert,fragmentShader:Xe.meshphong_frag},standard:{uniforms:Gt([pe.common,pe.envmap,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.roughnessmap,pe.metalnessmap,pe.fog,pe.lights,{emissive:{value:new Le(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Xe.meshphysical_vert,fragmentShader:Xe.meshphysical_frag},toon:{uniforms:Gt([pe.common,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.gradientmap,pe.fog,pe.lights,{emissive:{value:new Le(0)}}]),vertexShader:Xe.meshtoon_vert,fragmentShader:Xe.meshtoon_frag},matcap:{uniforms:Gt([pe.common,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.fog,{matcap:{value:null}}]),vertexShader:Xe.meshmatcap_vert,fragmentShader:Xe.meshmatcap_frag},points:{uniforms:Gt([pe.points,pe.fog]),vertexShader:Xe.points_vert,fragmentShader:Xe.points_frag},dashed:{uniforms:Gt([pe.common,pe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Xe.linedashed_vert,fragmentShader:Xe.linedashed_frag},depth:{uniforms:Gt([pe.common,pe.displacementmap]),vertexShader:Xe.depth_vert,fragmentShader:Xe.depth_frag},normal:{uniforms:Gt([pe.common,pe.bumpmap,pe.normalmap,pe.displacementmap,{opacity:{value:1}}]),vertexShader:Xe.meshnormal_vert,fragmentShader:Xe.meshnormal_frag},sprite:{uniforms:Gt([pe.sprite,pe.fog]),vertexShader:Xe.sprite_vert,fragmentShader:Xe.sprite_frag},background:{uniforms:{uvTransform:{value:new je},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Xe.background_vert,fragmentShader:Xe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Xe.backgroundCube_vert,fragmentShader:Xe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Xe.cube_vert,fragmentShader:Xe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Xe.equirect_vert,fragmentShader:Xe.equirect_frag},distanceRGBA:{uniforms:Gt([pe.common,pe.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Xe.distanceRGBA_vert,fragmentShader:Xe.distanceRGBA_frag},shadow:{uniforms:Gt([pe.lights,pe.fog,{color:{value:new Le(0)},opacity:{value:1}}]),vertexShader:Xe.shadow_vert,fragmentShader:Xe.shadow_frag}};Sn.physical={uniforms:Gt([Sn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new je},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new je},clearcoatNormalScale:{value:new ue(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new je},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new je},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new je},sheen:{value:0},sheenColor:{value:new Le(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new je},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new je},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new je},transmissionSamplerSize:{value:new ue},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new je},attenuationDistance:{value:0},attenuationColor:{value:new Le(0)},specularColor:{value:new Le(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new je},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new je},anisotropyVector:{value:new ue},anisotropyMap:{value:null},anisotropyMapTransform:{value:new je}}]),vertexShader:Xe.meshphysical_vert,fragmentShader:Xe.meshphysical_frag};const qs={r:0,b:0,g:0};function Wp(n,e,t,i,s,r,a){const o=new Le(0);let l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(p,m){let M=!1,_=m.isScene===!0?m.background:null;_&&_.isTexture&&(_=(m.backgroundBlurriness>0?t:e).get(_)),_===null?v(o,l):_&&_.isColor&&(v(_,1),M=!0);const x=n.xr.getEnvironmentBlendMode();x==="additive"?i.buffers.color.setClear(0,0,0,1,a):x==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||M)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),_&&(_.isCubeTexture||_.mapping===xr)?(h===void 0&&(h=new oe(new Fe(1,1,1),new fi({name:"BackgroundCubeMaterial",uniforms:Xi(Sn.backgroundCube.uniforms),vertexShader:Sn.backgroundCube.vertexShader,fragmentShader:Sn.backgroundCube.fragmentShader,side:qt,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(P,w,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=_,h.material.uniforms.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=m.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,h.material.toneMapped=nt.getTransfer(_.colorSpace)!==lt,(u!==_||d!==_.version||f!==n.toneMapping)&&(h.material.needsUpdate=!0,u=_,d=_.version,f=n.toneMapping),h.layers.enableAll(),p.unshift(h,h.geometry,h.material,0,0,null)):_&&_.isTexture&&(c===void 0&&(c=new oe(new pi(2,2),new fi({name:"BackgroundMaterial",uniforms:Xi(Sn.background.uniforms),vertexShader:Sn.background.vertexShader,fragmentShader:Sn.background.fragmentShader,side:qn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=_,c.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,c.material.toneMapped=nt.getTransfer(_.colorSpace)!==lt,_.matrixAutoUpdate===!0&&_.updateMatrix(),c.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||d!==_.version||f!==n.toneMapping)&&(c.material.needsUpdate=!0,u=_,d=_.version,f=n.toneMapping),c.layers.enableAll(),p.unshift(c,c.geometry,c.material,0,0,null))}function v(p,m){p.getRGB(qs,Bc(n)),i.buffers.color.setClear(qs.r,qs.g,qs.b,m,a)}return{getClearColor:function(){return o},setClearColor:function(p,m=1){o.set(p),l=m,v(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(p){l=p,v(o,l)},render:g}}function Xp(n,e,t,i){const s=n.getParameter(n.MAX_VERTEX_ATTRIBS),r=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||r!==null,o={},l=p(null);let c=l,h=!1;function u(L,B,H,Z,J){let j=!1;if(a){const ee=v(Z,H,B);c!==ee&&(c=ee,f(c.object)),j=m(L,Z,H,J),j&&M(L,Z,H,J)}else{const ee=B.wireframe===!0;(c.geometry!==Z.id||c.program!==H.id||c.wireframe!==ee)&&(c.geometry=Z.id,c.program=H.id,c.wireframe=ee,j=!0)}J!==null&&t.update(J,n.ELEMENT_ARRAY_BUFFER),(j||h)&&(h=!1,N(L,B,H,Z),J!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,t.get(J).buffer))}function d(){return i.isWebGL2?n.createVertexArray():r.createVertexArrayOES()}function f(L){return i.isWebGL2?n.bindVertexArray(L):r.bindVertexArrayOES(L)}function g(L){return i.isWebGL2?n.deleteVertexArray(L):r.deleteVertexArrayOES(L)}function v(L,B,H){const Z=H.wireframe===!0;let J=o[L.id];J===void 0&&(J={},o[L.id]=J);let j=J[B.id];j===void 0&&(j={},J[B.id]=j);let ee=j[Z];return ee===void 0&&(ee=p(d()),j[Z]=ee),ee}function p(L){const B=[],H=[],Z=[];for(let J=0;J<s;J++)B[J]=0,H[J]=0,Z[J]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:H,attributeDivisors:Z,object:L,attributes:{},index:null}}function m(L,B,H,Z){const J=c.attributes,j=B.attributes;let ee=0;const le=H.getAttributes();for(const k in le)if(le[k].location>=0){const V=J[k];let Q=j[k];if(Q===void 0&&(k==="instanceMatrix"&&L.instanceMatrix&&(Q=L.instanceMatrix),k==="instanceColor"&&L.instanceColor&&(Q=L.instanceColor)),V===void 0||V.attribute!==Q||Q&&V.data!==Q.data)return!0;ee++}return c.attributesNum!==ee||c.index!==Z}function M(L,B,H,Z){const J={},j=B.attributes;let ee=0;const le=H.getAttributes();for(const k in le)if(le[k].location>=0){let V=j[k];V===void 0&&(k==="instanceMatrix"&&L.instanceMatrix&&(V=L.instanceMatrix),k==="instanceColor"&&L.instanceColor&&(V=L.instanceColor));const Q={};Q.attribute=V,V&&V.data&&(Q.data=V.data),J[k]=Q,ee++}c.attributes=J,c.attributesNum=ee,c.index=Z}function _(){const L=c.newAttributes;for(let B=0,H=L.length;B<H;B++)L[B]=0}function x(L){P(L,0)}function P(L,B){const H=c.newAttributes,Z=c.enabledAttributes,J=c.attributeDivisors;H[L]=1,Z[L]===0&&(n.enableVertexAttribArray(L),Z[L]=1),J[L]!==B&&((i.isWebGL2?n:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,B),J[L]=B)}function w(){const L=c.newAttributes,B=c.enabledAttributes;for(let H=0,Z=B.length;H<Z;H++)B[H]!==L[H]&&(n.disableVertexAttribArray(H),B[H]=0)}function A(L,B,H,Z,J,j,ee){ee===!0?n.vertexAttribIPointer(L,B,H,J,j):n.vertexAttribPointer(L,B,H,Z,J,j)}function N(L,B,H,Z){if(i.isWebGL2===!1&&(L.isInstancedMesh||Z.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;_();const J=Z.attributes,j=H.getAttributes(),ee=B.defaultAttributeValues;for(const le in j){const k=j[le];if(k.location>=0){let O=J[le];if(O===void 0&&(le==="instanceMatrix"&&L.instanceMatrix&&(O=L.instanceMatrix),le==="instanceColor"&&L.instanceColor&&(O=L.instanceColor)),O!==void 0){const V=O.normalized,Q=O.itemSize,te=t.get(O);if(te===void 0)continue;const he=te.buffer,be=te.type,Pe=te.bytesPerElement,Se=i.isWebGL2===!0&&(be===n.INT||be===n.UNSIGNED_INT||O.gpuType===xc);if(O.isInterleavedBufferAttribute){const De=O.data,I=De.stride,ce=O.offset;if(De.isInstancedInterleavedBuffer){for(let Y=0;Y<k.locationSize;Y++)P(k.location+Y,De.meshPerAttribute);L.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=De.meshPerAttribute*De.count)}else for(let Y=0;Y<k.locationSize;Y++)x(k.location+Y);n.bindBuffer(n.ARRAY_BUFFER,he);for(let Y=0;Y<k.locationSize;Y++)A(k.location+Y,Q/k.locationSize,be,V,I*Pe,(ce+Q/k.locationSize*Y)*Pe,Se)}else{if(O.isInstancedBufferAttribute){for(let De=0;De<k.locationSize;De++)P(k.location+De,O.meshPerAttribute);L.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=O.meshPerAttribute*O.count)}else for(let De=0;De<k.locationSize;De++)x(k.location+De);n.bindBuffer(n.ARRAY_BUFFER,he);for(let De=0;De<k.locationSize;De++)A(k.location+De,Q/k.locationSize,be,V,Q*Pe,Q/k.locationSize*De*Pe,Se)}}else if(ee!==void 0){const V=ee[le];if(V!==void 0)switch(V.length){case 2:n.vertexAttrib2fv(k.location,V);break;case 3:n.vertexAttrib3fv(k.location,V);break;case 4:n.vertexAttrib4fv(k.location,V);break;default:n.vertexAttrib1fv(k.location,V)}}}}w()}function y(){F();for(const L in o){const B=o[L];for(const H in B){const Z=B[H];for(const J in Z)g(Z[J].object),delete Z[J];delete B[H]}delete o[L]}}function S(L){if(o[L.id]===void 0)return;const B=o[L.id];for(const H in B){const Z=B[H];for(const J in Z)g(Z[J].object),delete Z[J];delete B[H]}delete o[L.id]}function D(L){for(const B in o){const H=o[B];if(H[L.id]===void 0)continue;const Z=H[L.id];for(const J in Z)g(Z[J].object),delete Z[J];delete H[L.id]}}function F(){X(),h=!0,c!==l&&(c=l,f(c.object))}function X(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:u,reset:F,resetDefaultState:X,dispose:y,releaseStatesOfGeometry:S,releaseStatesOfProgram:D,initAttributes:_,enableAttribute:x,disableUnusedAttributes:w}}function $p(n,e,t,i){const s=i.isWebGL2;let r;function a(h){r=h}function o(h,u){n.drawArrays(r,h,u),t.update(u,r,1)}function l(h,u,d){if(d===0)return;let f,g;if(s)f=n,g="drawArraysInstanced";else if(f=e.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",f===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}f[g](r,h,u,d),t.update(u,r,d)}function c(h,u,d){if(d===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<d;g++)this.render(h[g],u[g]);else{f.multiDrawArraysWEBGL(r,h,0,u,0,d);let g=0;for(let v=0;v<d;v++)g+=u[v];t.update(g,r,1)}}this.setMode=a,this.render=o,this.renderInstances=l,this.renderMultiDraw=c}function qp(n,e,t){let i;function s(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");i=n.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function r(A){if(A==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext";let o=t.precision!==void 0?t.precision:"highp";const l=r(o);l!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",l,"instead."),o=l);const c=a||e.has("WEBGL_draw_buffers"),h=t.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),d=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=n.getParameter(n.MAX_TEXTURE_SIZE),g=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),v=n.getParameter(n.MAX_VERTEX_ATTRIBS),p=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),m=n.getParameter(n.MAX_VARYING_VECTORS),M=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),_=d>0,x=a||e.has("OES_texture_float"),P=_&&x,w=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:c,getMaxAnisotropy:s,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:d,maxTextureSize:f,maxCubemapSize:g,maxAttributes:v,maxVertexUniforms:p,maxVaryings:m,maxFragmentUniforms:M,vertexTextures:_,floatFragmentTextures:x,floatVertexTextures:P,maxSamples:w}}function Yp(n){const e=this;let t=null,i=0,s=!1,r=!1;const a=new ti,o=new je,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||i!==0||s;return s=d,i=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){const g=u.clippingPlanes,v=u.clipIntersection,p=u.clipShadows,m=n.get(u);if(!s||g===null||g.length===0||r&&!p)r?h(null):c();else{const M=r?0:i,_=M*4;let x=m.clippingState||null;l.value=x,x=h(g,d,_,f);for(let P=0;P!==_;++P)x[P]=t[P];m.clippingState=x,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=M}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function h(u,d,f,g){const v=u!==null?u.length:0;let p=null;if(v!==0){if(p=l.value,g!==!0||p===null){const m=f+v*4,M=d.matrixWorldInverse;o.getNormalMatrix(M),(p===null||p.length<m)&&(p=new Float32Array(m));for(let _=0,x=f;_!==v;++_,x+=4)a.copy(u[_]).applyMatrix4(M,o),a.normal.toArray(p,x),p[x+3]=a.constant}l.value=p,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,p}}function jp(n){let e=new WeakMap;function t(a,o){return o===or?a.mapping=Gi:o===Aa&&(a.mapping=Hi),a}function i(a){if(a&&a.isTexture){const o=a.mapping;if(o===or||o===Aa)if(e.has(a)){const l=e.get(a).texture;return t(l,a.mapping)}else{const l=a.image;if(l&&l.height>0){const c=new ad(l.height/2);return c.fromEquirectangularTexture(n,a),e.set(a,c),a.addEventListener("dispose",s),t(c.texture,a.mapping)}else return null}}return a}function s(a){const o=a.target;o.removeEventListener("dispose",s);const l=e.get(o);l!==void 0&&(e.delete(o),l.dispose())}function r(){e=new WeakMap}return{get:i,dispose:r}}class Vc extends zc{constructor(e=-1,t=1,i=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=i-e,a=i+e,o=s+t,l=s-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const Fi=4,ml=[.125,.215,.35,.446,.526,.582],si=20,ra=new Vc,gl=new Le;let aa=null,oa=0,la=0;const ni=(1+Math.sqrt(5))/2,Di=1/ni,vl=[new R(1,1,1),new R(-1,1,1),new R(1,1,-1),new R(-1,1,-1),new R(0,ni,Di),new R(0,ni,-Di),new R(Di,0,ni),new R(-Di,0,ni),new R(ni,Di,0),new R(-ni,Di,0)];class yl{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,s=100){aa=this._renderer.getRenderTarget(),oa=this._renderer.getActiveCubeFace(),la=this._renderer.getActiveMipmapLevel(),this._setSize(256);const r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,i,s,r),t>0&&this._blur(r,0,0,t),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Sl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ml(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(aa,oa,la),e.scissorTest=!1,Ys(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Gi||e.mapping===Hi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),aa=this._renderer.getRenderTarget(),oa=this._renderer.getActiveCubeFace(),la=this._renderer.getActiveMipmapLevel();const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:on,minFilter:on,generateMipmaps:!1,type:ms,format:vn,colorSpace:Un,depthBuffer:!1},s=_l(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=_l(e,t,i);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Kp(r)),this._blurMaterial=Jp(r,e,t)}return s}_compileMaterial(e){const t=new oe(this._lodPlanes[0],e);this._renderer.compile(t,ra)}_sceneToCubeUV(e,t,i,s){const o=new Wt(90,1,t,i),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(gl),h.toneMapping=Wn,h.autoClear=!1;const f=new Yt({name:"PMREM.Background",side:qt,depthWrite:!1,depthTest:!1}),g=new oe(new Fe,f);let v=!1;const p=e.background;p?p.isColor&&(f.color.copy(p),e.background=null,v=!0):(f.color.copy(gl),v=!0);for(let m=0;m<6;m++){const M=m%3;M===0?(o.up.set(0,l[m],0),o.lookAt(c[m],0,0)):M===1?(o.up.set(0,0,l[m]),o.lookAt(0,c[m],0)):(o.up.set(0,l[m],0),o.lookAt(0,0,c[m]));const _=this._cubeSize;Ys(s,M*_,m>2?_:0,_,_),h.setRenderTarget(s),v&&h.render(g,o),h.render(e,o)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,e.background=p}_textureToCubeUV(e,t){const i=this._renderer,s=e.mapping===Gi||e.mapping===Hi;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Sl()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ml());const r=s?this._cubemapMaterial:this._equirectMaterial,a=new oe(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=e;const l=this._cubeSize;Ys(t,0,0,3*l,2*l),i.setRenderTarget(t),i.render(a,ra)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){const r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=vl[(s-1)%vl.length];this._blur(e,s-1,s,r,a)}t.autoClear=i}_blur(e,t,i,s,r){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,s,"latitudinal",r),this._halfBlur(a,e,i,i,s,"longitudinal",r)}_halfBlur(e,t,i,s,r,a,o){const l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new oe(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[i]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*si-1),v=r/g,p=isFinite(r)?1+Math.floor(h*v):si;p>si&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${si}`);const m=[];let M=0;for(let A=0;A<si;++A){const N=A/v,y=Math.exp(-N*N/2);m.push(y),A===0?M+=y:A<p&&(M+=2*y)}for(let A=0;A<m.length;A++)m[A]=m[A]/M;d.envMap.value=e.texture,d.samples.value=p,d.weights.value=m,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);const{_lodMax:_}=this;d.dTheta.value=g,d.mipInt.value=_-i;const x=this._sizeLods[s],P=3*x*(s>_-Fi?s-_+Fi:0),w=4*(this._cubeSize-x);Ys(t,P,w,3*x,2*x),l.setRenderTarget(t),l.render(u,ra)}}function Kp(n){const e=[],t=[],i=[];let s=n;const r=n-Fi+1+ml.length;for(let a=0;a<r;a++){const o=Math.pow(2,s);t.push(o);let l=1/o;a>n-Fi?l=ml[a-n+Fi-1]:a===0&&(l=0),i.push(l);const c=1/(o-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,v=3,p=2,m=1,M=new Float32Array(v*g*f),_=new Float32Array(p*g*f),x=new Float32Array(m*g*f);for(let w=0;w<f;w++){const A=w%3*2/3-1,N=w>2?0:-1,y=[A,N,0,A+2/3,N,0,A+2/3,N+1,0,A,N,0,A+2/3,N+1,0,A,N+1,0];M.set(y,v*g*w),_.set(d,p*g*w);const S=[w,w,w,w,w,w];x.set(S,m*g*w)}const P=new It;P.setAttribute("position",new jt(M,v)),P.setAttribute("uv",new jt(_,p)),P.setAttribute("faceIndex",new jt(x,m)),e.push(P),s>Fi&&s--}return{lodPlanes:e,sizeLods:t,sigmas:i}}function _l(n,e,t){const i=new di(n,e,t);return i.texture.mapping=xr,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Ys(n,e,t,i,s){n.viewport.set(e,t,i,s),n.scissor.set(e,t,i,s)}function Jp(n,e,t){const i=new Float32Array(si),s=new R(0,1,0);return new fi({name:"SphericalGaussianBlur",defines:{n:si,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Za(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Vn,depthTest:!1,depthWrite:!1})}function Ml(){return new fi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Za(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Vn,depthTest:!1,depthWrite:!1})}function Sl(){return new fi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Za(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Vn,depthTest:!1,depthWrite:!1})}function Za(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Zp(n){let e=new WeakMap,t=null;function i(o){if(o&&o.isTexture){const l=o.mapping,c=l===or||l===Aa,h=l===Gi||l===Hi;if(c||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=e.get(o);return t===null&&(t=new yl(n)),u=c?t.fromEquirectangular(o,u):t.fromCubemap(o,u),e.set(o,u),u.texture}else{if(e.has(o))return e.get(o).texture;{const u=o.image;if(c&&u&&u.height>0||h&&u&&s(u)){t===null&&(t=new yl(n));const d=c?t.fromEquirectangular(o):t.fromCubemap(o);return e.set(o,d),o.addEventListener("dispose",r),d.texture}else return null}}}return o}function s(o){let l=0;const c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function r(o){const l=o.target;l.removeEventListener("dispose",r);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:a}}function Qp(n){const e={};function t(i){if(e[i]!==void 0)return e[i];let s;switch(i){case"WEBGL_depth_texture":s=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=n.getExtension(i)}return e[i]=s,s}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){const s=t(i);return s===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function em(n,e,t,i){const s={},r=new WeakMap;function a(u){const d=u.target;d.index!==null&&e.remove(d.index);for(const g in d.attributes)e.remove(d.attributes[g]);for(const g in d.morphAttributes){const v=d.morphAttributes[g];for(let p=0,m=v.length;p<m;p++)e.remove(v[p])}d.removeEventListener("dispose",a),delete s[d.id];const f=r.get(d);f&&(e.remove(f),r.delete(d)),i.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function o(u,d){return s[d.id]===!0||(d.addEventListener("dispose",a),s[d.id]=!0,t.memory.geometries++),d}function l(u){const d=u.attributes;for(const g in d)e.update(d[g],n.ARRAY_BUFFER);const f=u.morphAttributes;for(const g in f){const v=f[g];for(let p=0,m=v.length;p<m;p++)e.update(v[p],n.ARRAY_BUFFER)}}function c(u){const d=[],f=u.index,g=u.attributes.position;let v=0;if(f!==null){const M=f.array;v=f.version;for(let _=0,x=M.length;_<x;_+=3){const P=M[_+0],w=M[_+1],A=M[_+2];d.push(P,w,w,A,A,P)}}else if(g!==void 0){const M=g.array;v=g.version;for(let _=0,x=M.length/3-1;_<x;_+=3){const P=_+0,w=_+1,A=_+2;d.push(P,w,w,A,A,P)}}else return;const p=new(Ic(d)?kc:Fc)(d,1);p.version=v;const m=r.get(u);m&&e.remove(m),r.set(u,p)}function h(u){const d=r.get(u);if(d){const f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function tm(n,e,t,i){const s=i.isWebGL2;let r;function a(f){r=f}let o,l;function c(f){o=f.type,l=f.bytesPerElement}function h(f,g){n.drawElements(r,g,o,f*l),t.update(g,r,1)}function u(f,g,v){if(v===0)return;let p,m;if(s)p=n,m="drawElementsInstanced";else if(p=e.get("ANGLE_instanced_arrays"),m="drawElementsInstancedANGLE",p===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[m](r,g,o,f*l,v),t.update(g,r,v)}function d(f,g,v){if(v===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let m=0;m<v;m++)this.render(f[m]/l,g[m]);else{p.multiDrawElementsWEBGL(r,g,0,o,f,0,v);let m=0;for(let M=0;M<v;M++)m+=g[M];t.update(m,r,1)}}this.setMode=a,this.setIndex=c,this.render=h,this.renderInstances=u,this.renderMultiDraw=d}function nm(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,a,o){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=o*(r/3);break;case n.LINES:t.lines+=o*(r/2);break;case n.LINE_STRIP:t.lines+=o*(r-1);break;case n.LINE_LOOP:t.lines+=o*r;break;case n.POINTS:t.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:i}}function im(n,e){return n[0]-e[0]}function sm(n,e){return Math.abs(e[1])-Math.abs(n[1])}function rm(n,e,t){const i={},s=new Float32Array(8),r=new WeakMap,a=new ct,o=[];for(let c=0;c<8;c++)o[c]=[c,0];function l(c,h,u){const d=c.morphTargetInfluences;if(e.isWebGL2===!0){const g=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,v=g!==void 0?g.length:0;let p=r.get(h);if(p===void 0||p.count!==v){let B=function(){X.dispose(),r.delete(h),h.removeEventListener("dispose",B)};var f=B;p!==void 0&&p.texture.dispose();const _=h.morphAttributes.position!==void 0,x=h.morphAttributes.normal!==void 0,P=h.morphAttributes.color!==void 0,w=h.morphAttributes.position||[],A=h.morphAttributes.normal||[],N=h.morphAttributes.color||[];let y=0;_===!0&&(y=1),x===!0&&(y=2),P===!0&&(y=3);let S=h.attributes.position.count*y,D=1;S>e.maxTextureSize&&(D=Math.ceil(S/e.maxTextureSize),S=e.maxTextureSize);const F=new Float32Array(S*D*4*v),X=new Nc(F,S,D,v);X.type=Gn,X.needsUpdate=!0;const L=y*4;for(let H=0;H<v;H++){const Z=w[H],J=A[H],j=N[H],ee=S*D*4*H;for(let le=0;le<Z.count;le++){const k=le*L;_===!0&&(a.fromBufferAttribute(Z,le),F[ee+k+0]=a.x,F[ee+k+1]=a.y,F[ee+k+2]=a.z,F[ee+k+3]=0),x===!0&&(a.fromBufferAttribute(J,le),F[ee+k+4]=a.x,F[ee+k+5]=a.y,F[ee+k+6]=a.z,F[ee+k+7]=0),P===!0&&(a.fromBufferAttribute(j,le),F[ee+k+8]=a.x,F[ee+k+9]=a.y,F[ee+k+10]=a.z,F[ee+k+11]=j.itemSize===4?a.w:1)}}p={count:v,texture:X,size:new ue(S,D)},r.set(h,p),h.addEventListener("dispose",B)}let m=0;for(let _=0;_<d.length;_++)m+=d[_];const M=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(n,"morphTargetBaseInfluence",M),u.getUniforms().setValue(n,"morphTargetInfluences",d),u.getUniforms().setValue(n,"morphTargetsTexture",p.texture,t),u.getUniforms().setValue(n,"morphTargetsTextureSize",p.size)}else{const g=d===void 0?0:d.length;let v=i[h.id];if(v===void 0||v.length!==g){v=[];for(let x=0;x<g;x++)v[x]=[x,0];i[h.id]=v}for(let x=0;x<g;x++){const P=v[x];P[0]=x,P[1]=d[x]}v.sort(sm);for(let x=0;x<8;x++)x<g&&v[x][1]?(o[x][0]=v[x][0],o[x][1]=v[x][1]):(o[x][0]=Number.MAX_SAFE_INTEGER,o[x][1]=0);o.sort(im);const p=h.morphAttributes.position,m=h.morphAttributes.normal;let M=0;for(let x=0;x<8;x++){const P=o[x],w=P[0],A=P[1];w!==Number.MAX_SAFE_INTEGER&&A?(p&&h.getAttribute("morphTarget"+x)!==p[w]&&h.setAttribute("morphTarget"+x,p[w]),m&&h.getAttribute("morphNormal"+x)!==m[w]&&h.setAttribute("morphNormal"+x,m[w]),s[x]=A,M+=A):(p&&h.hasAttribute("morphTarget"+x)===!0&&h.deleteAttribute("morphTarget"+x),m&&h.hasAttribute("morphNormal"+x)===!0&&h.deleteAttribute("morphNormal"+x),s[x]=0)}const _=h.morphTargetsRelative?1:1-M;u.getUniforms().setValue(n,"morphTargetBaseInfluence",_),u.getUniforms().setValue(n,"morphTargetInfluences",s)}}return{update:l}}function am(n,e,t,i){let s=new WeakMap;function r(l){const c=i.render.frame,h=l.geometry,u=e.get(l,h);if(s.get(u)!==c&&(e.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),s.get(l)!==c&&(t.update(l.instanceMatrix,n.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,n.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){const d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function a(){s=new WeakMap}function o(l){const c=l.target;c.removeEventListener("dispose",o),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:r,dispose:a}}class Wc extends Kt{constructor(e,t,i,s,r,a,o,l,c,h){if(h=h!==void 0?h:li,h!==li&&h!==Vi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===li&&(i=zn),i===void 0&&h===Vi&&(i=oi),super(null,s,r,a,o,l,h,i,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:Vt,this.minFilter=l!==void 0?l:Vt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const Xc=new Kt,$c=new Wc(1,1);$c.compareFunction=Lc;const qc=new Nc,Yc=new Vu,jc=new Gc,xl=[],bl=[],El=new Float32Array(16),wl=new Float32Array(9),Tl=new Float32Array(4);function Ji(n,e,t){const i=n[0];if(i<=0||i>0)return n;const s=e*t;let r=xl[s];if(r===void 0&&(r=new Float32Array(s),xl[s]=r),e!==0){i.toArray(r,0);for(let a=1,o=0;a!==e;++a)o+=t,n[a].toArray(r,o)}return r}function wt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function Tt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function Er(n,e){let t=bl[e];t===void 0&&(t=new Int32Array(e),bl[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function om(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function lm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;n.uniform2fv(this.addr,e),Tt(t,e)}}function cm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(wt(t,e))return;n.uniform3fv(this.addr,e),Tt(t,e)}}function hm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;n.uniform4fv(this.addr,e),Tt(t,e)}}function um(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(wt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),Tt(t,e)}else{if(wt(t,i))return;Tl.set(i),n.uniformMatrix2fv(this.addr,!1,Tl),Tt(t,i)}}function dm(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(wt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),Tt(t,e)}else{if(wt(t,i))return;wl.set(i),n.uniformMatrix3fv(this.addr,!1,wl),Tt(t,i)}}function fm(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(wt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),Tt(t,e)}else{if(wt(t,i))return;El.set(i),n.uniformMatrix4fv(this.addr,!1,El),Tt(t,i)}}function pm(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function mm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;n.uniform2iv(this.addr,e),Tt(t,e)}}function gm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wt(t,e))return;n.uniform3iv(this.addr,e),Tt(t,e)}}function vm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;n.uniform4iv(this.addr,e),Tt(t,e)}}function ym(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function _m(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;n.uniform2uiv(this.addr,e),Tt(t,e)}}function Mm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wt(t,e))return;n.uniform3uiv(this.addr,e),Tt(t,e)}}function Sm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;n.uniform4uiv(this.addr,e),Tt(t,e)}}function xm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);const r=this.type===n.SAMPLER_2D_SHADOW?$c:Xc;t.setTexture2D(e||r,s)}function bm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture3D(e||Yc,s)}function Em(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTextureCube(e||jc,s)}function wm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture2DArray(e||qc,s)}function Tm(n){switch(n){case 5126:return om;case 35664:return lm;case 35665:return cm;case 35666:return hm;case 35674:return um;case 35675:return dm;case 35676:return fm;case 5124:case 35670:return pm;case 35667:case 35671:return mm;case 35668:case 35672:return gm;case 35669:case 35673:return vm;case 5125:return ym;case 36294:return _m;case 36295:return Mm;case 36296:return Sm;case 35678:case 36198:case 36298:case 36306:case 35682:return xm;case 35679:case 36299:case 36307:return bm;case 35680:case 36300:case 36308:case 36293:return Em;case 36289:case 36303:case 36311:case 36292:return wm}}function Am(n,e){n.uniform1fv(this.addr,e)}function Cm(n,e){const t=Ji(e,this.size,2);n.uniform2fv(this.addr,t)}function Rm(n,e){const t=Ji(e,this.size,3);n.uniform3fv(this.addr,t)}function Pm(n,e){const t=Ji(e,this.size,4);n.uniform4fv(this.addr,t)}function Lm(n,e){const t=Ji(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function Im(n,e){const t=Ji(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function Dm(n,e){const t=Ji(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function Um(n,e){n.uniform1iv(this.addr,e)}function Nm(n,e){n.uniform2iv(this.addr,e)}function Om(n,e){n.uniform3iv(this.addr,e)}function Fm(n,e){n.uniform4iv(this.addr,e)}function km(n,e){n.uniform1uiv(this.addr,e)}function Bm(n,e){n.uniform2uiv(this.addr,e)}function zm(n,e){n.uniform3uiv(this.addr,e)}function Gm(n,e){n.uniform4uiv(this.addr,e)}function Hm(n,e,t){const i=this.cache,s=e.length,r=Er(t,s);wt(i,r)||(n.uniform1iv(this.addr,r),Tt(i,r));for(let a=0;a!==s;++a)t.setTexture2D(e[a]||Xc,r[a])}function Vm(n,e,t){const i=this.cache,s=e.length,r=Er(t,s);wt(i,r)||(n.uniform1iv(this.addr,r),Tt(i,r));for(let a=0;a!==s;++a)t.setTexture3D(e[a]||Yc,r[a])}function Wm(n,e,t){const i=this.cache,s=e.length,r=Er(t,s);wt(i,r)||(n.uniform1iv(this.addr,r),Tt(i,r));for(let a=0;a!==s;++a)t.setTextureCube(e[a]||jc,r[a])}function Xm(n,e,t){const i=this.cache,s=e.length,r=Er(t,s);wt(i,r)||(n.uniform1iv(this.addr,r),Tt(i,r));for(let a=0;a!==s;++a)t.setTexture2DArray(e[a]||qc,r[a])}function $m(n){switch(n){case 5126:return Am;case 35664:return Cm;case 35665:return Rm;case 35666:return Pm;case 35674:return Lm;case 35675:return Im;case 35676:return Dm;case 5124:case 35670:return Um;case 35667:case 35671:return Nm;case 35668:case 35672:return Om;case 35669:case 35673:return Fm;case 5125:return km;case 36294:return Bm;case 36295:return zm;case 36296:return Gm;case 35678:case 36198:case 36298:case 36306:case 35682:return Hm;case 35679:case 36299:case 36307:return Vm;case 35680:case 36300:case 36308:case 36293:return Wm;case 36289:case 36303:case 36311:case 36292:return Xm}}class qm{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=Tm(t.type)}}class Ym{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=$m(t.type)}}class jm{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(e,t[o.id],i)}}}const ca=/(\w+)(\])?(\[|\.)?/g;function Al(n,e){n.seq.push(e),n.map[e.id]=e}function Km(n,e,t){const i=n.name,s=i.length;for(ca.lastIndex=0;;){const r=ca.exec(i),a=ca.lastIndex;let o=r[1];const l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===s){Al(t,c===void 0?new qm(o,n,e):new Ym(o,n,e));break}else{let u=t.map[o];u===void 0&&(u=new jm(o),Al(t,u)),t=u}}}class ir{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){const r=e.getActiveUniform(t,s),a=e.getUniformLocation(t,r.name);Km(r,a,this)}}setValue(e,t,i,s){const r=this.map[t];r!==void 0&&r.setValue(e,i,s)}setOptional(e,t,i){const s=t[i];s!==void 0&&this.setValue(e,i,s)}static upload(e,t,i,s){for(let r=0,a=t.length;r!==a;++r){const o=t[r],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,s)}}static seqWithValue(e,t){const i=[];for(let s=0,r=e.length;s!==r;++s){const a=e[s];a.id in t&&i.push(a)}return i}}function Cl(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const Jm=37297;let Zm=0;function Qm(n,e){const t=n.split(`
`),i=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let a=s;a<r;a++){const o=a+1;i.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return i.join(`
`)}function e0(n){const e=nt.getPrimaries(nt.workingColorSpace),t=nt.getPrimaries(n);let i;switch(e===t?i="":e===ur&&t===hr?i="LinearDisplayP3ToLinearSRGB":e===hr&&t===ur&&(i="LinearSRGBToLinearDisplayP3"),n){case Un:case br:return[i,"LinearTransferOETF"];case dt:case qa:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function Rl(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),s=n.getShaderInfoLog(e).trim();if(i&&s==="")return"";const r=/ERROR: 0:(\d+)/.exec(s);if(r){const a=parseInt(r[1]);return t.toUpperCase()+`

`+s+`

`+Qm(n.getShaderSource(e),a)}else return s}function t0(n,e){const t=e0(e);return`vec4 ${n}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function n0(n,e){let t;switch(e){case eu:t="Linear";break;case tu:t="Reinhard";break;case nu:t="OptimizedCineon";break;case Mc:t="ACESFilmic";break;case su:t="AgX";break;case iu:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function i0(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(ki).join(`
`)}function s0(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(ki).join(`
`)}function r0(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function a0(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){const r=n.getActiveAttrib(e,s),a=r.name;let o=1;r.type===n.FLOAT_MAT2&&(o=2),r.type===n.FLOAT_MAT3&&(o=3),r.type===n.FLOAT_MAT4&&(o=4),t[a]={type:r.type,location:n.getAttribLocation(e,a),locationSize:o}}return t}function ki(n){return n!==""}function Pl(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Ll(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const o0=/^[ \t]*#include +<([\w\d./]+)>/gm;function La(n){return n.replace(o0,c0)}const l0=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function c0(n,e){let t=Xe[e];if(t===void 0){const i=l0.get(e);if(i!==void 0)t=Xe[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return La(t)}const h0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Il(n){return n.replace(h0,u0)}function u0(n,e,t,i){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Dl(n){let e="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function d0(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===vc?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===yc?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===Ln&&(e="SHADOWMAP_TYPE_VSM"),e}function f0(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Gi:case Hi:e="ENVMAP_TYPE_CUBE";break;case xr:e="ENVMAP_TYPE_CUBE_UV";break}return e}function p0(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Hi:e="ENVMAP_MODE_REFRACTION";break}return e}function m0(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case _c:e="ENVMAP_BLENDING_MULTIPLY";break;case Zh:e="ENVMAP_BLENDING_MIX";break;case Qh:e="ENVMAP_BLENDING_ADD";break}return e}function g0(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:i,maxMip:t}}function v0(n,e,t,i){const s=n.getContext(),r=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=d0(t),c=f0(t),h=p0(t),u=m0(t),d=g0(t),f=t.isWebGL2?"":i0(t),g=s0(t),v=r0(r),p=s.createProgram();let m,M,_=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,v].filter(ki).join(`
`),m.length>0&&(m+=`
`),M=[f,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,v].filter(ki).join(`
`),M.length>0&&(M+=`
`)):(m=[Dl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,v,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ki).join(`
`),M=[f,Dl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,v,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Wn?"#define TONE_MAPPING":"",t.toneMapping!==Wn?Xe.tonemapping_pars_fragment:"",t.toneMapping!==Wn?n0("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Xe.colorspace_pars_fragment,t0("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(ki).join(`
`)),a=La(a),a=Pl(a,t),a=Ll(a,t),o=La(o),o=Pl(o,t),o=Ll(o,t),a=Il(a),o=Il(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,m=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,M=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===Jo?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Jo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+M);const x=_+m+a,P=_+M+o,w=Cl(s,s.VERTEX_SHADER,x),A=Cl(s,s.FRAGMENT_SHADER,P);s.attachShader(p,w),s.attachShader(p,A),t.index0AttributeName!==void 0?s.bindAttribLocation(p,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(p,0,"position"),s.linkProgram(p);function N(F){if(n.debug.checkShaderErrors){const X=s.getProgramInfoLog(p).trim(),L=s.getShaderInfoLog(w).trim(),B=s.getShaderInfoLog(A).trim();let H=!0,Z=!0;if(s.getProgramParameter(p,s.LINK_STATUS)===!1)if(H=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,p,w,A);else{const J=Rl(s,w,"vertex"),j=Rl(s,A,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(p,s.VALIDATE_STATUS)+`

Program Info Log: `+X+`
`+J+`
`+j)}else X!==""?console.warn("THREE.WebGLProgram: Program Info Log:",X):(L===""||B==="")&&(Z=!1);Z&&(F.diagnostics={runnable:H,programLog:X,vertexShader:{log:L,prefix:m},fragmentShader:{log:B,prefix:M}})}s.deleteShader(w),s.deleteShader(A),y=new ir(s,p),S=a0(s,p)}let y;this.getUniforms=function(){return y===void 0&&N(this),y};let S;this.getAttributes=function(){return S===void 0&&N(this),S};let D=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return D===!1&&(D=s.getProgramParameter(p,Jm)),D},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(p),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Zm++,this.cacheKey=e,this.usedTimes=1,this.program=p,this.vertexShader=w,this.fragmentShader=A,this}let y0=0;class _0{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new M0(e),t.set(e,i)),i}}class M0{constructor(e){this.id=y0++,this.code=e,this.usedTimes=0}}function S0(n,e,t,i,s,r,a){const o=new Ka,l=new _0,c=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,d=s.vertexTextures;let f=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(y){return y===0?"uv":`uv${y}`}function p(y,S,D,F,X){const L=F.fog,B=X.geometry,H=y.isMeshStandardMaterial?F.environment:null,Z=(y.isMeshStandardMaterial?t:e).get(y.envMap||H),J=Z&&Z.mapping===xr?Z.image.height:null,j=g[y.type];y.precision!==null&&(f=s.getMaxPrecision(y.precision),f!==y.precision&&console.warn("THREE.WebGLProgram.getParameters:",y.precision,"not supported, using",f,"instead."));const ee=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,le=ee!==void 0?ee.length:0;let k=0;B.morphAttributes.position!==void 0&&(k=1),B.morphAttributes.normal!==void 0&&(k=2),B.morphAttributes.color!==void 0&&(k=3);let O,V,Q,te;if(j){const kt=Sn[j];O=kt.vertexShader,V=kt.fragmentShader}else O=y.vertexShader,V=y.fragmentShader,l.update(y),Q=l.getVertexShaderID(y),te=l.getFragmentShaderID(y);const he=n.getRenderTarget(),be=X.isInstancedMesh===!0,Pe=X.isBatchedMesh===!0,Se=!!y.map,De=!!y.matcap,I=!!Z,ce=!!y.aoMap,Y=!!y.lightMap,ie=!!y.bumpMap,K=!!y.normalMap,Ae=!!y.displacementMap,me=!!y.emissiveMap,T=!!y.metalnessMap,E=!!y.roughnessMap,G=y.anisotropy>0,ae=y.clearcoat>0,se=y.iridescence>0,ne=y.sheen>0,Ce=y.transmission>0,ge=G&&!!y.anisotropyMap,xe=ae&&!!y.clearcoatMap,Ue=ae&&!!y.clearcoatNormalMap,He=ae&&!!y.clearcoatRoughnessMap,re=se&&!!y.iridescenceMap,Qe=se&&!!y.iridescenceThicknessMap,Ke=ne&&!!y.sheenColorMap,ze=ne&&!!y.sheenRoughnessMap,Ie=!!y.specularMap,Te=!!y.specularColorMap,We=!!y.specularIntensityMap,tt=Ce&&!!y.transmissionMap,mt=Ce&&!!y.thicknessMap,qe=!!y.gradientMap,fe=!!y.alphaMap,U=y.alphaTest>0,ye=!!y.alphaHash,_e=!!y.extensions,ke=!!B.attributes.uv1,Ne=!!B.attributes.uv2,rt=!!B.attributes.uv3;let at=Wn;return y.toneMapped&&(he===null||he.isXRRenderTarget===!0)&&(at=n.toneMapping),{isWebGL2:h,shaderID:j,shaderType:y.type,shaderName:y.name,vertexShader:O,fragmentShader:V,defines:y.defines,customVertexShaderID:Q,customFragmentShaderID:te,isRawShaderMaterial:y.isRawShaderMaterial===!0,glslVersion:y.glslVersion,precision:f,batching:Pe,instancing:be,instancingColor:be&&X.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:he===null?n.outputColorSpace:he.isXRRenderTarget===!0?he.texture.colorSpace:Un,map:Se,matcap:De,envMap:I,envMapMode:I&&Z.mapping,envMapCubeUVHeight:J,aoMap:ce,lightMap:Y,bumpMap:ie,normalMap:K,displacementMap:d&&Ae,emissiveMap:me,normalMapObjectSpace:K&&y.normalMapType===gu,normalMapTangentSpace:K&&y.normalMapType===Pc,metalnessMap:T,roughnessMap:E,anisotropy:G,anisotropyMap:ge,clearcoat:ae,clearcoatMap:xe,clearcoatNormalMap:Ue,clearcoatRoughnessMap:He,iridescence:se,iridescenceMap:re,iridescenceThicknessMap:Qe,sheen:ne,sheenColorMap:Ke,sheenRoughnessMap:ze,specularMap:Ie,specularColorMap:Te,specularIntensityMap:We,transmission:Ce,transmissionMap:tt,thicknessMap:mt,gradientMap:qe,opaque:y.transparent===!1&&y.blending===ai,alphaMap:fe,alphaTest:U,alphaHash:ye,combine:y.combine,mapUv:Se&&v(y.map.channel),aoMapUv:ce&&v(y.aoMap.channel),lightMapUv:Y&&v(y.lightMap.channel),bumpMapUv:ie&&v(y.bumpMap.channel),normalMapUv:K&&v(y.normalMap.channel),displacementMapUv:Ae&&v(y.displacementMap.channel),emissiveMapUv:me&&v(y.emissiveMap.channel),metalnessMapUv:T&&v(y.metalnessMap.channel),roughnessMapUv:E&&v(y.roughnessMap.channel),anisotropyMapUv:ge&&v(y.anisotropyMap.channel),clearcoatMapUv:xe&&v(y.clearcoatMap.channel),clearcoatNormalMapUv:Ue&&v(y.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:He&&v(y.clearcoatRoughnessMap.channel),iridescenceMapUv:re&&v(y.iridescenceMap.channel),iridescenceThicknessMapUv:Qe&&v(y.iridescenceThicknessMap.channel),sheenColorMapUv:Ke&&v(y.sheenColorMap.channel),sheenRoughnessMapUv:ze&&v(y.sheenRoughnessMap.channel),specularMapUv:Ie&&v(y.specularMap.channel),specularColorMapUv:Te&&v(y.specularColorMap.channel),specularIntensityMapUv:We&&v(y.specularIntensityMap.channel),transmissionMapUv:tt&&v(y.transmissionMap.channel),thicknessMapUv:mt&&v(y.thicknessMap.channel),alphaMapUv:fe&&v(y.alphaMap.channel),vertexTangents:!!B.attributes.tangent&&(K||G),vertexColors:y.vertexColors,vertexAlphas:y.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,vertexUv1s:ke,vertexUv2s:Ne,vertexUv3s:rt,pointsUvs:X.isPoints===!0&&!!B.attributes.uv&&(Se||fe),fog:!!L,useFog:y.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:y.flatShading===!0,sizeAttenuation:y.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:X.isSkinnedMesh===!0,morphTargets:B.morphAttributes.position!==void 0,morphNormals:B.morphAttributes.normal!==void 0,morphColors:B.morphAttributes.color!==void 0,morphTargetsCount:le,morphTextureStride:k,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:y.dithering,shadowMapEnabled:n.shadowMap.enabled&&D.length>0,shadowMapType:n.shadowMap.type,toneMapping:at,useLegacyLights:n._useLegacyLights,decodeVideoTexture:Se&&y.map.isVideoTexture===!0&&nt.getTransfer(y.map.colorSpace)===lt,premultipliedAlpha:y.premultipliedAlpha,doubleSided:y.side===Xt,flipSided:y.side===qt,useDepthPacking:y.depthPacking>=0,depthPacking:y.depthPacking||0,index0AttributeName:y.index0AttributeName,extensionDerivatives:_e&&y.extensions.derivatives===!0,extensionFragDepth:_e&&y.extensions.fragDepth===!0,extensionDrawBuffers:_e&&y.extensions.drawBuffers===!0,extensionShaderTextureLOD:_e&&y.extensions.shaderTextureLOD===!0,extensionClipCullDistance:_e&&y.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:y.customProgramCacheKey()}}function m(y){const S=[];if(y.shaderID?S.push(y.shaderID):(S.push(y.customVertexShaderID),S.push(y.customFragmentShaderID)),y.defines!==void 0)for(const D in y.defines)S.push(D),S.push(y.defines[D]);return y.isRawShaderMaterial===!1&&(M(S,y),_(S,y),S.push(n.outputColorSpace)),S.push(y.customProgramCacheKey),S.join()}function M(y,S){y.push(S.precision),y.push(S.outputColorSpace),y.push(S.envMapMode),y.push(S.envMapCubeUVHeight),y.push(S.mapUv),y.push(S.alphaMapUv),y.push(S.lightMapUv),y.push(S.aoMapUv),y.push(S.bumpMapUv),y.push(S.normalMapUv),y.push(S.displacementMapUv),y.push(S.emissiveMapUv),y.push(S.metalnessMapUv),y.push(S.roughnessMapUv),y.push(S.anisotropyMapUv),y.push(S.clearcoatMapUv),y.push(S.clearcoatNormalMapUv),y.push(S.clearcoatRoughnessMapUv),y.push(S.iridescenceMapUv),y.push(S.iridescenceThicknessMapUv),y.push(S.sheenColorMapUv),y.push(S.sheenRoughnessMapUv),y.push(S.specularMapUv),y.push(S.specularColorMapUv),y.push(S.specularIntensityMapUv),y.push(S.transmissionMapUv),y.push(S.thicknessMapUv),y.push(S.combine),y.push(S.fogExp2),y.push(S.sizeAttenuation),y.push(S.morphTargetsCount),y.push(S.morphAttributeCount),y.push(S.numDirLights),y.push(S.numPointLights),y.push(S.numSpotLights),y.push(S.numSpotLightMaps),y.push(S.numHemiLights),y.push(S.numRectAreaLights),y.push(S.numDirLightShadows),y.push(S.numPointLightShadows),y.push(S.numSpotLightShadows),y.push(S.numSpotLightShadowsWithMaps),y.push(S.numLightProbes),y.push(S.shadowMapType),y.push(S.toneMapping),y.push(S.numClippingPlanes),y.push(S.numClipIntersection),y.push(S.depthPacking)}function _(y,S){o.disableAll(),S.isWebGL2&&o.enable(0),S.supportsVertexTextures&&o.enable(1),S.instancing&&o.enable(2),S.instancingColor&&o.enable(3),S.matcap&&o.enable(4),S.envMap&&o.enable(5),S.normalMapObjectSpace&&o.enable(6),S.normalMapTangentSpace&&o.enable(7),S.clearcoat&&o.enable(8),S.iridescence&&o.enable(9),S.alphaTest&&o.enable(10),S.vertexColors&&o.enable(11),S.vertexAlphas&&o.enable(12),S.vertexUv1s&&o.enable(13),S.vertexUv2s&&o.enable(14),S.vertexUv3s&&o.enable(15),S.vertexTangents&&o.enable(16),S.anisotropy&&o.enable(17),S.alphaHash&&o.enable(18),S.batching&&o.enable(19),y.push(o.mask),o.disableAll(),S.fog&&o.enable(0),S.useFog&&o.enable(1),S.flatShading&&o.enable(2),S.logarithmicDepthBuffer&&o.enable(3),S.skinning&&o.enable(4),S.morphTargets&&o.enable(5),S.morphNormals&&o.enable(6),S.morphColors&&o.enable(7),S.premultipliedAlpha&&o.enable(8),S.shadowMapEnabled&&o.enable(9),S.useLegacyLights&&o.enable(10),S.doubleSided&&o.enable(11),S.flipSided&&o.enable(12),S.useDepthPacking&&o.enable(13),S.dithering&&o.enable(14),S.transmission&&o.enable(15),S.sheen&&o.enable(16),S.opaque&&o.enable(17),S.pointsUvs&&o.enable(18),S.decodeVideoTexture&&o.enable(19),y.push(o.mask)}function x(y){const S=g[y.type];let D;if(S){const F=Sn[S];D=nd.clone(F.uniforms)}else D=y.uniforms;return D}function P(y,S){let D;for(let F=0,X=c.length;F<X;F++){const L=c[F];if(L.cacheKey===S){D=L,++D.usedTimes;break}}return D===void 0&&(D=new v0(n,S,y,r),c.push(D)),D}function w(y){if(--y.usedTimes===0){const S=c.indexOf(y);c[S]=c[c.length-1],c.pop(),y.destroy()}}function A(y){l.remove(y)}function N(){l.dispose()}return{getParameters:p,getProgramCacheKey:m,getUniforms:x,acquireProgram:P,releaseProgram:w,releaseShaderCache:A,programs:c,dispose:N}}function x0(){let n=new WeakMap;function e(r){let a=n.get(r);return a===void 0&&(a={},n.set(r,a)),a}function t(r){n.delete(r)}function i(r,a,o){n.get(r)[a]=o}function s(){n=new WeakMap}return{get:e,remove:t,update:i,dispose:s}}function b0(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function Ul(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function Nl(){const n=[];let e=0;const t=[],i=[],s=[];function r(){e=0,t.length=0,i.length=0,s.length=0}function a(u,d,f,g,v,p){let m=n[e];return m===void 0?(m={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:v,group:p},n[e]=m):(m.id=u.id,m.object=u,m.geometry=d,m.material=f,m.groupOrder=g,m.renderOrder=u.renderOrder,m.z=v,m.group=p),e++,m}function o(u,d,f,g,v,p){const m=a(u,d,f,g,v,p);f.transmission>0?i.push(m):f.transparent===!0?s.push(m):t.push(m)}function l(u,d,f,g,v,p){const m=a(u,d,f,g,v,p);f.transmission>0?i.unshift(m):f.transparent===!0?s.unshift(m):t.unshift(m)}function c(u,d){t.length>1&&t.sort(u||b0),i.length>1&&i.sort(d||Ul),s.length>1&&s.sort(d||Ul)}function h(){for(let u=e,d=n.length;u<d;u++){const f=n[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:i,transparent:s,init:r,push:o,unshift:l,finish:h,sort:c}}function E0(){let n=new WeakMap;function e(i,s){const r=n.get(i);let a;return r===void 0?(a=new Nl,n.set(i,[a])):s>=r.length?(a=new Nl,r.push(a)):a=r[s],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function w0(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new R,color:new Le};break;case"SpotLight":t={position:new R,direction:new R,color:new Le,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new R,color:new Le,distance:0,decay:0};break;case"HemisphereLight":t={direction:new R,skyColor:new Le,groundColor:new Le};break;case"RectAreaLight":t={color:new Le,position:new R,halfWidth:new R,halfHeight:new R};break}return n[e.id]=t,t}}}function T0(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ue};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ue};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ue,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let A0=0;function C0(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function R0(n,e){const t=new w0,i=T0(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new R);const r=new R,a=new pt,o=new pt;function l(h,u){let d=0,f=0,g=0;for(let F=0;F<9;F++)s.probe[F].set(0,0,0);let v=0,p=0,m=0,M=0,_=0,x=0,P=0,w=0,A=0,N=0,y=0;h.sort(C0);const S=u===!0?Math.PI:1;for(let F=0,X=h.length;F<X;F++){const L=h[F],B=L.color,H=L.intensity,Z=L.distance,J=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)d+=B.r*H*S,f+=B.g*H*S,g+=B.b*H*S;else if(L.isLightProbe){for(let j=0;j<9;j++)s.probe[j].addScaledVector(L.sh.coefficients[j],H);y++}else if(L.isDirectionalLight){const j=t.get(L);if(j.color.copy(L.color).multiplyScalar(L.intensity*S),L.castShadow){const ee=L.shadow,le=i.get(L);le.shadowBias=ee.bias,le.shadowNormalBias=ee.normalBias,le.shadowRadius=ee.radius,le.shadowMapSize=ee.mapSize,s.directionalShadow[v]=le,s.directionalShadowMap[v]=J,s.directionalShadowMatrix[v]=L.shadow.matrix,x++}s.directional[v]=j,v++}else if(L.isSpotLight){const j=t.get(L);j.position.setFromMatrixPosition(L.matrixWorld),j.color.copy(B).multiplyScalar(H*S),j.distance=Z,j.coneCos=Math.cos(L.angle),j.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),j.decay=L.decay,s.spot[m]=j;const ee=L.shadow;if(L.map&&(s.spotLightMap[A]=L.map,A++,ee.updateMatrices(L),L.castShadow&&N++),s.spotLightMatrix[m]=ee.matrix,L.castShadow){const le=i.get(L);le.shadowBias=ee.bias,le.shadowNormalBias=ee.normalBias,le.shadowRadius=ee.radius,le.shadowMapSize=ee.mapSize,s.spotShadow[m]=le,s.spotShadowMap[m]=J,w++}m++}else if(L.isRectAreaLight){const j=t.get(L);j.color.copy(B).multiplyScalar(H),j.halfWidth.set(L.width*.5,0,0),j.halfHeight.set(0,L.height*.5,0),s.rectArea[M]=j,M++}else if(L.isPointLight){const j=t.get(L);if(j.color.copy(L.color).multiplyScalar(L.intensity*S),j.distance=L.distance,j.decay=L.decay,L.castShadow){const ee=L.shadow,le=i.get(L);le.shadowBias=ee.bias,le.shadowNormalBias=ee.normalBias,le.shadowRadius=ee.radius,le.shadowMapSize=ee.mapSize,le.shadowCameraNear=ee.camera.near,le.shadowCameraFar=ee.camera.far,s.pointShadow[p]=le,s.pointShadowMap[p]=J,s.pointShadowMatrix[p]=L.shadow.matrix,P++}s.point[p]=j,p++}else if(L.isHemisphereLight){const j=t.get(L);j.skyColor.copy(L.color).multiplyScalar(H*S),j.groundColor.copy(L.groundColor).multiplyScalar(H*S),s.hemi[_]=j,_++}}M>0&&(e.isWebGL2?n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=pe.LTC_FLOAT_1,s.rectAreaLTC2=pe.LTC_FLOAT_2):(s.rectAreaLTC1=pe.LTC_HALF_1,s.rectAreaLTC2=pe.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=pe.LTC_FLOAT_1,s.rectAreaLTC2=pe.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=pe.LTC_HALF_1,s.rectAreaLTC2=pe.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=d,s.ambient[1]=f,s.ambient[2]=g;const D=s.hash;(D.directionalLength!==v||D.pointLength!==p||D.spotLength!==m||D.rectAreaLength!==M||D.hemiLength!==_||D.numDirectionalShadows!==x||D.numPointShadows!==P||D.numSpotShadows!==w||D.numSpotMaps!==A||D.numLightProbes!==y)&&(s.directional.length=v,s.spot.length=m,s.rectArea.length=M,s.point.length=p,s.hemi.length=_,s.directionalShadow.length=x,s.directionalShadowMap.length=x,s.pointShadow.length=P,s.pointShadowMap.length=P,s.spotShadow.length=w,s.spotShadowMap.length=w,s.directionalShadowMatrix.length=x,s.pointShadowMatrix.length=P,s.spotLightMatrix.length=w+A-N,s.spotLightMap.length=A,s.numSpotLightShadowsWithMaps=N,s.numLightProbes=y,D.directionalLength=v,D.pointLength=p,D.spotLength=m,D.rectAreaLength=M,D.hemiLength=_,D.numDirectionalShadows=x,D.numPointShadows=P,D.numSpotShadows=w,D.numSpotMaps=A,D.numLightProbes=y,s.version=A0++)}function c(h,u){let d=0,f=0,g=0,v=0,p=0;const m=u.matrixWorldInverse;for(let M=0,_=h.length;M<_;M++){const x=h[M];if(x.isDirectionalLight){const P=s.directional[d];P.direction.setFromMatrixPosition(x.matrixWorld),r.setFromMatrixPosition(x.target.matrixWorld),P.direction.sub(r),P.direction.transformDirection(m),d++}else if(x.isSpotLight){const P=s.spot[g];P.position.setFromMatrixPosition(x.matrixWorld),P.position.applyMatrix4(m),P.direction.setFromMatrixPosition(x.matrixWorld),r.setFromMatrixPosition(x.target.matrixWorld),P.direction.sub(r),P.direction.transformDirection(m),g++}else if(x.isRectAreaLight){const P=s.rectArea[v];P.position.setFromMatrixPosition(x.matrixWorld),P.position.applyMatrix4(m),o.identity(),a.copy(x.matrixWorld),a.premultiply(m),o.extractRotation(a),P.halfWidth.set(x.width*.5,0,0),P.halfHeight.set(0,x.height*.5,0),P.halfWidth.applyMatrix4(o),P.halfHeight.applyMatrix4(o),v++}else if(x.isPointLight){const P=s.point[f];P.position.setFromMatrixPosition(x.matrixWorld),P.position.applyMatrix4(m),f++}else if(x.isHemisphereLight){const P=s.hemi[p];P.direction.setFromMatrixPosition(x.matrixWorld),P.direction.transformDirection(m),p++}}}return{setup:l,setupView:c,state:s}}function Ol(n,e){const t=new R0(n,e),i=[],s=[];function r(){i.length=0,s.length=0}function a(u){i.push(u)}function o(u){s.push(u)}function l(u){t.setup(i,u)}function c(u){t.setupView(i,u)}return{init:r,state:{lightsArray:i,shadowsArray:s,lights:t},setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function P0(n,e){let t=new WeakMap;function i(r,a=0){const o=t.get(r);let l;return o===void 0?(l=new Ol(n,e),t.set(r,[l])):a>=o.length?(l=new Ol(n,e),o.push(l)):l=o[a],l}function s(){t=new WeakMap}return{get:i,dispose:s}}class L0 extends Ki{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=pu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class I0 extends Ki{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const D0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,U0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function N0(n,e,t){let i=new Ja;const s=new ue,r=new ue,a=new ct,o=new L0({depthPacking:mu}),l=new I0,c={},h=t.maxTextureSize,u={[qn]:qt,[qt]:qn,[Xt]:Xt},d=new fi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ue},radius:{value:4}},vertexShader:D0,fragmentShader:U0}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const g=new It;g.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new oe(g,d),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=vc;let m=this.type;this.render=function(w,A,N){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||w.length===0)return;const y=n.getRenderTarget(),S=n.getActiveCubeFace(),D=n.getActiveMipmapLevel(),F=n.state;F.setBlending(Vn),F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const X=m!==Ln&&this.type===Ln,L=m===Ln&&this.type!==Ln;for(let B=0,H=w.length;B<H;B++){const Z=w[B],J=Z.shadow;if(J===void 0){console.warn("THREE.WebGLShadowMap:",Z,"has no shadow.");continue}if(J.autoUpdate===!1&&J.needsUpdate===!1)continue;s.copy(J.mapSize);const j=J.getFrameExtents();if(s.multiply(j),r.copy(J.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/j.x),s.x=r.x*j.x,J.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/j.y),s.y=r.y*j.y,J.mapSize.y=r.y)),J.map===null||X===!0||L===!0){const le=this.type!==Ln?{minFilter:Vt,magFilter:Vt}:{};J.map!==null&&J.map.dispose(),J.map=new di(s.x,s.y,le),J.map.texture.name=Z.name+".shadowMap",J.camera.updateProjectionMatrix()}n.setRenderTarget(J.map),n.clear();const ee=J.getViewportCount();for(let le=0;le<ee;le++){const k=J.getViewport(le);a.set(r.x*k.x,r.y*k.y,r.x*k.z,r.y*k.w),F.viewport(a),J.updateMatrices(Z,le),i=J.getFrustum(),x(A,N,J.camera,Z,this.type)}J.isPointLightShadow!==!0&&this.type===Ln&&M(J,N),J.needsUpdate=!1}m=this.type,p.needsUpdate=!1,n.setRenderTarget(y,S,D)};function M(w,A){const N=e.update(v);d.defines.VSM_SAMPLES!==w.blurSamples&&(d.defines.VSM_SAMPLES=w.blurSamples,f.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),w.mapPass===null&&(w.mapPass=new di(s.x,s.y)),d.uniforms.shadow_pass.value=w.map.texture,d.uniforms.resolution.value=w.mapSize,d.uniforms.radius.value=w.radius,n.setRenderTarget(w.mapPass),n.clear(),n.renderBufferDirect(A,null,N,d,v,null),f.uniforms.shadow_pass.value=w.mapPass.texture,f.uniforms.resolution.value=w.mapSize,f.uniforms.radius.value=w.radius,n.setRenderTarget(w.map),n.clear(),n.renderBufferDirect(A,null,N,f,v,null)}function _(w,A,N,y){let S=null;const D=N.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(D!==void 0)S=D;else if(S=N.isPointLight===!0?l:o,n.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){const F=S.uuid,X=A.uuid;let L=c[F];L===void 0&&(L={},c[F]=L);let B=L[X];B===void 0&&(B=S.clone(),L[X]=B,A.addEventListener("dispose",P)),S=B}if(S.visible=A.visible,S.wireframe=A.wireframe,y===Ln?S.side=A.shadowSide!==null?A.shadowSide:A.side:S.side=A.shadowSide!==null?A.shadowSide:u[A.side],S.alphaMap=A.alphaMap,S.alphaTest=A.alphaTest,S.map=A.map,S.clipShadows=A.clipShadows,S.clippingPlanes=A.clippingPlanes,S.clipIntersection=A.clipIntersection,S.displacementMap=A.displacementMap,S.displacementScale=A.displacementScale,S.displacementBias=A.displacementBias,S.wireframeLinewidth=A.wireframeLinewidth,S.linewidth=A.linewidth,N.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const F=n.properties.get(S);F.light=N}return S}function x(w,A,N,y,S){if(w.visible===!1)return;if(w.layers.test(A.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&S===Ln)&&(!w.frustumCulled||i.intersectsObject(w))){w.modelViewMatrix.multiplyMatrices(N.matrixWorldInverse,w.matrixWorld);const X=e.update(w),L=w.material;if(Array.isArray(L)){const B=X.groups;for(let H=0,Z=B.length;H<Z;H++){const J=B[H],j=L[J.materialIndex];if(j&&j.visible){const ee=_(w,j,y,S);w.onBeforeShadow(n,w,A,N,X,ee,J),n.renderBufferDirect(N,null,X,ee,w,J),w.onAfterShadow(n,w,A,N,X,ee,J)}}}else if(L.visible){const B=_(w,L,y,S);w.onBeforeShadow(n,w,A,N,X,B,null),n.renderBufferDirect(N,null,X,B,w,null),w.onAfterShadow(n,w,A,N,X,B,null)}}const F=w.children;for(let X=0,L=F.length;X<L;X++)x(F[X],A,N,y,S)}function P(w){w.target.removeEventListener("dispose",P);for(const N in c){const y=c[N],S=w.target.uuid;S in y&&(y[S].dispose(),delete y[S])}}}function O0(n,e,t){const i=t.isWebGL2;function s(){let U=!1;const ye=new ct;let _e=null;const ke=new ct(0,0,0,0);return{setMask:function(Ne){_e!==Ne&&!U&&(n.colorMask(Ne,Ne,Ne,Ne),_e=Ne)},setLocked:function(Ne){U=Ne},setClear:function(Ne,rt,at,At,kt){kt===!0&&(Ne*=At,rt*=At,at*=At),ye.set(Ne,rt,at,At),ke.equals(ye)===!1&&(n.clearColor(Ne,rt,at,At),ke.copy(ye))},reset:function(){U=!1,_e=null,ke.set(-1,0,0,0)}}}function r(){let U=!1,ye=null,_e=null,ke=null;return{setTest:function(Ne){Ne?Pe(n.DEPTH_TEST):Se(n.DEPTH_TEST)},setMask:function(Ne){ye!==Ne&&!U&&(n.depthMask(Ne),ye=Ne)},setFunc:function(Ne){if(_e!==Ne){switch(Ne){case Xh:n.depthFunc(n.NEVER);break;case $h:n.depthFunc(n.ALWAYS);break;case qh:n.depthFunc(n.LESS);break;case ar:n.depthFunc(n.LEQUAL);break;case Yh:n.depthFunc(n.EQUAL);break;case jh:n.depthFunc(n.GEQUAL);break;case Kh:n.depthFunc(n.GREATER);break;case Jh:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}_e=Ne}},setLocked:function(Ne){U=Ne},setClear:function(Ne){ke!==Ne&&(n.clearDepth(Ne),ke=Ne)},reset:function(){U=!1,ye=null,_e=null,ke=null}}}function a(){let U=!1,ye=null,_e=null,ke=null,Ne=null,rt=null,at=null,At=null,kt=null;return{setTest:function(ot){U||(ot?Pe(n.STENCIL_TEST):Se(n.STENCIL_TEST))},setMask:function(ot){ye!==ot&&!U&&(n.stencilMask(ot),ye=ot)},setFunc:function(ot,Bt,yn){(_e!==ot||ke!==Bt||Ne!==yn)&&(n.stencilFunc(ot,Bt,yn),_e=ot,ke=Bt,Ne=yn)},setOp:function(ot,Bt,yn){(rt!==ot||at!==Bt||At!==yn)&&(n.stencilOp(ot,Bt,yn),rt=ot,at=Bt,At=yn)},setLocked:function(ot){U=ot},setClear:function(ot){kt!==ot&&(n.clearStencil(ot),kt=ot)},reset:function(){U=!1,ye=null,_e=null,ke=null,Ne=null,rt=null,at=null,At=null,kt=null}}}const o=new s,l=new r,c=new a,h=new WeakMap,u=new WeakMap;let d={},f={},g=new WeakMap,v=[],p=null,m=!1,M=null,_=null,x=null,P=null,w=null,A=null,N=null,y=new Le(0,0,0),S=0,D=!1,F=null,X=null,L=null,B=null,H=null;const Z=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let J=!1,j=0;const ee=n.getParameter(n.VERSION);ee.indexOf("WebGL")!==-1?(j=parseFloat(/^WebGL (\d)/.exec(ee)[1]),J=j>=1):ee.indexOf("OpenGL ES")!==-1&&(j=parseFloat(/^OpenGL ES (\d)/.exec(ee)[1]),J=j>=2);let le=null,k={};const O=n.getParameter(n.SCISSOR_BOX),V=n.getParameter(n.VIEWPORT),Q=new ct().fromArray(O),te=new ct().fromArray(V);function he(U,ye,_e,ke){const Ne=new Uint8Array(4),rt=n.createTexture();n.bindTexture(U,rt),n.texParameteri(U,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(U,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let at=0;at<_e;at++)i&&(U===n.TEXTURE_3D||U===n.TEXTURE_2D_ARRAY)?n.texImage3D(ye,0,n.RGBA,1,1,ke,0,n.RGBA,n.UNSIGNED_BYTE,Ne):n.texImage2D(ye+at,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Ne);return rt}const be={};be[n.TEXTURE_2D]=he(n.TEXTURE_2D,n.TEXTURE_2D,1),be[n.TEXTURE_CUBE_MAP]=he(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(be[n.TEXTURE_2D_ARRAY]=he(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),be[n.TEXTURE_3D]=he(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),l.setClear(1),c.setClear(0),Pe(n.DEPTH_TEST),l.setFunc(ar),me(!1),T(yo),Pe(n.CULL_FACE),K(Vn);function Pe(U){d[U]!==!0&&(n.enable(U),d[U]=!0)}function Se(U){d[U]!==!1&&(n.disable(U),d[U]=!1)}function De(U,ye){return f[U]!==ye?(n.bindFramebuffer(U,ye),f[U]=ye,i&&(U===n.DRAW_FRAMEBUFFER&&(f[n.FRAMEBUFFER]=ye),U===n.FRAMEBUFFER&&(f[n.DRAW_FRAMEBUFFER]=ye)),!0):!1}function I(U,ye){let _e=v,ke=!1;if(U)if(_e=g.get(ye),_e===void 0&&(_e=[],g.set(ye,_e)),U.isWebGLMultipleRenderTargets){const Ne=U.texture;if(_e.length!==Ne.length||_e[0]!==n.COLOR_ATTACHMENT0){for(let rt=0,at=Ne.length;rt<at;rt++)_e[rt]=n.COLOR_ATTACHMENT0+rt;_e.length=Ne.length,ke=!0}}else _e[0]!==n.COLOR_ATTACHMENT0&&(_e[0]=n.COLOR_ATTACHMENT0,ke=!0);else _e[0]!==n.BACK&&(_e[0]=n.BACK,ke=!0);ke&&(t.isWebGL2?n.drawBuffers(_e):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(_e))}function ce(U){return p!==U?(n.useProgram(U),p=U,!0):!1}const Y={[ii]:n.FUNC_ADD,[Ph]:n.FUNC_SUBTRACT,[Lh]:n.FUNC_REVERSE_SUBTRACT};if(i)Y[So]=n.MIN,Y[xo]=n.MAX;else{const U=e.get("EXT_blend_minmax");U!==null&&(Y[So]=U.MIN_EXT,Y[xo]=U.MAX_EXT)}const ie={[Ih]:n.ZERO,[Dh]:n.ONE,[Uh]:n.SRC_COLOR,[wa]:n.SRC_ALPHA,[zh]:n.SRC_ALPHA_SATURATE,[kh]:n.DST_COLOR,[Oh]:n.DST_ALPHA,[Nh]:n.ONE_MINUS_SRC_COLOR,[Ta]:n.ONE_MINUS_SRC_ALPHA,[Bh]:n.ONE_MINUS_DST_COLOR,[Fh]:n.ONE_MINUS_DST_ALPHA,[Gh]:n.CONSTANT_COLOR,[Hh]:n.ONE_MINUS_CONSTANT_COLOR,[Vh]:n.CONSTANT_ALPHA,[Wh]:n.ONE_MINUS_CONSTANT_ALPHA};function K(U,ye,_e,ke,Ne,rt,at,At,kt,ot){if(U===Vn){m===!0&&(Se(n.BLEND),m=!1);return}if(m===!1&&(Pe(n.BLEND),m=!0),U!==Rh){if(U!==M||ot!==D){if((_!==ii||w!==ii)&&(n.blendEquation(n.FUNC_ADD),_=ii,w=ii),ot)switch(U){case ai:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case un:n.blendFunc(n.ONE,n.ONE);break;case _o:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Mo:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case ai:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case un:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case _o:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Mo:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}x=null,P=null,A=null,N=null,y.set(0,0,0),S=0,M=U,D=ot}return}Ne=Ne||ye,rt=rt||_e,at=at||ke,(ye!==_||Ne!==w)&&(n.blendEquationSeparate(Y[ye],Y[Ne]),_=ye,w=Ne),(_e!==x||ke!==P||rt!==A||at!==N)&&(n.blendFuncSeparate(ie[_e],ie[ke],ie[rt],ie[at]),x=_e,P=ke,A=rt,N=at),(At.equals(y)===!1||kt!==S)&&(n.blendColor(At.r,At.g,At.b,kt),y.copy(At),S=kt),M=U,D=!1}function Ae(U,ye){U.side===Xt?Se(n.CULL_FACE):Pe(n.CULL_FACE);let _e=U.side===qt;ye&&(_e=!_e),me(_e),U.blending===ai&&U.transparent===!1?K(Vn):K(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),l.setFunc(U.depthFunc),l.setTest(U.depthTest),l.setMask(U.depthWrite),o.setMask(U.colorWrite);const ke=U.stencilWrite;c.setTest(ke),ke&&(c.setMask(U.stencilWriteMask),c.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),c.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),G(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?Pe(n.SAMPLE_ALPHA_TO_COVERAGE):Se(n.SAMPLE_ALPHA_TO_COVERAGE)}function me(U){F!==U&&(U?n.frontFace(n.CW):n.frontFace(n.CCW),F=U)}function T(U){U!==Ah?(Pe(n.CULL_FACE),U!==X&&(U===yo?n.cullFace(n.BACK):U===Ch?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):Se(n.CULL_FACE),X=U}function E(U){U!==L&&(J&&n.lineWidth(U),L=U)}function G(U,ye,_e){U?(Pe(n.POLYGON_OFFSET_FILL),(B!==ye||H!==_e)&&(n.polygonOffset(ye,_e),B=ye,H=_e)):Se(n.POLYGON_OFFSET_FILL)}function ae(U){U?Pe(n.SCISSOR_TEST):Se(n.SCISSOR_TEST)}function se(U){U===void 0&&(U=n.TEXTURE0+Z-1),le!==U&&(n.activeTexture(U),le=U)}function ne(U,ye,_e){_e===void 0&&(le===null?_e=n.TEXTURE0+Z-1:_e=le);let ke=k[_e];ke===void 0&&(ke={type:void 0,texture:void 0},k[_e]=ke),(ke.type!==U||ke.texture!==ye)&&(le!==_e&&(n.activeTexture(_e),le=_e),n.bindTexture(U,ye||be[U]),ke.type=U,ke.texture=ye)}function Ce(){const U=k[le];U!==void 0&&U.type!==void 0&&(n.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function ge(){try{n.compressedTexImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function xe(){try{n.compressedTexImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ue(){try{n.texSubImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function He(){try{n.texSubImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function re(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Qe(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ke(){try{n.texStorage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ze(){try{n.texStorage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ie(){try{n.texImage2D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Te(){try{n.texImage3D.apply(n,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function We(U){Q.equals(U)===!1&&(n.scissor(U.x,U.y,U.z,U.w),Q.copy(U))}function tt(U){te.equals(U)===!1&&(n.viewport(U.x,U.y,U.z,U.w),te.copy(U))}function mt(U,ye){let _e=u.get(ye);_e===void 0&&(_e=new WeakMap,u.set(ye,_e));let ke=_e.get(U);ke===void 0&&(ke=n.getUniformBlockIndex(ye,U.name),_e.set(U,ke))}function qe(U,ye){const ke=u.get(ye).get(U);h.get(ye)!==ke&&(n.uniformBlockBinding(ye,ke,U.__bindingPointIndex),h.set(ye,ke))}function fe(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),d={},le=null,k={},f={},g=new WeakMap,v=[],p=null,m=!1,M=null,_=null,x=null,P=null,w=null,A=null,N=null,y=new Le(0,0,0),S=0,D=!1,F=null,X=null,L=null,B=null,H=null,Q.set(0,0,n.canvas.width,n.canvas.height),te.set(0,0,n.canvas.width,n.canvas.height),o.reset(),l.reset(),c.reset()}return{buffers:{color:o,depth:l,stencil:c},enable:Pe,disable:Se,bindFramebuffer:De,drawBuffers:I,useProgram:ce,setBlending:K,setMaterial:Ae,setFlipSided:me,setCullFace:T,setLineWidth:E,setPolygonOffset:G,setScissorTest:ae,activeTexture:se,bindTexture:ne,unbindTexture:Ce,compressedTexImage2D:ge,compressedTexImage3D:xe,texImage2D:Ie,texImage3D:Te,updateUBOMapping:mt,uniformBlockBinding:qe,texStorage2D:Ke,texStorage3D:ze,texSubImage2D:Ue,texSubImage3D:He,compressedTexSubImage2D:re,compressedTexSubImage3D:Qe,scissor:We,viewport:tt,reset:fe}}function F0(n,e,t,i,s,r,a){const o=s.isWebGL2,l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap;let u;const d=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(T,E){return f?new OffscreenCanvas(T,E):pr("canvas")}function v(T,E,G,ae){let se=1;if((T.width>ae||T.height>ae)&&(se=ae/Math.max(T.width,T.height)),se<1||E===!0)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap){const ne=E?fr:Math.floor,Ce=ne(se*T.width),ge=ne(se*T.height);u===void 0&&(u=g(Ce,ge));const xe=G?g(Ce,ge):u;return xe.width=Ce,xe.height=ge,xe.getContext("2d").drawImage(T,0,0,Ce,ge),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+T.width+"x"+T.height+") to ("+Ce+"x"+ge+")."),xe}else return"data"in T&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+T.width+"x"+T.height+")."),T;return T}function p(T){return Pa(T.width)&&Pa(T.height)}function m(T){return o?!1:T.wrapS!==ln||T.wrapT!==ln||T.minFilter!==Vt&&T.minFilter!==on}function M(T,E){return T.generateMipmaps&&E&&T.minFilter!==Vt&&T.minFilter!==on}function _(T){n.generateMipmap(T)}function x(T,E,G,ae,se=!1){if(o===!1)return E;if(T!==null){if(n[T]!==void 0)return n[T];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let ne=E;if(E===n.RED&&(G===n.FLOAT&&(ne=n.R32F),G===n.HALF_FLOAT&&(ne=n.R16F),G===n.UNSIGNED_BYTE&&(ne=n.R8)),E===n.RED_INTEGER&&(G===n.UNSIGNED_BYTE&&(ne=n.R8UI),G===n.UNSIGNED_SHORT&&(ne=n.R16UI),G===n.UNSIGNED_INT&&(ne=n.R32UI),G===n.BYTE&&(ne=n.R8I),G===n.SHORT&&(ne=n.R16I),G===n.INT&&(ne=n.R32I)),E===n.RG&&(G===n.FLOAT&&(ne=n.RG32F),G===n.HALF_FLOAT&&(ne=n.RG16F),G===n.UNSIGNED_BYTE&&(ne=n.RG8)),E===n.RGBA){const Ce=se?cr:nt.getTransfer(ae);G===n.FLOAT&&(ne=n.RGBA32F),G===n.HALF_FLOAT&&(ne=n.RGBA16F),G===n.UNSIGNED_BYTE&&(ne=Ce===lt?n.SRGB8_ALPHA8:n.RGBA8),G===n.UNSIGNED_SHORT_4_4_4_4&&(ne=n.RGBA4),G===n.UNSIGNED_SHORT_5_5_5_1&&(ne=n.RGB5_A1)}return(ne===n.R16F||ne===n.R32F||ne===n.RG16F||ne===n.RG32F||ne===n.RGBA16F||ne===n.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function P(T,E,G){return M(T,G)===!0||T.isFramebufferTexture&&T.minFilter!==Vt&&T.minFilter!==on?Math.log2(Math.max(E.width,E.height))+1:T.mipmaps!==void 0&&T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?E.mipmaps.length:1}function w(T){return T===Vt||T===bo||T===Or?n.NEAREST:n.LINEAR}function A(T){const E=T.target;E.removeEventListener("dispose",A),y(E),E.isVideoTexture&&h.delete(E)}function N(T){const E=T.target;E.removeEventListener("dispose",N),D(E)}function y(T){const E=i.get(T);if(E.__webglInit===void 0)return;const G=T.source,ae=d.get(G);if(ae){const se=ae[E.__cacheKey];se.usedTimes--,se.usedTimes===0&&S(T),Object.keys(ae).length===0&&d.delete(G)}i.remove(T)}function S(T){const E=i.get(T);n.deleteTexture(E.__webglTexture);const G=T.source,ae=d.get(G);delete ae[E.__cacheKey],a.memory.textures--}function D(T){const E=T.texture,G=i.get(T),ae=i.get(E);if(ae.__webglTexture!==void 0&&(n.deleteTexture(ae.__webglTexture),a.memory.textures--),T.depthTexture&&T.depthTexture.dispose(),T.isWebGLCubeRenderTarget)for(let se=0;se<6;se++){if(Array.isArray(G.__webglFramebuffer[se]))for(let ne=0;ne<G.__webglFramebuffer[se].length;ne++)n.deleteFramebuffer(G.__webglFramebuffer[se][ne]);else n.deleteFramebuffer(G.__webglFramebuffer[se]);G.__webglDepthbuffer&&n.deleteRenderbuffer(G.__webglDepthbuffer[se])}else{if(Array.isArray(G.__webglFramebuffer))for(let se=0;se<G.__webglFramebuffer.length;se++)n.deleteFramebuffer(G.__webglFramebuffer[se]);else n.deleteFramebuffer(G.__webglFramebuffer);if(G.__webglDepthbuffer&&n.deleteRenderbuffer(G.__webglDepthbuffer),G.__webglMultisampledFramebuffer&&n.deleteFramebuffer(G.__webglMultisampledFramebuffer),G.__webglColorRenderbuffer)for(let se=0;se<G.__webglColorRenderbuffer.length;se++)G.__webglColorRenderbuffer[se]&&n.deleteRenderbuffer(G.__webglColorRenderbuffer[se]);G.__webglDepthRenderbuffer&&n.deleteRenderbuffer(G.__webglDepthRenderbuffer)}if(T.isWebGLMultipleRenderTargets)for(let se=0,ne=E.length;se<ne;se++){const Ce=i.get(E[se]);Ce.__webglTexture&&(n.deleteTexture(Ce.__webglTexture),a.memory.textures--),i.remove(E[se])}i.remove(E),i.remove(T)}let F=0;function X(){F=0}function L(){const T=F;return T>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+T+" texture units while this GPU supports only "+s.maxTextures),F+=1,T}function B(T){const E=[];return E.push(T.wrapS),E.push(T.wrapT),E.push(T.wrapR||0),E.push(T.magFilter),E.push(T.minFilter),E.push(T.anisotropy),E.push(T.internalFormat),E.push(T.format),E.push(T.type),E.push(T.generateMipmaps),E.push(T.premultiplyAlpha),E.push(T.flipY),E.push(T.unpackAlignment),E.push(T.colorSpace),E.join()}function H(T,E){const G=i.get(T);if(T.isVideoTexture&&Ae(T),T.isRenderTargetTexture===!1&&T.version>0&&G.__version!==T.version){const ae=T.image;if(ae===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(ae.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Q(G,T,E);return}}t.bindTexture(n.TEXTURE_2D,G.__webglTexture,n.TEXTURE0+E)}function Z(T,E){const G=i.get(T);if(T.version>0&&G.__version!==T.version){Q(G,T,E);return}t.bindTexture(n.TEXTURE_2D_ARRAY,G.__webglTexture,n.TEXTURE0+E)}function J(T,E){const G=i.get(T);if(T.version>0&&G.__version!==T.version){Q(G,T,E);return}t.bindTexture(n.TEXTURE_3D,G.__webglTexture,n.TEXTURE0+E)}function j(T,E){const G=i.get(T);if(T.version>0&&G.__version!==T.version){te(G,T,E);return}t.bindTexture(n.TEXTURE_CUBE_MAP,G.__webglTexture,n.TEXTURE0+E)}const ee={[lr]:n.REPEAT,[ln]:n.CLAMP_TO_EDGE,[Ca]:n.MIRRORED_REPEAT},le={[Vt]:n.NEAREST,[bo]:n.NEAREST_MIPMAP_NEAREST,[Or]:n.NEAREST_MIPMAP_LINEAR,[on]:n.LINEAR,[ru]:n.LINEAR_MIPMAP_NEAREST,[ps]:n.LINEAR_MIPMAP_LINEAR},k={[vu]:n.NEVER,[bu]:n.ALWAYS,[yu]:n.LESS,[Lc]:n.LEQUAL,[_u]:n.EQUAL,[xu]:n.GEQUAL,[Mu]:n.GREATER,[Su]:n.NOTEQUAL};function O(T,E,G){if(G?(n.texParameteri(T,n.TEXTURE_WRAP_S,ee[E.wrapS]),n.texParameteri(T,n.TEXTURE_WRAP_T,ee[E.wrapT]),(T===n.TEXTURE_3D||T===n.TEXTURE_2D_ARRAY)&&n.texParameteri(T,n.TEXTURE_WRAP_R,ee[E.wrapR]),n.texParameteri(T,n.TEXTURE_MAG_FILTER,le[E.magFilter]),n.texParameteri(T,n.TEXTURE_MIN_FILTER,le[E.minFilter])):(n.texParameteri(T,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(T,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(T===n.TEXTURE_3D||T===n.TEXTURE_2D_ARRAY)&&n.texParameteri(T,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(E.wrapS!==ln||E.wrapT!==ln)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(T,n.TEXTURE_MAG_FILTER,w(E.magFilter)),n.texParameteri(T,n.TEXTURE_MIN_FILTER,w(E.minFilter)),E.minFilter!==Vt&&E.minFilter!==on&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),E.compareFunction&&(n.texParameteri(T,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(T,n.TEXTURE_COMPARE_FUNC,k[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){const ae=e.get("EXT_texture_filter_anisotropic");if(E.magFilter===Vt||E.minFilter!==Or&&E.minFilter!==ps||E.type===Gn&&e.has("OES_texture_float_linear")===!1||o===!1&&E.type===ms&&e.has("OES_texture_half_float_linear")===!1)return;(E.anisotropy>1||i.get(E).__currentAnisotropy)&&(n.texParameterf(T,ae.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,s.getMaxAnisotropy())),i.get(E).__currentAnisotropy=E.anisotropy)}}function V(T,E){let G=!1;T.__webglInit===void 0&&(T.__webglInit=!0,E.addEventListener("dispose",A));const ae=E.source;let se=d.get(ae);se===void 0&&(se={},d.set(ae,se));const ne=B(E);if(ne!==T.__cacheKey){se[ne]===void 0&&(se[ne]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,G=!0),se[ne].usedTimes++;const Ce=se[T.__cacheKey];Ce!==void 0&&(se[T.__cacheKey].usedTimes--,Ce.usedTimes===0&&S(E)),T.__cacheKey=ne,T.__webglTexture=se[ne].texture}return G}function Q(T,E,G){let ae=n.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(ae=n.TEXTURE_2D_ARRAY),E.isData3DTexture&&(ae=n.TEXTURE_3D);const se=V(T,E),ne=E.source;t.bindTexture(ae,T.__webglTexture,n.TEXTURE0+G);const Ce=i.get(ne);if(ne.version!==Ce.__version||se===!0){t.activeTexture(n.TEXTURE0+G);const ge=nt.getPrimaries(nt.workingColorSpace),xe=E.colorSpace===cn?null:nt.getPrimaries(E.colorSpace),Ue=E.colorSpace===cn||ge===xe?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,E.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,E.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ue);const He=m(E)&&p(E.image)===!1;let re=v(E.image,He,!1,s.maxTextureSize);re=me(E,re);const Qe=p(re)||o,Ke=r.convert(E.format,E.colorSpace);let ze=r.convert(E.type),Ie=x(E.internalFormat,Ke,ze,E.colorSpace,E.isVideoTexture);O(ae,E,Qe);let Te;const We=E.mipmaps,tt=o&&E.isVideoTexture!==!0&&Ie!==Cc,mt=Ce.__version===void 0||se===!0,qe=P(E,re,Qe);if(E.isDepthTexture)Ie=n.DEPTH_COMPONENT,o?E.type===Gn?Ie=n.DEPTH_COMPONENT32F:E.type===zn?Ie=n.DEPTH_COMPONENT24:E.type===oi?Ie=n.DEPTH24_STENCIL8:Ie=n.DEPTH_COMPONENT16:E.type===Gn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),E.format===li&&Ie===n.DEPTH_COMPONENT&&E.type!==$a&&E.type!==zn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),E.type=zn,ze=r.convert(E.type)),E.format===Vi&&Ie===n.DEPTH_COMPONENT&&(Ie=n.DEPTH_STENCIL,E.type!==oi&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),E.type=oi,ze=r.convert(E.type))),mt&&(tt?t.texStorage2D(n.TEXTURE_2D,1,Ie,re.width,re.height):t.texImage2D(n.TEXTURE_2D,0,Ie,re.width,re.height,0,Ke,ze,null));else if(E.isDataTexture)if(We.length>0&&Qe){tt&&mt&&t.texStorage2D(n.TEXTURE_2D,qe,Ie,We[0].width,We[0].height);for(let fe=0,U=We.length;fe<U;fe++)Te=We[fe],tt?t.texSubImage2D(n.TEXTURE_2D,fe,0,0,Te.width,Te.height,Ke,ze,Te.data):t.texImage2D(n.TEXTURE_2D,fe,Ie,Te.width,Te.height,0,Ke,ze,Te.data);E.generateMipmaps=!1}else tt?(mt&&t.texStorage2D(n.TEXTURE_2D,qe,Ie,re.width,re.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,re.width,re.height,Ke,ze,re.data)):t.texImage2D(n.TEXTURE_2D,0,Ie,re.width,re.height,0,Ke,ze,re.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){tt&&mt&&t.texStorage3D(n.TEXTURE_2D_ARRAY,qe,Ie,We[0].width,We[0].height,re.depth);for(let fe=0,U=We.length;fe<U;fe++)Te=We[fe],E.format!==vn?Ke!==null?tt?t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,fe,0,0,0,Te.width,Te.height,re.depth,Ke,Te.data,0,0):t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,fe,Ie,Te.width,Te.height,re.depth,0,Te.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):tt?t.texSubImage3D(n.TEXTURE_2D_ARRAY,fe,0,0,0,Te.width,Te.height,re.depth,Ke,ze,Te.data):t.texImage3D(n.TEXTURE_2D_ARRAY,fe,Ie,Te.width,Te.height,re.depth,0,Ke,ze,Te.data)}else{tt&&mt&&t.texStorage2D(n.TEXTURE_2D,qe,Ie,We[0].width,We[0].height);for(let fe=0,U=We.length;fe<U;fe++)Te=We[fe],E.format!==vn?Ke!==null?tt?t.compressedTexSubImage2D(n.TEXTURE_2D,fe,0,0,Te.width,Te.height,Ke,Te.data):t.compressedTexImage2D(n.TEXTURE_2D,fe,Ie,Te.width,Te.height,0,Te.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):tt?t.texSubImage2D(n.TEXTURE_2D,fe,0,0,Te.width,Te.height,Ke,ze,Te.data):t.texImage2D(n.TEXTURE_2D,fe,Ie,Te.width,Te.height,0,Ke,ze,Te.data)}else if(E.isDataArrayTexture)tt?(mt&&t.texStorage3D(n.TEXTURE_2D_ARRAY,qe,Ie,re.width,re.height,re.depth),t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,re.width,re.height,re.depth,Ke,ze,re.data)):t.texImage3D(n.TEXTURE_2D_ARRAY,0,Ie,re.width,re.height,re.depth,0,Ke,ze,re.data);else if(E.isData3DTexture)tt?(mt&&t.texStorage3D(n.TEXTURE_3D,qe,Ie,re.width,re.height,re.depth),t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,re.width,re.height,re.depth,Ke,ze,re.data)):t.texImage3D(n.TEXTURE_3D,0,Ie,re.width,re.height,re.depth,0,Ke,ze,re.data);else if(E.isFramebufferTexture){if(mt)if(tt)t.texStorage2D(n.TEXTURE_2D,qe,Ie,re.width,re.height);else{let fe=re.width,U=re.height;for(let ye=0;ye<qe;ye++)t.texImage2D(n.TEXTURE_2D,ye,Ie,fe,U,0,Ke,ze,null),fe>>=1,U>>=1}}else if(We.length>0&&Qe){tt&&mt&&t.texStorage2D(n.TEXTURE_2D,qe,Ie,We[0].width,We[0].height);for(let fe=0,U=We.length;fe<U;fe++)Te=We[fe],tt?t.texSubImage2D(n.TEXTURE_2D,fe,0,0,Ke,ze,Te):t.texImage2D(n.TEXTURE_2D,fe,Ie,Ke,ze,Te);E.generateMipmaps=!1}else tt?(mt&&t.texStorage2D(n.TEXTURE_2D,qe,Ie,re.width,re.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,Ke,ze,re)):t.texImage2D(n.TEXTURE_2D,0,Ie,Ke,ze,re);M(E,Qe)&&_(ae),Ce.__version=ne.version,E.onUpdate&&E.onUpdate(E)}T.__version=E.version}function te(T,E,G){if(E.image.length!==6)return;const ae=V(T,E),se=E.source;t.bindTexture(n.TEXTURE_CUBE_MAP,T.__webglTexture,n.TEXTURE0+G);const ne=i.get(se);if(se.version!==ne.__version||ae===!0){t.activeTexture(n.TEXTURE0+G);const Ce=nt.getPrimaries(nt.workingColorSpace),ge=E.colorSpace===cn?null:nt.getPrimaries(E.colorSpace),xe=E.colorSpace===cn||Ce===ge?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,E.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,E.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,xe);const Ue=E.isCompressedTexture||E.image[0].isCompressedTexture,He=E.image[0]&&E.image[0].isDataTexture,re=[];for(let fe=0;fe<6;fe++)!Ue&&!He?re[fe]=v(E.image[fe],!1,!0,s.maxCubemapSize):re[fe]=He?E.image[fe].image:E.image[fe],re[fe]=me(E,re[fe]);const Qe=re[0],Ke=p(Qe)||o,ze=r.convert(E.format,E.colorSpace),Ie=r.convert(E.type),Te=x(E.internalFormat,ze,Ie,E.colorSpace),We=o&&E.isVideoTexture!==!0,tt=ne.__version===void 0||ae===!0;let mt=P(E,Qe,Ke);O(n.TEXTURE_CUBE_MAP,E,Ke);let qe;if(Ue){We&&tt&&t.texStorage2D(n.TEXTURE_CUBE_MAP,mt,Te,Qe.width,Qe.height);for(let fe=0;fe<6;fe++){qe=re[fe].mipmaps;for(let U=0;U<qe.length;U++){const ye=qe[U];E.format!==vn?ze!==null?We?t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U,0,0,ye.width,ye.height,ze,ye.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U,Te,ye.width,ye.height,0,ye.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):We?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U,0,0,ye.width,ye.height,ze,Ie,ye.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U,Te,ye.width,ye.height,0,ze,Ie,ye.data)}}}else{qe=E.mipmaps,We&&tt&&(qe.length>0&&mt++,t.texStorage2D(n.TEXTURE_CUBE_MAP,mt,Te,re[0].width,re[0].height));for(let fe=0;fe<6;fe++)if(He){We?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,re[fe].width,re[fe].height,ze,Ie,re[fe].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,Te,re[fe].width,re[fe].height,0,ze,Ie,re[fe].data);for(let U=0;U<qe.length;U++){const _e=qe[U].image[fe].image;We?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U+1,0,0,_e.width,_e.height,ze,Ie,_e.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U+1,Te,_e.width,_e.height,0,ze,Ie,_e.data)}}else{We?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,ze,Ie,re[fe]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,Te,ze,Ie,re[fe]);for(let U=0;U<qe.length;U++){const ye=qe[U];We?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U+1,0,0,ze,Ie,ye.image[fe]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,U+1,Te,ze,Ie,ye.image[fe])}}}M(E,Ke)&&_(n.TEXTURE_CUBE_MAP),ne.__version=se.version,E.onUpdate&&E.onUpdate(E)}T.__version=E.version}function he(T,E,G,ae,se,ne){const Ce=r.convert(G.format,G.colorSpace),ge=r.convert(G.type),xe=x(G.internalFormat,Ce,ge,G.colorSpace);if(!i.get(E).__hasExternalTextures){const He=Math.max(1,E.width>>ne),re=Math.max(1,E.height>>ne);se===n.TEXTURE_3D||se===n.TEXTURE_2D_ARRAY?t.texImage3D(se,ne,xe,He,re,E.depth,0,Ce,ge,null):t.texImage2D(se,ne,xe,He,re,0,Ce,ge,null)}t.bindFramebuffer(n.FRAMEBUFFER,T),K(E)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,ae,se,i.get(G).__webglTexture,0,ie(E)):(se===n.TEXTURE_2D||se>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&se<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,ae,se,i.get(G).__webglTexture,ne),t.bindFramebuffer(n.FRAMEBUFFER,null)}function be(T,E,G){if(n.bindRenderbuffer(n.RENDERBUFFER,T),E.depthBuffer&&!E.stencilBuffer){let ae=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(G||K(E)){const se=E.depthTexture;se&&se.isDepthTexture&&(se.type===Gn?ae=n.DEPTH_COMPONENT32F:se.type===zn&&(ae=n.DEPTH_COMPONENT24));const ne=ie(E);K(E)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ne,ae,E.width,E.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,ne,ae,E.width,E.height)}else n.renderbufferStorage(n.RENDERBUFFER,ae,E.width,E.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,T)}else if(E.depthBuffer&&E.stencilBuffer){const ae=ie(E);G&&K(E)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,ae,n.DEPTH24_STENCIL8,E.width,E.height):K(E)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ae,n.DEPTH24_STENCIL8,E.width,E.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,E.width,E.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,T)}else{const ae=E.isWebGLMultipleRenderTargets===!0?E.texture:[E.texture];for(let se=0;se<ae.length;se++){const ne=ae[se],Ce=r.convert(ne.format,ne.colorSpace),ge=r.convert(ne.type),xe=x(ne.internalFormat,Ce,ge,ne.colorSpace),Ue=ie(E);G&&K(E)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ue,xe,E.width,E.height):K(E)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ue,xe,E.width,E.height):n.renderbufferStorage(n.RENDERBUFFER,xe,E.width,E.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function Pe(T,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,T),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(E.depthTexture).__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),H(E.depthTexture,0);const ae=i.get(E.depthTexture).__webglTexture,se=ie(E);if(E.depthTexture.format===li)K(E)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,ae,0,se):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,ae,0);else if(E.depthTexture.format===Vi)K(E)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,ae,0,se):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,ae,0);else throw new Error("Unknown depthTexture format")}function Se(T){const E=i.get(T),G=T.isWebGLCubeRenderTarget===!0;if(T.depthTexture&&!E.__autoAllocateDepthBuffer){if(G)throw new Error("target.depthTexture not supported in Cube render targets");Pe(E.__webglFramebuffer,T)}else if(G){E.__webglDepthbuffer=[];for(let ae=0;ae<6;ae++)t.bindFramebuffer(n.FRAMEBUFFER,E.__webglFramebuffer[ae]),E.__webglDepthbuffer[ae]=n.createRenderbuffer(),be(E.__webglDepthbuffer[ae],T,!1)}else t.bindFramebuffer(n.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer=n.createRenderbuffer(),be(E.__webglDepthbuffer,T,!1);t.bindFramebuffer(n.FRAMEBUFFER,null)}function De(T,E,G){const ae=i.get(T);E!==void 0&&he(ae.__webglFramebuffer,T,T.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),G!==void 0&&Se(T)}function I(T){const E=T.texture,G=i.get(T),ae=i.get(E);T.addEventListener("dispose",N),T.isWebGLMultipleRenderTargets!==!0&&(ae.__webglTexture===void 0&&(ae.__webglTexture=n.createTexture()),ae.__version=E.version,a.memory.textures++);const se=T.isWebGLCubeRenderTarget===!0,ne=T.isWebGLMultipleRenderTargets===!0,Ce=p(T)||o;if(se){G.__webglFramebuffer=[];for(let ge=0;ge<6;ge++)if(o&&E.mipmaps&&E.mipmaps.length>0){G.__webglFramebuffer[ge]=[];for(let xe=0;xe<E.mipmaps.length;xe++)G.__webglFramebuffer[ge][xe]=n.createFramebuffer()}else G.__webglFramebuffer[ge]=n.createFramebuffer()}else{if(o&&E.mipmaps&&E.mipmaps.length>0){G.__webglFramebuffer=[];for(let ge=0;ge<E.mipmaps.length;ge++)G.__webglFramebuffer[ge]=n.createFramebuffer()}else G.__webglFramebuffer=n.createFramebuffer();if(ne)if(s.drawBuffers){const ge=T.texture;for(let xe=0,Ue=ge.length;xe<Ue;xe++){const He=i.get(ge[xe]);He.__webglTexture===void 0&&(He.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&T.samples>0&&K(T)===!1){const ge=ne?E:[E];G.__webglMultisampledFramebuffer=n.createFramebuffer(),G.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,G.__webglMultisampledFramebuffer);for(let xe=0;xe<ge.length;xe++){const Ue=ge[xe];G.__webglColorRenderbuffer[xe]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,G.__webglColorRenderbuffer[xe]);const He=r.convert(Ue.format,Ue.colorSpace),re=r.convert(Ue.type),Qe=x(Ue.internalFormat,He,re,Ue.colorSpace,T.isXRRenderTarget===!0),Ke=ie(T);n.renderbufferStorageMultisample(n.RENDERBUFFER,Ke,Qe,T.width,T.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+xe,n.RENDERBUFFER,G.__webglColorRenderbuffer[xe])}n.bindRenderbuffer(n.RENDERBUFFER,null),T.depthBuffer&&(G.__webglDepthRenderbuffer=n.createRenderbuffer(),be(G.__webglDepthRenderbuffer,T,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(se){t.bindTexture(n.TEXTURE_CUBE_MAP,ae.__webglTexture),O(n.TEXTURE_CUBE_MAP,E,Ce);for(let ge=0;ge<6;ge++)if(o&&E.mipmaps&&E.mipmaps.length>0)for(let xe=0;xe<E.mipmaps.length;xe++)he(G.__webglFramebuffer[ge][xe],T,E,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,xe);else he(G.__webglFramebuffer[ge],T,E,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0);M(E,Ce)&&_(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ne){const ge=T.texture;for(let xe=0,Ue=ge.length;xe<Ue;xe++){const He=ge[xe],re=i.get(He);t.bindTexture(n.TEXTURE_2D,re.__webglTexture),O(n.TEXTURE_2D,He,Ce),he(G.__webglFramebuffer,T,He,n.COLOR_ATTACHMENT0+xe,n.TEXTURE_2D,0),M(He,Ce)&&_(n.TEXTURE_2D)}t.unbindTexture()}else{let ge=n.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(o?ge=T.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(ge,ae.__webglTexture),O(ge,E,Ce),o&&E.mipmaps&&E.mipmaps.length>0)for(let xe=0;xe<E.mipmaps.length;xe++)he(G.__webglFramebuffer[xe],T,E,n.COLOR_ATTACHMENT0,ge,xe);else he(G.__webglFramebuffer,T,E,n.COLOR_ATTACHMENT0,ge,0);M(E,Ce)&&_(ge),t.unbindTexture()}T.depthBuffer&&Se(T)}function ce(T){const E=p(T)||o,G=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let ae=0,se=G.length;ae<se;ae++){const ne=G[ae];if(M(ne,E)){const Ce=T.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,ge=i.get(ne).__webglTexture;t.bindTexture(Ce,ge),_(Ce),t.unbindTexture()}}}function Y(T){if(o&&T.samples>0&&K(T)===!1){const E=T.isWebGLMultipleRenderTargets?T.texture:[T.texture],G=T.width,ae=T.height;let se=n.COLOR_BUFFER_BIT;const ne=[],Ce=T.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ge=i.get(T),xe=T.isWebGLMultipleRenderTargets===!0;if(xe)for(let Ue=0;Ue<E.length;Ue++)t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ue,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ue,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,ge.__webglMultisampledFramebuffer),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,ge.__webglFramebuffer);for(let Ue=0;Ue<E.length;Ue++){ne.push(n.COLOR_ATTACHMENT0+Ue),T.depthBuffer&&ne.push(Ce);const He=ge.__ignoreDepthValues!==void 0?ge.__ignoreDepthValues:!1;if(He===!1&&(T.depthBuffer&&(se|=n.DEPTH_BUFFER_BIT),T.stencilBuffer&&(se|=n.STENCIL_BUFFER_BIT)),xe&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,ge.__webglColorRenderbuffer[Ue]),He===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[Ce]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[Ce])),xe){const re=i.get(E[Ue]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,re,0)}n.blitFramebuffer(0,0,G,ae,0,0,G,ae,se,n.NEAREST),c&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,ne)}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),xe)for(let Ue=0;Ue<E.length;Ue++){t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ue,n.RENDERBUFFER,ge.__webglColorRenderbuffer[Ue]);const He=i.get(E[Ue]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ue,n.TEXTURE_2D,He,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,ge.__webglMultisampledFramebuffer)}}function ie(T){return Math.min(s.maxSamples,T.samples)}function K(T){const E=i.get(T);return o&&T.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function Ae(T){const E=a.render.frame;h.get(T)!==E&&(h.set(T,E),T.update())}function me(T,E){const G=T.colorSpace,ae=T.format,se=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||T.format===Ra||G!==Un&&G!==cn&&(nt.getTransfer(G)===lt?o===!1?e.has("EXT_sRGB")===!0&&ae===vn?(T.format=Ra,T.minFilter=on,T.generateMipmaps=!1):E=Dc.sRGBToLinear(E):(ae!==vn||se!==Xn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",G)),E}this.allocateTextureUnit=L,this.resetTextureUnits=X,this.setTexture2D=H,this.setTexture2DArray=Z,this.setTexture3D=J,this.setTextureCube=j,this.rebindTextures=De,this.setupRenderTarget=I,this.updateRenderTargetMipmap=ce,this.updateMultisampleRenderTarget=Y,this.setupDepthRenderbuffer=Se,this.setupFrameBufferTexture=he,this.useMultisampledRTT=K}function k0(n,e,t){const i=t.isWebGL2;function s(r,a=cn){let o;const l=nt.getTransfer(a);if(r===Xn)return n.UNSIGNED_BYTE;if(r===bc)return n.UNSIGNED_SHORT_4_4_4_4;if(r===Ec)return n.UNSIGNED_SHORT_5_5_5_1;if(r===au)return n.BYTE;if(r===ou)return n.SHORT;if(r===$a)return n.UNSIGNED_SHORT;if(r===xc)return n.INT;if(r===zn)return n.UNSIGNED_INT;if(r===Gn)return n.FLOAT;if(r===ms)return i?n.HALF_FLOAT:(o=e.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===lu)return n.ALPHA;if(r===vn)return n.RGBA;if(r===cu)return n.LUMINANCE;if(r===hu)return n.LUMINANCE_ALPHA;if(r===li)return n.DEPTH_COMPONENT;if(r===Vi)return n.DEPTH_STENCIL;if(r===Ra)return o=e.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===uu)return n.RED;if(r===wc)return n.RED_INTEGER;if(r===du)return n.RG;if(r===Tc)return n.RG_INTEGER;if(r===Ac)return n.RGBA_INTEGER;if(r===Fr||r===kr||r===Br||r===zr)if(l===lt)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===Fr)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===kr)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Br)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===zr)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===Fr)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===kr)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Br)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===zr)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Eo||r===wo||r===To||r===Ao)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===Eo)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===wo)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===To)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Ao)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Cc)return o=e.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===Co||r===Ro)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(r===Co)return l===lt?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===Ro)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===Po||r===Lo||r===Io||r===Do||r===Uo||r===No||r===Oo||r===Fo||r===ko||r===Bo||r===zo||r===Go||r===Ho||r===Vo)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(r===Po)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Lo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Io)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Do)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Uo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===No)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Oo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Fo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===ko)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Bo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===zo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Go)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Ho)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Vo)return l===lt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Gr||r===Wo||r===Xo)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(r===Gr)return l===lt?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Wo)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Xo)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===fu||r===$o||r===qo||r===Yo)if(o=e.get("EXT_texture_compression_rgtc"),o!==null){if(r===Gr)return o.COMPRESSED_RED_RGTC1_EXT;if(r===$o)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===qo)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Yo)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===oi?i?n.UNSIGNED_INT_24_8:(o=e.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[r]!==void 0?n[r]:null}return{convert:s}}class B0 extends Wt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class et extends _t{constructor(){super(),this.isGroup=!0,this.type="Group"}}const z0={type:"move"};class ha{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new et,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new et,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new et,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let s=null,r=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const v of e.hand.values()){const p=t.getJointPose(v,i),m=this._getHandJoint(c,v);p!==null&&(m.matrix.fromArray(p.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=p.radius),m.visible=p!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,i),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(s=t.getPose(e.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(z0)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new et;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class G0 extends ji{constructor(e,t){super();const i=this;let s=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null;const v=t.getContextAttributes();let p=null,m=null;const M=[],_=[],x=new ue;let P=null;const w=new Wt;w.layers.enable(1),w.viewport=new ct;const A=new Wt;A.layers.enable(2),A.viewport=new ct;const N=[w,A],y=new B0;y.layers.enable(1),y.layers.enable(2);let S=null,D=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(O){let V=M[O];return V===void 0&&(V=new ha,M[O]=V),V.getTargetRaySpace()},this.getControllerGrip=function(O){let V=M[O];return V===void 0&&(V=new ha,M[O]=V),V.getGripSpace()},this.getHand=function(O){let V=M[O];return V===void 0&&(V=new ha,M[O]=V),V.getHandSpace()};function F(O){const V=_.indexOf(O.inputSource);if(V===-1)return;const Q=M[V];Q!==void 0&&(Q.update(O.inputSource,O.frame,c||a),Q.dispatchEvent({type:O.type,data:O.inputSource}))}function X(){s.removeEventListener("select",F),s.removeEventListener("selectstart",F),s.removeEventListener("selectend",F),s.removeEventListener("squeeze",F),s.removeEventListener("squeezestart",F),s.removeEventListener("squeezeend",F),s.removeEventListener("end",X),s.removeEventListener("inputsourceschange",L);for(let O=0;O<M.length;O++){const V=_[O];V!==null&&(_[O]=null,M[O].disconnect(V))}S=null,D=null,e.setRenderTarget(p),f=null,d=null,u=null,s=null,m=null,k.stop(),i.isPresenting=!1,e.setPixelRatio(P),e.setSize(x.width,x.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(O){r=O,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(O){o=O,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(O){c=O},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(O){if(s=O,s!==null){if(p=e.getRenderTarget(),s.addEventListener("select",F),s.addEventListener("selectstart",F),s.addEventListener("selectend",F),s.addEventListener("squeeze",F),s.addEventListener("squeezestart",F),s.addEventListener("squeezeend",F),s.addEventListener("end",X),s.addEventListener("inputsourceschange",L),v.xrCompatible!==!0&&await t.makeXRCompatible(),P=e.getPixelRatio(),e.getSize(x),s.renderState.layers===void 0||e.capabilities.isWebGL2===!1){const V={antialias:s.renderState.layers===void 0?v.antialias:!0,alpha:!0,depth:v.depth,stencil:v.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,V),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),m=new di(f.framebufferWidth,f.framebufferHeight,{format:vn,type:Xn,colorSpace:e.outputColorSpace,stencilBuffer:v.stencil})}else{let V=null,Q=null,te=null;v.depth&&(te=v.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,V=v.stencil?Vi:li,Q=v.stencil?oi:zn);const he={colorFormat:t.RGBA8,depthFormat:te,scaleFactor:r};u=new XRWebGLBinding(s,t),d=u.createProjectionLayer(he),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),m=new di(d.textureWidth,d.textureHeight,{format:vn,type:Xn,depthTexture:new Wc(d.textureWidth,d.textureHeight,Q,void 0,void 0,void 0,void 0,void 0,void 0,V),stencilBuffer:v.stencil,colorSpace:e.outputColorSpace,samples:v.antialias?4:0});const be=e.properties.get(m);be.__ignoreDepthValues=d.ignoreDepthValues}m.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await s.requestReferenceSpace(o),k.setContext(s),k.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function L(O){for(let V=0;V<O.removed.length;V++){const Q=O.removed[V],te=_.indexOf(Q);te>=0&&(_[te]=null,M[te].disconnect(Q))}for(let V=0;V<O.added.length;V++){const Q=O.added[V];let te=_.indexOf(Q);if(te===-1){for(let be=0;be<M.length;be++)if(be>=_.length){_.push(Q),te=be;break}else if(_[be]===null){_[be]=Q,te=be;break}if(te===-1)break}const he=M[te];he&&he.connect(Q)}}const B=new R,H=new R;function Z(O,V,Q){B.setFromMatrixPosition(V.matrixWorld),H.setFromMatrixPosition(Q.matrixWorld);const te=B.distanceTo(H),he=V.projectionMatrix.elements,be=Q.projectionMatrix.elements,Pe=he[14]/(he[10]-1),Se=he[14]/(he[10]+1),De=(he[9]+1)/he[5],I=(he[9]-1)/he[5],ce=(he[8]-1)/he[0],Y=(be[8]+1)/be[0],ie=Pe*ce,K=Pe*Y,Ae=te/(-ce+Y),me=Ae*-ce;V.matrixWorld.decompose(O.position,O.quaternion,O.scale),O.translateX(me),O.translateZ(Ae),O.matrixWorld.compose(O.position,O.quaternion,O.scale),O.matrixWorldInverse.copy(O.matrixWorld).invert();const T=Pe+Ae,E=Se+Ae,G=ie-me,ae=K+(te-me),se=De*Se/E*T,ne=I*Se/E*T;O.projectionMatrix.makePerspective(G,ae,se,ne,T,E),O.projectionMatrixInverse.copy(O.projectionMatrix).invert()}function J(O,V){V===null?O.matrixWorld.copy(O.matrix):O.matrixWorld.multiplyMatrices(V.matrixWorld,O.matrix),O.matrixWorldInverse.copy(O.matrixWorld).invert()}this.updateCamera=function(O){if(s===null)return;y.near=A.near=w.near=O.near,y.far=A.far=w.far=O.far,(S!==y.near||D!==y.far)&&(s.updateRenderState({depthNear:y.near,depthFar:y.far}),S=y.near,D=y.far);const V=O.parent,Q=y.cameras;J(y,V);for(let te=0;te<Q.length;te++)J(Q[te],V);Q.length===2?Z(y,w,A):y.projectionMatrix.copy(w.projectionMatrix),j(O,y,V)};function j(O,V,Q){Q===null?O.matrix.copy(V.matrixWorld):(O.matrix.copy(Q.matrixWorld),O.matrix.invert(),O.matrix.multiply(V.matrixWorld)),O.matrix.decompose(O.position,O.quaternion,O.scale),O.updateMatrixWorld(!0),O.projectionMatrix.copy(V.projectionMatrix),O.projectionMatrixInverse.copy(V.projectionMatrixInverse),O.isPerspectiveCamera&&(O.fov=Wi*2*Math.atan(1/O.projectionMatrix.elements[5]),O.zoom=1)}this.getCamera=function(){return y},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(O){l=O,d!==null&&(d.fixedFoveation=O),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=O)};let ee=null;function le(O,V){if(h=V.getViewerPose(c||a),g=V,h!==null){const Q=h.views;f!==null&&(e.setRenderTargetFramebuffer(m,f.framebuffer),e.setRenderTarget(m));let te=!1;Q.length!==y.cameras.length&&(y.cameras.length=0,te=!0);for(let he=0;he<Q.length;he++){const be=Q[he];let Pe=null;if(f!==null)Pe=f.getViewport(be);else{const De=u.getViewSubImage(d,be);Pe=De.viewport,he===0&&(e.setRenderTargetTextures(m,De.colorTexture,d.ignoreDepthValues?void 0:De.depthStencilTexture),e.setRenderTarget(m))}let Se=N[he];Se===void 0&&(Se=new Wt,Se.layers.enable(he),Se.viewport=new ct,N[he]=Se),Se.matrix.fromArray(be.transform.matrix),Se.matrix.decompose(Se.position,Se.quaternion,Se.scale),Se.projectionMatrix.fromArray(be.projectionMatrix),Se.projectionMatrixInverse.copy(Se.projectionMatrix).invert(),Se.viewport.set(Pe.x,Pe.y,Pe.width,Pe.height),he===0&&(y.matrix.copy(Se.matrix),y.matrix.decompose(y.position,y.quaternion,y.scale)),te===!0&&y.cameras.push(Se)}}for(let Q=0;Q<M.length;Q++){const te=_[Q],he=M[Q];te!==null&&he!==void 0&&he.update(te,V,c||a)}ee&&ee(O,V),V.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:V}),g=null}const k=new Hc;k.setAnimationLoop(le),this.setAnimationLoop=function(O){ee=O},this.dispose=function(){}}}function H0(n,e){function t(p,m){p.matrixAutoUpdate===!0&&p.updateMatrix(),m.value.copy(p.matrix)}function i(p,m){m.color.getRGB(p.fogColor.value,Bc(n)),m.isFog?(p.fogNear.value=m.near,p.fogFar.value=m.far):m.isFogExp2&&(p.fogDensity.value=m.density)}function s(p,m,M,_,x){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(p,m):m.isMeshToonMaterial?(r(p,m),u(p,m)):m.isMeshPhongMaterial?(r(p,m),h(p,m)):m.isMeshStandardMaterial?(r(p,m),d(p,m),m.isMeshPhysicalMaterial&&f(p,m,x)):m.isMeshMatcapMaterial?(r(p,m),g(p,m)):m.isMeshDepthMaterial?r(p,m):m.isMeshDistanceMaterial?(r(p,m),v(p,m)):m.isMeshNormalMaterial?r(p,m):m.isLineBasicMaterial?(a(p,m),m.isLineDashedMaterial&&o(p,m)):m.isPointsMaterial?l(p,m,M,_):m.isSpriteMaterial?c(p,m):m.isShadowMaterial?(p.color.value.copy(m.color),p.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(p,m){p.opacity.value=m.opacity,m.color&&p.diffuse.value.copy(m.color),m.emissive&&p.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(p.map.value=m.map,t(m.map,p.mapTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,t(m.alphaMap,p.alphaMapTransform)),m.bumpMap&&(p.bumpMap.value=m.bumpMap,t(m.bumpMap,p.bumpMapTransform),p.bumpScale.value=m.bumpScale,m.side===qt&&(p.bumpScale.value*=-1)),m.normalMap&&(p.normalMap.value=m.normalMap,t(m.normalMap,p.normalMapTransform),p.normalScale.value.copy(m.normalScale),m.side===qt&&p.normalScale.value.negate()),m.displacementMap&&(p.displacementMap.value=m.displacementMap,t(m.displacementMap,p.displacementMapTransform),p.displacementScale.value=m.displacementScale,p.displacementBias.value=m.displacementBias),m.emissiveMap&&(p.emissiveMap.value=m.emissiveMap,t(m.emissiveMap,p.emissiveMapTransform)),m.specularMap&&(p.specularMap.value=m.specularMap,t(m.specularMap,p.specularMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest);const M=e.get(m).envMap;if(M&&(p.envMap.value=M,p.flipEnvMap.value=M.isCubeTexture&&M.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=m.reflectivity,p.ior.value=m.ior,p.refractionRatio.value=m.refractionRatio),m.lightMap){p.lightMap.value=m.lightMap;const _=n._useLegacyLights===!0?Math.PI:1;p.lightMapIntensity.value=m.lightMapIntensity*_,t(m.lightMap,p.lightMapTransform)}m.aoMap&&(p.aoMap.value=m.aoMap,p.aoMapIntensity.value=m.aoMapIntensity,t(m.aoMap,p.aoMapTransform))}function a(p,m){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,m.map&&(p.map.value=m.map,t(m.map,p.mapTransform))}function o(p,m){p.dashSize.value=m.dashSize,p.totalSize.value=m.dashSize+m.gapSize,p.scale.value=m.scale}function l(p,m,M,_){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,p.size.value=m.size*M,p.scale.value=_*.5,m.map&&(p.map.value=m.map,t(m.map,p.uvTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,t(m.alphaMap,p.alphaMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest)}function c(p,m){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,p.rotation.value=m.rotation,m.map&&(p.map.value=m.map,t(m.map,p.mapTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,t(m.alphaMap,p.alphaMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest)}function h(p,m){p.specular.value.copy(m.specular),p.shininess.value=Math.max(m.shininess,1e-4)}function u(p,m){m.gradientMap&&(p.gradientMap.value=m.gradientMap)}function d(p,m){p.metalness.value=m.metalness,m.metalnessMap&&(p.metalnessMap.value=m.metalnessMap,t(m.metalnessMap,p.metalnessMapTransform)),p.roughness.value=m.roughness,m.roughnessMap&&(p.roughnessMap.value=m.roughnessMap,t(m.roughnessMap,p.roughnessMapTransform)),e.get(m).envMap&&(p.envMapIntensity.value=m.envMapIntensity)}function f(p,m,M){p.ior.value=m.ior,m.sheen>0&&(p.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),p.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(p.sheenColorMap.value=m.sheenColorMap,t(m.sheenColorMap,p.sheenColorMapTransform)),m.sheenRoughnessMap&&(p.sheenRoughnessMap.value=m.sheenRoughnessMap,t(m.sheenRoughnessMap,p.sheenRoughnessMapTransform))),m.clearcoat>0&&(p.clearcoat.value=m.clearcoat,p.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(p.clearcoatMap.value=m.clearcoatMap,t(m.clearcoatMap,p.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,t(m.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(p.clearcoatNormalMap.value=m.clearcoatNormalMap,t(m.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===qt&&p.clearcoatNormalScale.value.negate())),m.iridescence>0&&(p.iridescence.value=m.iridescence,p.iridescenceIOR.value=m.iridescenceIOR,p.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(p.iridescenceMap.value=m.iridescenceMap,t(m.iridescenceMap,p.iridescenceMapTransform)),m.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=m.iridescenceThicknessMap,t(m.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),m.transmission>0&&(p.transmission.value=m.transmission,p.transmissionSamplerMap.value=M.texture,p.transmissionSamplerSize.value.set(M.width,M.height),m.transmissionMap&&(p.transmissionMap.value=m.transmissionMap,t(m.transmissionMap,p.transmissionMapTransform)),p.thickness.value=m.thickness,m.thicknessMap&&(p.thicknessMap.value=m.thicknessMap,t(m.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=m.attenuationDistance,p.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(p.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(p.anisotropyMap.value=m.anisotropyMap,t(m.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=m.specularIntensity,p.specularColor.value.copy(m.specularColor),m.specularColorMap&&(p.specularColorMap.value=m.specularColorMap,t(m.specularColorMap,p.specularColorMapTransform)),m.specularIntensityMap&&(p.specularIntensityMap.value=m.specularIntensityMap,t(m.specularIntensityMap,p.specularIntensityMapTransform))}function g(p,m){m.matcap&&(p.matcap.value=m.matcap)}function v(p,m){const M=e.get(m).light;p.referencePosition.value.setFromMatrixPosition(M.matrixWorld),p.nearDistance.value=M.shadow.camera.near,p.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function V0(n,e,t,i){let s={},r={},a=[];const o=t.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(M,_){const x=_.program;i.uniformBlockBinding(M,x)}function c(M,_){let x=s[M.id];x===void 0&&(g(M),x=h(M),s[M.id]=x,M.addEventListener("dispose",p));const P=_.program;i.updateUBOMapping(M,P);const w=e.render.frame;r[M.id]!==w&&(d(M),r[M.id]=w)}function h(M){const _=u();M.__bindingPointIndex=_;const x=n.createBuffer(),P=M.__size,w=M.usage;return n.bindBuffer(n.UNIFORM_BUFFER,x),n.bufferData(n.UNIFORM_BUFFER,P,w),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,_,x),x}function u(){for(let M=0;M<o;M++)if(a.indexOf(M)===-1)return a.push(M),M;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(M){const _=s[M.id],x=M.uniforms,P=M.__cache;n.bindBuffer(n.UNIFORM_BUFFER,_);for(let w=0,A=x.length;w<A;w++){const N=Array.isArray(x[w])?x[w]:[x[w]];for(let y=0,S=N.length;y<S;y++){const D=N[y];if(f(D,w,y,P)===!0){const F=D.__offset,X=Array.isArray(D.value)?D.value:[D.value];let L=0;for(let B=0;B<X.length;B++){const H=X[B],Z=v(H);typeof H=="number"||typeof H=="boolean"?(D.__data[0]=H,n.bufferSubData(n.UNIFORM_BUFFER,F+L,D.__data)):H.isMatrix3?(D.__data[0]=H.elements[0],D.__data[1]=H.elements[1],D.__data[2]=H.elements[2],D.__data[3]=0,D.__data[4]=H.elements[3],D.__data[5]=H.elements[4],D.__data[6]=H.elements[5],D.__data[7]=0,D.__data[8]=H.elements[6],D.__data[9]=H.elements[7],D.__data[10]=H.elements[8],D.__data[11]=0):(H.toArray(D.__data,L),L+=Z.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,F,D.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function f(M,_,x,P){const w=M.value,A=_+"_"+x;if(P[A]===void 0)return typeof w=="number"||typeof w=="boolean"?P[A]=w:P[A]=w.clone(),!0;{const N=P[A];if(typeof w=="number"||typeof w=="boolean"){if(N!==w)return P[A]=w,!0}else if(N.equals(w)===!1)return N.copy(w),!0}return!1}function g(M){const _=M.uniforms;let x=0;const P=16;for(let A=0,N=_.length;A<N;A++){const y=Array.isArray(_[A])?_[A]:[_[A]];for(let S=0,D=y.length;S<D;S++){const F=y[S],X=Array.isArray(F.value)?F.value:[F.value];for(let L=0,B=X.length;L<B;L++){const H=X[L],Z=v(H),J=x%P;J!==0&&P-J<Z.boundary&&(x+=P-J),F.__data=new Float32Array(Z.storage/Float32Array.BYTES_PER_ELEMENT),F.__offset=x,x+=Z.storage}}}const w=x%P;return w>0&&(x+=P-w),M.__size=x,M.__cache={},this}function v(M){const _={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(_.boundary=4,_.storage=4):M.isVector2?(_.boundary=8,_.storage=8):M.isVector3||M.isColor?(_.boundary=16,_.storage=12):M.isVector4?(_.boundary=16,_.storage=16):M.isMatrix3?(_.boundary=48,_.storage=48):M.isMatrix4?(_.boundary=64,_.storage=64):M.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",M),_}function p(M){const _=M.target;_.removeEventListener("dispose",p);const x=a.indexOf(_.__bindingPointIndex);a.splice(x,1),n.deleteBuffer(s[_.id]),delete s[_.id],delete r[_.id]}function m(){for(const M in s)n.deleteBuffer(s[M]);a=[],s={},r={}}return{bind:l,update:c,dispose:m}}class Kc{constructor(e={}){const{canvas:t=ku(),context:i=null,depth:s=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=e;this.isWebGLRenderer=!0;let d;i!==null?d=i.getContextAttributes().alpha:d=a;const f=new Uint32Array(4),g=new Int32Array(4);let v=null,p=null;const m=[],M=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=dt,this._useLegacyLights=!1,this.toneMapping=Wn,this.toneMappingExposure=1;const _=this;let x=!1,P=0,w=0,A=null,N=-1,y=null;const S=new ct,D=new ct;let F=null;const X=new Le(0);let L=0,B=t.width,H=t.height,Z=1,J=null,j=null;const ee=new ct(0,0,B,H),le=new ct(0,0,B,H);let k=!1;const O=new Ja;let V=!1,Q=!1,te=null;const he=new pt,be=new ue,Pe=new R,Se={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function De(){return A===null?Z:1}let I=i;function ce(C,z){for(let $=0;$<C.length;$++){const q=C[$],W=t.getContext(q,z);if(W!==null)return W}return null}try{const C={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Sr}`),t.addEventListener("webglcontextlost",fe,!1),t.addEventListener("webglcontextrestored",U,!1),t.addEventListener("webglcontextcreationerror",ye,!1),I===null){const z=["webgl2","webgl","experimental-webgl"];if(_.isWebGL1Renderer===!0&&z.shift(),I=ce(z,C),I===null)throw ce(z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&I instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),I.getShaderPrecisionFormat===void 0&&(I.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let Y,ie,K,Ae,me,T,E,G,ae,se,ne,Ce,ge,xe,Ue,He,re,Qe,Ke,ze,Ie,Te,We,tt;function mt(){Y=new Qp(I),ie=new qp(I,Y,e),Y.init(ie),Te=new k0(I,Y,ie),K=new O0(I,Y,ie),Ae=new nm(I),me=new x0,T=new F0(I,Y,K,me,ie,Te,Ae),E=new jp(_),G=new Zp(_),ae=new cd(I,ie),We=new Xp(I,Y,ae,ie),se=new em(I,ae,Ae,We),ne=new am(I,se,ae,Ae),Ke=new rm(I,ie,T),He=new Yp(me),Ce=new S0(_,E,G,Y,ie,We,He),ge=new H0(_,me),xe=new E0,Ue=new P0(Y,ie),Qe=new Wp(_,E,G,K,ne,d,l),re=new N0(_,ne,ie),tt=new V0(I,Ae,ie,K),ze=new $p(I,Y,Ae,ie),Ie=new tm(I,Y,Ae,ie),Ae.programs=Ce.programs,_.capabilities=ie,_.extensions=Y,_.properties=me,_.renderLists=xe,_.shadowMap=re,_.state=K,_.info=Ae}mt();const qe=new G0(_,I);this.xr=qe,this.getContext=function(){return I},this.getContextAttributes=function(){return I.getContextAttributes()},this.forceContextLoss=function(){const C=Y.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=Y.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Z},this.setPixelRatio=function(C){C!==void 0&&(Z=C,this.setSize(B,H,!1))},this.getSize=function(C){return C.set(B,H)},this.setSize=function(C,z,$=!0){if(qe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}B=C,H=z,t.width=Math.floor(C*Z),t.height=Math.floor(z*Z),$===!0&&(t.style.width=C+"px",t.style.height=z+"px"),this.setViewport(0,0,C,z)},this.getDrawingBufferSize=function(C){return C.set(B*Z,H*Z).floor()},this.setDrawingBufferSize=function(C,z,$){B=C,H=z,Z=$,t.width=Math.floor(C*$),t.height=Math.floor(z*$),this.setViewport(0,0,C,z)},this.getCurrentViewport=function(C){return C.copy(S)},this.getViewport=function(C){return C.copy(ee)},this.setViewport=function(C,z,$,q){C.isVector4?ee.set(C.x,C.y,C.z,C.w):ee.set(C,z,$,q),K.viewport(S.copy(ee).multiplyScalar(Z).floor())},this.getScissor=function(C){return C.copy(le)},this.setScissor=function(C,z,$,q){C.isVector4?le.set(C.x,C.y,C.z,C.w):le.set(C,z,$,q),K.scissor(D.copy(le).multiplyScalar(Z).floor())},this.getScissorTest=function(){return k},this.setScissorTest=function(C){K.setScissorTest(k=C)},this.setOpaqueSort=function(C){J=C},this.setTransparentSort=function(C){j=C},this.getClearColor=function(C){return C.copy(Qe.getClearColor())},this.setClearColor=function(){Qe.setClearColor.apply(Qe,arguments)},this.getClearAlpha=function(){return Qe.getClearAlpha()},this.setClearAlpha=function(){Qe.setClearAlpha.apply(Qe,arguments)},this.clear=function(C=!0,z=!0,$=!0){let q=0;if(C){let W=!1;if(A!==null){const Me=A.texture.format;W=Me===Ac||Me===Tc||Me===wc}if(W){const Me=A.texture.type,Re=Me===Xn||Me===zn||Me===$a||Me===oi||Me===bc||Me===Ec,Oe=Qe.getClearColor(),Be=Qe.getClearAlpha(),$e=Oe.r,Ge=Oe.g,Ve=Oe.b;Re?(f[0]=$e,f[1]=Ge,f[2]=Ve,f[3]=Be,I.clearBufferuiv(I.COLOR,0,f)):(g[0]=$e,g[1]=Ge,g[2]=Ve,g[3]=Be,I.clearBufferiv(I.COLOR,0,g))}else q|=I.COLOR_BUFFER_BIT}z&&(q|=I.DEPTH_BUFFER_BIT),$&&(q|=I.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),I.clear(q)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",fe,!1),t.removeEventListener("webglcontextrestored",U,!1),t.removeEventListener("webglcontextcreationerror",ye,!1),xe.dispose(),Ue.dispose(),me.dispose(),E.dispose(),G.dispose(),ne.dispose(),We.dispose(),tt.dispose(),Ce.dispose(),qe.dispose(),qe.removeEventListener("sessionstart",kt),qe.removeEventListener("sessionend",ot),te&&(te.dispose(),te=null),Bt.stop()};function fe(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),x=!0}function U(){console.log("THREE.WebGLRenderer: Context Restored."),x=!1;const C=Ae.autoReset,z=re.enabled,$=re.autoUpdate,q=re.needsUpdate,W=re.type;mt(),Ae.autoReset=C,re.enabled=z,re.autoUpdate=$,re.needsUpdate=q,re.type=W}function ye(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function _e(C){const z=C.target;z.removeEventListener("dispose",_e),ke(z)}function ke(C){Ne(C),me.remove(C)}function Ne(C){const z=me.get(C).programs;z!==void 0&&(z.forEach(function($){Ce.releaseProgram($)}),C.isShaderMaterial&&Ce.releaseShaderCache(C))}this.renderBufferDirect=function(C,z,$,q,W,Me){z===null&&(z=Se);const Re=W.isMesh&&W.matrixWorld.determinant()<0,Oe=bh(C,z,$,q,W);K.setMaterial(q,Re);let Be=$.index,$e=1;if(q.wireframe===!0){if(Be=se.getWireframeAttribute($),Be===void 0)return;$e=2}const Ge=$.drawRange,Ve=$.attributes.position;let Mt=Ge.start*$e,Jt=(Ge.start+Ge.count)*$e;Me!==null&&(Mt=Math.max(Mt,Me.start*$e),Jt=Math.min(Jt,(Me.start+Me.count)*$e)),Be!==null?(Mt=Math.max(Mt,0),Jt=Math.min(Jt,Be.count)):Ve!=null&&(Mt=Math.max(Mt,0),Jt=Math.min(Jt,Ve.count));const Ct=Jt-Mt;if(Ct<0||Ct===1/0)return;We.setup(W,q,Oe,$,Be);let wn,ht=ze;if(Be!==null&&(wn=ae.get(Be),ht=Ie,ht.setIndex(wn)),W.isMesh)q.wireframe===!0?(K.setLineWidth(q.wireframeLinewidth*De()),ht.setMode(I.LINES)):ht.setMode(I.TRIANGLES);else if(W.isLine){let Ye=q.linewidth;Ye===void 0&&(Ye=1),K.setLineWidth(Ye*De()),W.isLineSegments?ht.setMode(I.LINES):W.isLineLoop?ht.setMode(I.LINE_LOOP):ht.setMode(I.LINE_STRIP)}else W.isPoints?ht.setMode(I.POINTS):W.isSprite&&ht.setMode(I.TRIANGLES);if(W.isBatchedMesh)ht.renderMultiDraw(W._multiDrawStarts,W._multiDrawCounts,W._multiDrawCount);else if(W.isInstancedMesh)ht.renderInstances(Mt,Ct,W.count);else if($.isInstancedBufferGeometry){const Ye=$._maxInstanceCount!==void 0?$._maxInstanceCount:1/0,Ir=Math.min($.instanceCount,Ye);ht.renderInstances(Mt,Ct,Ir)}else ht.render(Mt,Ct)};function rt(C,z,$){C.transparent===!0&&C.side===Xt&&C.forceSinglePass===!1?(C.side=qt,C.needsUpdate=!0,Ts(C,z,$),C.side=qn,C.needsUpdate=!0,Ts(C,z,$),C.side=Xt):Ts(C,z,$)}this.compile=function(C,z,$=null){$===null&&($=C),p=Ue.get($),p.init(),M.push(p),$.traverseVisible(function(W){W.isLight&&W.layers.test(z.layers)&&(p.pushLight(W),W.castShadow&&p.pushShadow(W))}),C!==$&&C.traverseVisible(function(W){W.isLight&&W.layers.test(z.layers)&&(p.pushLight(W),W.castShadow&&p.pushShadow(W))}),p.setupLights(_._useLegacyLights);const q=new Set;return C.traverse(function(W){const Me=W.material;if(Me)if(Array.isArray(Me))for(let Re=0;Re<Me.length;Re++){const Oe=Me[Re];rt(Oe,$,W),q.add(Oe)}else rt(Me,$,W),q.add(Me)}),M.pop(),p=null,q},this.compileAsync=function(C,z,$=null){const q=this.compile(C,z,$);return new Promise(W=>{function Me(){if(q.forEach(function(Re){me.get(Re).currentProgram.isReady()&&q.delete(Re)}),q.size===0){W(C);return}setTimeout(Me,10)}Y.get("KHR_parallel_shader_compile")!==null?Me():setTimeout(Me,10)})};let at=null;function At(C){at&&at(C)}function kt(){Bt.stop()}function ot(){Bt.start()}const Bt=new Hc;Bt.setAnimationLoop(At),typeof self<"u"&&Bt.setContext(self),this.setAnimationLoop=function(C){at=C,qe.setAnimationLoop(C),C===null?Bt.stop():Bt.start()},qe.addEventListener("sessionstart",kt),qe.addEventListener("sessionend",ot),this.render=function(C,z){if(z!==void 0&&z.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(x===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),z.parent===null&&z.matrixWorldAutoUpdate===!0&&z.updateMatrixWorld(),qe.enabled===!0&&qe.isPresenting===!0&&(qe.cameraAutoUpdate===!0&&qe.updateCamera(z),z=qe.getCamera()),C.isScene===!0&&C.onBeforeRender(_,C,z,A),p=Ue.get(C,M.length),p.init(),M.push(p),he.multiplyMatrices(z.projectionMatrix,z.matrixWorldInverse),O.setFromProjectionMatrix(he),Q=this.localClippingEnabled,V=He.init(this.clippingPlanes,Q),v=xe.get(C,m.length),v.init(),m.push(v),yn(C,z,0,_.sortObjects),v.finish(),_.sortObjects===!0&&v.sort(J,j),this.info.render.frame++,V===!0&&He.beginShadows();const $=p.state.shadowsArray;if(re.render($,C,z),V===!0&&He.endShadows(),this.info.autoReset===!0&&this.info.reset(),Qe.render(v,C),p.setupLights(_._useLegacyLights),z.isArrayCamera){const q=z.cameras;for(let W=0,Me=q.length;W<Me;W++){const Re=q[W];uo(v,C,Re,Re.viewport)}}else uo(v,C,z);A!==null&&(T.updateMultisampleRenderTarget(A),T.updateRenderTargetMipmap(A)),C.isScene===!0&&C.onAfterRender(_,C,z),We.resetDefaultState(),N=-1,y=null,M.pop(),M.length>0?p=M[M.length-1]:p=null,m.pop(),m.length>0?v=m[m.length-1]:v=null};function yn(C,z,$,q){if(C.visible===!1)return;if(C.layers.test(z.layers)){if(C.isGroup)$=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(z);else if(C.isLight)p.pushLight(C),C.castShadow&&p.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||O.intersectsSprite(C)){q&&Pe.setFromMatrixPosition(C.matrixWorld).applyMatrix4(he);const Re=ne.update(C),Oe=C.material;Oe.visible&&v.push(C,Re,Oe,$,Pe.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||O.intersectsObject(C))){const Re=ne.update(C),Oe=C.material;if(q&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),Pe.copy(C.boundingSphere.center)):(Re.boundingSphere===null&&Re.computeBoundingSphere(),Pe.copy(Re.boundingSphere.center)),Pe.applyMatrix4(C.matrixWorld).applyMatrix4(he)),Array.isArray(Oe)){const Be=Re.groups;for(let $e=0,Ge=Be.length;$e<Ge;$e++){const Ve=Be[$e],Mt=Oe[Ve.materialIndex];Mt&&Mt.visible&&v.push(C,Re,Mt,$,Pe.z,Ve)}}else Oe.visible&&v.push(C,Re,Oe,$,Pe.z,null)}}const Me=C.children;for(let Re=0,Oe=Me.length;Re<Oe;Re++)yn(Me[Re],z,$,q)}function uo(C,z,$,q){const W=C.opaque,Me=C.transmissive,Re=C.transparent;p.setupLightsView($),V===!0&&He.setGlobalState(_.clippingPlanes,$),Me.length>0&&xh(W,Me,z,$),q&&K.viewport(S.copy(q)),W.length>0&&ws(W,z,$),Me.length>0&&ws(Me,z,$),Re.length>0&&ws(Re,z,$),K.buffers.depth.setTest(!0),K.buffers.depth.setMask(!0),K.buffers.color.setMask(!0),K.setPolygonOffset(!1)}function xh(C,z,$,q){if(($.isScene===!0?$.overrideMaterial:null)!==null)return;const Me=ie.isWebGL2;te===null&&(te=new di(1,1,{generateMipmaps:!0,type:Y.has("EXT_color_buffer_half_float")?ms:Xn,minFilter:ps,samples:Me?4:0})),_.getDrawingBufferSize(be),Me?te.setSize(be.x,be.y):te.setSize(fr(be.x),fr(be.y));const Re=_.getRenderTarget();_.setRenderTarget(te),_.getClearColor(X),L=_.getClearAlpha(),L<1&&_.setClearColor(16777215,.5),_.clear();const Oe=_.toneMapping;_.toneMapping=Wn,ws(C,$,q),T.updateMultisampleRenderTarget(te),T.updateRenderTargetMipmap(te);let Be=!1;for(let $e=0,Ge=z.length;$e<Ge;$e++){const Ve=z[$e],Mt=Ve.object,Jt=Ve.geometry,Ct=Ve.material,wn=Ve.group;if(Ct.side===Xt&&Mt.layers.test(q.layers)){const ht=Ct.side;Ct.side=qt,Ct.needsUpdate=!0,fo(Mt,$,q,Jt,Ct,wn),Ct.side=ht,Ct.needsUpdate=!0,Be=!0}}Be===!0&&(T.updateMultisampleRenderTarget(te),T.updateRenderTargetMipmap(te)),_.setRenderTarget(Re),_.setClearColor(X,L),_.toneMapping=Oe}function ws(C,z,$){const q=z.isScene===!0?z.overrideMaterial:null;for(let W=0,Me=C.length;W<Me;W++){const Re=C[W],Oe=Re.object,Be=Re.geometry,$e=q===null?Re.material:q,Ge=Re.group;Oe.layers.test($.layers)&&fo(Oe,z,$,Be,$e,Ge)}}function fo(C,z,$,q,W,Me){C.onBeforeRender(_,z,$,q,W,Me),C.modelViewMatrix.multiplyMatrices($.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),W.onBeforeRender(_,z,$,q,C,Me),W.transparent===!0&&W.side===Xt&&W.forceSinglePass===!1?(W.side=qt,W.needsUpdate=!0,_.renderBufferDirect($,z,q,W,C,Me),W.side=qn,W.needsUpdate=!0,_.renderBufferDirect($,z,q,W,C,Me),W.side=Xt):_.renderBufferDirect($,z,q,W,C,Me),C.onAfterRender(_,z,$,q,W,Me)}function Ts(C,z,$){z.isScene!==!0&&(z=Se);const q=me.get(C),W=p.state.lights,Me=p.state.shadowsArray,Re=W.state.version,Oe=Ce.getParameters(C,W.state,Me,z,$),Be=Ce.getProgramCacheKey(Oe);let $e=q.programs;q.environment=C.isMeshStandardMaterial?z.environment:null,q.fog=z.fog,q.envMap=(C.isMeshStandardMaterial?G:E).get(C.envMap||q.environment),$e===void 0&&(C.addEventListener("dispose",_e),$e=new Map,q.programs=$e);let Ge=$e.get(Be);if(Ge!==void 0){if(q.currentProgram===Ge&&q.lightsStateVersion===Re)return mo(C,Oe),Ge}else Oe.uniforms=Ce.getUniforms(C),C.onBuild($,Oe,_),C.onBeforeCompile(Oe,_),Ge=Ce.acquireProgram(Oe,Be),$e.set(Be,Ge),q.uniforms=Oe.uniforms;const Ve=q.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Ve.clippingPlanes=He.uniform),mo(C,Oe),q.needsLights=wh(C),q.lightsStateVersion=Re,q.needsLights&&(Ve.ambientLightColor.value=W.state.ambient,Ve.lightProbe.value=W.state.probe,Ve.directionalLights.value=W.state.directional,Ve.directionalLightShadows.value=W.state.directionalShadow,Ve.spotLights.value=W.state.spot,Ve.spotLightShadows.value=W.state.spotShadow,Ve.rectAreaLights.value=W.state.rectArea,Ve.ltc_1.value=W.state.rectAreaLTC1,Ve.ltc_2.value=W.state.rectAreaLTC2,Ve.pointLights.value=W.state.point,Ve.pointLightShadows.value=W.state.pointShadow,Ve.hemisphereLights.value=W.state.hemi,Ve.directionalShadowMap.value=W.state.directionalShadowMap,Ve.directionalShadowMatrix.value=W.state.directionalShadowMatrix,Ve.spotShadowMap.value=W.state.spotShadowMap,Ve.spotLightMatrix.value=W.state.spotLightMatrix,Ve.spotLightMap.value=W.state.spotLightMap,Ve.pointShadowMap.value=W.state.pointShadowMap,Ve.pointShadowMatrix.value=W.state.pointShadowMatrix),q.currentProgram=Ge,q.uniformsList=null,Ge}function po(C){if(C.uniformsList===null){const z=C.currentProgram.getUniforms();C.uniformsList=ir.seqWithValue(z.seq,C.uniforms)}return C.uniformsList}function mo(C,z){const $=me.get(C);$.outputColorSpace=z.outputColorSpace,$.batching=z.batching,$.instancing=z.instancing,$.instancingColor=z.instancingColor,$.skinning=z.skinning,$.morphTargets=z.morphTargets,$.morphNormals=z.morphNormals,$.morphColors=z.morphColors,$.morphTargetsCount=z.morphTargetsCount,$.numClippingPlanes=z.numClippingPlanes,$.numIntersection=z.numClipIntersection,$.vertexAlphas=z.vertexAlphas,$.vertexTangents=z.vertexTangents,$.toneMapping=z.toneMapping}function bh(C,z,$,q,W){z.isScene!==!0&&(z=Se),T.resetTextureUnits();const Me=z.fog,Re=q.isMeshStandardMaterial?z.environment:null,Oe=A===null?_.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:Un,Be=(q.isMeshStandardMaterial?G:E).get(q.envMap||Re),$e=q.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,Ge=!!$.attributes.tangent&&(!!q.normalMap||q.anisotropy>0),Ve=!!$.morphAttributes.position,Mt=!!$.morphAttributes.normal,Jt=!!$.morphAttributes.color;let Ct=Wn;q.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(Ct=_.toneMapping);const wn=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,ht=wn!==void 0?wn.length:0,Ye=me.get(q),Ir=p.state.lights;if(V===!0&&(Q===!0||C!==y)){const sn=C===y&&q.id===N;He.setState(q,C,sn)}let gt=!1;q.version===Ye.__version?(Ye.needsLights&&Ye.lightsStateVersion!==Ir.state.version||Ye.outputColorSpace!==Oe||W.isBatchedMesh&&Ye.batching===!1||!W.isBatchedMesh&&Ye.batching===!0||W.isInstancedMesh&&Ye.instancing===!1||!W.isInstancedMesh&&Ye.instancing===!0||W.isSkinnedMesh&&Ye.skinning===!1||!W.isSkinnedMesh&&Ye.skinning===!0||W.isInstancedMesh&&Ye.instancingColor===!0&&W.instanceColor===null||W.isInstancedMesh&&Ye.instancingColor===!1&&W.instanceColor!==null||Ye.envMap!==Be||q.fog===!0&&Ye.fog!==Me||Ye.numClippingPlanes!==void 0&&(Ye.numClippingPlanes!==He.numPlanes||Ye.numIntersection!==He.numIntersection)||Ye.vertexAlphas!==$e||Ye.vertexTangents!==Ge||Ye.morphTargets!==Ve||Ye.morphNormals!==Mt||Ye.morphColors!==Jt||Ye.toneMapping!==Ct||ie.isWebGL2===!0&&Ye.morphTargetsCount!==ht)&&(gt=!0):(gt=!0,Ye.__version=q.version);let Yn=Ye.currentProgram;gt===!0&&(Yn=Ts(q,z,W));let go=!1,Zi=!1,Dr=!1;const Dt=Yn.getUniforms(),jn=Ye.uniforms;if(K.useProgram(Yn.program)&&(go=!0,Zi=!0,Dr=!0),q.id!==N&&(N=q.id,Zi=!0),go||y!==C){Dt.setValue(I,"projectionMatrix",C.projectionMatrix),Dt.setValue(I,"viewMatrix",C.matrixWorldInverse);const sn=Dt.map.cameraPosition;sn!==void 0&&sn.setValue(I,Pe.setFromMatrixPosition(C.matrixWorld)),ie.logarithmicDepthBuffer&&Dt.setValue(I,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(q.isMeshPhongMaterial||q.isMeshToonMaterial||q.isMeshLambertMaterial||q.isMeshBasicMaterial||q.isMeshStandardMaterial||q.isShaderMaterial)&&Dt.setValue(I,"isOrthographic",C.isOrthographicCamera===!0),y!==C&&(y=C,Zi=!0,Dr=!0)}if(W.isSkinnedMesh){Dt.setOptional(I,W,"bindMatrix"),Dt.setOptional(I,W,"bindMatrixInverse");const sn=W.skeleton;sn&&(ie.floatVertexTextures?(sn.boneTexture===null&&sn.computeBoneTexture(),Dt.setValue(I,"boneTexture",sn.boneTexture,T)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}W.isBatchedMesh&&(Dt.setOptional(I,W,"batchingTexture"),Dt.setValue(I,"batchingTexture",W._matricesTexture,T));const Ur=$.morphAttributes;if((Ur.position!==void 0||Ur.normal!==void 0||Ur.color!==void 0&&ie.isWebGL2===!0)&&Ke.update(W,$,Yn),(Zi||Ye.receiveShadow!==W.receiveShadow)&&(Ye.receiveShadow=W.receiveShadow,Dt.setValue(I,"receiveShadow",W.receiveShadow)),q.isMeshGouraudMaterial&&q.envMap!==null&&(jn.envMap.value=Be,jn.flipEnvMap.value=Be.isCubeTexture&&Be.isRenderTargetTexture===!1?-1:1),Zi&&(Dt.setValue(I,"toneMappingExposure",_.toneMappingExposure),Ye.needsLights&&Eh(jn,Dr),Me&&q.fog===!0&&ge.refreshFogUniforms(jn,Me),ge.refreshMaterialUniforms(jn,q,Z,H,te),ir.upload(I,po(Ye),jn,T)),q.isShaderMaterial&&q.uniformsNeedUpdate===!0&&(ir.upload(I,po(Ye),jn,T),q.uniformsNeedUpdate=!1),q.isSpriteMaterial&&Dt.setValue(I,"center",W.center),Dt.setValue(I,"modelViewMatrix",W.modelViewMatrix),Dt.setValue(I,"normalMatrix",W.normalMatrix),Dt.setValue(I,"modelMatrix",W.matrixWorld),q.isShaderMaterial||q.isRawShaderMaterial){const sn=q.uniformsGroups;for(let Nr=0,Th=sn.length;Nr<Th;Nr++)if(ie.isWebGL2){const vo=sn[Nr];tt.update(vo,Yn),tt.bind(vo,Yn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Yn}function Eh(C,z){C.ambientLightColor.needsUpdate=z,C.lightProbe.needsUpdate=z,C.directionalLights.needsUpdate=z,C.directionalLightShadows.needsUpdate=z,C.pointLights.needsUpdate=z,C.pointLightShadows.needsUpdate=z,C.spotLights.needsUpdate=z,C.spotLightShadows.needsUpdate=z,C.rectAreaLights.needsUpdate=z,C.hemisphereLights.needsUpdate=z}function wh(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return P},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(C,z,$){me.get(C.texture).__webglTexture=z,me.get(C.depthTexture).__webglTexture=$;const q=me.get(C);q.__hasExternalTextures=!0,q.__hasExternalTextures&&(q.__autoAllocateDepthBuffer=$===void 0,q.__autoAllocateDepthBuffer||Y.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),q.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,z){const $=me.get(C);$.__webglFramebuffer=z,$.__useDefaultFramebuffer=z===void 0},this.setRenderTarget=function(C,z=0,$=0){A=C,P=z,w=$;let q=!0,W=null,Me=!1,Re=!1;if(C){const Be=me.get(C);Be.__useDefaultFramebuffer!==void 0?(K.bindFramebuffer(I.FRAMEBUFFER,null),q=!1):Be.__webglFramebuffer===void 0?T.setupRenderTarget(C):Be.__hasExternalTextures&&T.rebindTextures(C,me.get(C.texture).__webglTexture,me.get(C.depthTexture).__webglTexture);const $e=C.texture;($e.isData3DTexture||$e.isDataArrayTexture||$e.isCompressedArrayTexture)&&(Re=!0);const Ge=me.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Ge[z])?W=Ge[z][$]:W=Ge[z],Me=!0):ie.isWebGL2&&C.samples>0&&T.useMultisampledRTT(C)===!1?W=me.get(C).__webglMultisampledFramebuffer:Array.isArray(Ge)?W=Ge[$]:W=Ge,S.copy(C.viewport),D.copy(C.scissor),F=C.scissorTest}else S.copy(ee).multiplyScalar(Z).floor(),D.copy(le).multiplyScalar(Z).floor(),F=k;if(K.bindFramebuffer(I.FRAMEBUFFER,W)&&ie.drawBuffers&&q&&K.drawBuffers(C,W),K.viewport(S),K.scissor(D),K.setScissorTest(F),Me){const Be=me.get(C.texture);I.framebufferTexture2D(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_CUBE_MAP_POSITIVE_X+z,Be.__webglTexture,$)}else if(Re){const Be=me.get(C.texture),$e=z||0;I.framebufferTextureLayer(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0,Be.__webglTexture,$||0,$e)}N=-1},this.readRenderTargetPixels=function(C,z,$,q,W,Me,Re){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Oe=me.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Re!==void 0&&(Oe=Oe[Re]),Oe){K.bindFramebuffer(I.FRAMEBUFFER,Oe);try{const Be=C.texture,$e=Be.format,Ge=Be.type;if($e!==vn&&Te.convert($e)!==I.getParameter(I.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const Ve=Ge===ms&&(Y.has("EXT_color_buffer_half_float")||ie.isWebGL2&&Y.has("EXT_color_buffer_float"));if(Ge!==Xn&&Te.convert(Ge)!==I.getParameter(I.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Ge===Gn&&(ie.isWebGL2||Y.has("OES_texture_float")||Y.has("WEBGL_color_buffer_float")))&&!Ve){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}z>=0&&z<=C.width-q&&$>=0&&$<=C.height-W&&I.readPixels(z,$,q,W,Te.convert($e),Te.convert(Ge),Me)}finally{const Be=A!==null?me.get(A).__webglFramebuffer:null;K.bindFramebuffer(I.FRAMEBUFFER,Be)}}},this.copyFramebufferToTexture=function(C,z,$=0){const q=Math.pow(2,-$),W=Math.floor(z.image.width*q),Me=Math.floor(z.image.height*q);T.setTexture2D(z,0),I.copyTexSubImage2D(I.TEXTURE_2D,$,0,0,C.x,C.y,W,Me),K.unbindTexture()},this.copyTextureToTexture=function(C,z,$,q=0){const W=z.image.width,Me=z.image.height,Re=Te.convert($.format),Oe=Te.convert($.type);T.setTexture2D($,0),I.pixelStorei(I.UNPACK_FLIP_Y_WEBGL,$.flipY),I.pixelStorei(I.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),I.pixelStorei(I.UNPACK_ALIGNMENT,$.unpackAlignment),z.isDataTexture?I.texSubImage2D(I.TEXTURE_2D,q,C.x,C.y,W,Me,Re,Oe,z.image.data):z.isCompressedTexture?I.compressedTexSubImage2D(I.TEXTURE_2D,q,C.x,C.y,z.mipmaps[0].width,z.mipmaps[0].height,Re,z.mipmaps[0].data):I.texSubImage2D(I.TEXTURE_2D,q,C.x,C.y,Re,Oe,z.image),q===0&&$.generateMipmaps&&I.generateMipmap(I.TEXTURE_2D),K.unbindTexture()},this.copyTextureToTexture3D=function(C,z,$,q,W=0){if(_.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const Me=C.max.x-C.min.x+1,Re=C.max.y-C.min.y+1,Oe=C.max.z-C.min.z+1,Be=Te.convert(q.format),$e=Te.convert(q.type);let Ge;if(q.isData3DTexture)T.setTexture3D(q,0),Ge=I.TEXTURE_3D;else if(q.isDataArrayTexture||q.isCompressedArrayTexture)T.setTexture2DArray(q,0),Ge=I.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}I.pixelStorei(I.UNPACK_FLIP_Y_WEBGL,q.flipY),I.pixelStorei(I.UNPACK_PREMULTIPLY_ALPHA_WEBGL,q.premultiplyAlpha),I.pixelStorei(I.UNPACK_ALIGNMENT,q.unpackAlignment);const Ve=I.getParameter(I.UNPACK_ROW_LENGTH),Mt=I.getParameter(I.UNPACK_IMAGE_HEIGHT),Jt=I.getParameter(I.UNPACK_SKIP_PIXELS),Ct=I.getParameter(I.UNPACK_SKIP_ROWS),wn=I.getParameter(I.UNPACK_SKIP_IMAGES),ht=$.isCompressedTexture?$.mipmaps[W]:$.image;I.pixelStorei(I.UNPACK_ROW_LENGTH,ht.width),I.pixelStorei(I.UNPACK_IMAGE_HEIGHT,ht.height),I.pixelStorei(I.UNPACK_SKIP_PIXELS,C.min.x),I.pixelStorei(I.UNPACK_SKIP_ROWS,C.min.y),I.pixelStorei(I.UNPACK_SKIP_IMAGES,C.min.z),$.isDataTexture||$.isData3DTexture?I.texSubImage3D(Ge,W,z.x,z.y,z.z,Me,Re,Oe,Be,$e,ht.data):$.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),I.compressedTexSubImage3D(Ge,W,z.x,z.y,z.z,Me,Re,Oe,Be,ht.data)):I.texSubImage3D(Ge,W,z.x,z.y,z.z,Me,Re,Oe,Be,$e,ht),I.pixelStorei(I.UNPACK_ROW_LENGTH,Ve),I.pixelStorei(I.UNPACK_IMAGE_HEIGHT,Mt),I.pixelStorei(I.UNPACK_SKIP_PIXELS,Jt),I.pixelStorei(I.UNPACK_SKIP_ROWS,Ct),I.pixelStorei(I.UNPACK_SKIP_IMAGES,wn),W===0&&q.generateMipmaps&&I.generateMipmap(Ge),K.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?T.setTextureCube(C,0):C.isData3DTexture?T.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?T.setTexture2DArray(C,0):T.setTexture2D(C,0),K.unbindTexture()},this.resetState=function(){P=0,w=0,A=null,K.reset(),We.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Dn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=e===qa?"display-p3":"srgb",t.unpackColorSpace=nt.workingColorSpace===br?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===dt?ci:Rc}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===ci?dt:Un}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}}class W0 extends Kc{}W0.prototype.isWebGL1Renderer=!0;class wr{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new Le(e),this.density=t}clone(){return new wr(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class Jc extends _t{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}}class Zc extends Ki{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Le(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Fl=new pt,Ia=new ja,js=new Ss,Ks=new R;class X0 extends _t{constructor(e=new It,t=new Zc){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const i=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),js.copy(i.boundingSphere),js.applyMatrix4(s),js.radius+=r,e.ray.intersectsSphere(js)===!1)return;Fl.copy(s).invert(),Ia.copy(e.ray).applyMatrix4(Fl);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=i.index,u=i.attributes.position;if(c!==null){const d=Math.max(0,a.start),f=Math.min(c.count,a.start+a.count);for(let g=d,v=f;g<v;g++){const p=c.getX(g);Ks.fromBufferAttribute(u,p),kl(Ks,p,l,s,e,t,this)}}else{const d=Math.max(0,a.start),f=Math.min(u.count,a.start+a.count);for(let g=d,v=f;g<v;g++)Ks.fromBufferAttribute(u,g),kl(Ks,g,l,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const s=t[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function kl(n,e,t,i,s,r,a){const o=Ia.distanceSqToPoint(n);if(o<t){const l=new R;Ia.closestPointToPoint(n,l),l.applyMatrix4(i);const c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,object:a})}}class bs extends Kt{constructor(e,t,i,s,r,a,o,l,c){super(e,t,i,s,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class En{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){const i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let i,s=this.getPoint(0),r=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),r+=i.distanceTo(s),t.push(r),s=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){const i=this.getLengths();let s=0;const r=i.length;let a;t?a=t:a=e*i[r-1];let o=0,l=r-1,c;for(;o<=l;)if(s=Math.floor(o+(l-o)/2),c=i[s]-a,c<0)o=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,i[s]===a)return s/(r-1);const h=i[s],d=i[s+1]-h,f=(a-h)/d;return(s+f)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const a=this.getPoint(s),o=this.getPoint(r),l=t||(a.isVector2?new ue:new R);return l.copy(o).sub(a).normalize(),l}getTangentAt(e,t){const i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t){const i=new R,s=[],r=[],a=[],o=new R,l=new pt;for(let f=0;f<=e;f++){const g=f/e;s[f]=this.getTangentAt(g,new R)}r[0]=new R,a[0]=new R;let c=Number.MAX_VALUE;const h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,i.set(1,0,0)),u<=c&&(c=u,i.set(0,1,0)),d<=c&&i.set(0,0,1),o.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let f=1;f<=e;f++){if(r[f]=r[f-1].clone(),a[f]=a[f-1].clone(),o.crossVectors(s[f-1],s[f]),o.length()>Number.EPSILON){o.normalize();const g=Math.acos(Et(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(o,g))}a[f].crossVectors(s[f],r[f])}if(t===!0){let f=Math.acos(Et(r[0].dot(r[e]),-1,1));f/=e,s[0].dot(o.crossVectors(r[0],r[e]))>0&&(f=-f);for(let g=1;g<=e;g++)r[g].applyMatrix4(l.makeRotationAxis(s[g],f*g)),a[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Qa extends En{constructor(e=0,t=0,i=1,s=1,r=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(e,t){const i=t||new ue,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);const o=this.aStartAngle+e*r;let l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){const h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return i.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class $0 extends Qa{constructor(e,t,i,s,r,a){super(e,t,i,i,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}}function eo(){let n=0,e=0,t=0,i=0;function s(r,a,o,l){n=r,e=o,t=-3*r+3*a-2*o-l,i=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,c){s(a,o,c*(o-r),c*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,c,h,u){let d=(a-r)/c-(o-r)/(c+h)+(o-a)/h,f=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,f*=h,s(a,o,d,f)},calc:function(r){const a=r*r,o=a*r;return n+e*r+t*a+i*o}}}const Js=new R,ua=new eo,da=new eo,fa=new eo;class q0 extends En{constructor(e=[],t=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=s}getPoint(e,t=new R){const i=t,s=this.points,r=s.length,a=(r-(this.closed?0:1))*e;let o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:l===0&&o===r-1&&(o=r-2,l=1);let c,h;this.closed||o>0?c=s[(o-1)%r]:(Js.subVectors(s[0],s[1]).add(s[0]),c=Js);const u=s[o%r],d=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:(Js.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Js),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let g=Math.pow(c.distanceToSquared(u),f),v=Math.pow(u.distanceToSquared(d),f),p=Math.pow(d.distanceToSquared(h),f);v<1e-4&&(v=1),g<1e-4&&(g=v),p<1e-4&&(p=v),ua.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,v,p),da.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,v,p),fa.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,v,p)}else this.curveType==="catmullrom"&&(ua.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),da.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),fa.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return i.set(ua.calc(l),da.calc(l),fa.calc(l)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new R().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function Bl(n,e,t,i,s){const r=(i-e)*.5,a=(s-t)*.5,o=n*n,l=n*o;return(2*t-2*i+r+a)*l+(-3*t+3*i-2*r-a)*o+r*n+t}function Y0(n,e){const t=1-n;return t*t*e}function j0(n,e){return 2*(1-n)*n*e}function K0(n,e){return n*n*e}function cs(n,e,t,i){return Y0(n,e)+j0(n,t)+K0(n,i)}function J0(n,e){const t=1-n;return t*t*t*e}function Z0(n,e){const t=1-n;return 3*t*t*n*e}function Q0(n,e){return 3*(1-n)*n*n*e}function eg(n,e){return n*n*n*e}function hs(n,e,t,i,s){return J0(n,e)+Z0(n,t)+Q0(n,i)+eg(n,s)}class Qc extends En{constructor(e=new ue,t=new ue,i=new ue,s=new ue){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new ue){const i=t,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(hs(e,s.x,r.x,a.x,o.x),hs(e,s.y,r.y,a.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class tg extends En{constructor(e=new R,t=new R,i=new R,s=new R){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new R){const i=t,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(hs(e,s.x,r.x,a.x,o.x),hs(e,s.y,r.y,a.y,o.y),hs(e,s.z,r.z,a.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class eh extends En{constructor(e=new ue,t=new ue){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new ue){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new ue){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class ng extends En{constructor(e=new R,t=new R){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new R){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new R){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class th extends En{constructor(e=new ue,t=new ue,i=new ue){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new ue){const i=t,s=this.v0,r=this.v1,a=this.v2;return i.set(cs(e,s.x,r.x,a.x),cs(e,s.y,r.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class ig extends En{constructor(e=new R,t=new R,i=new R){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new R){const i=t,s=this.v0,r=this.v1,a=this.v2;return i.set(cs(e,s.x,r.x,a.x),cs(e,s.y,r.y,a.y),cs(e,s.z,r.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class nh extends En{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new ue){const i=t,s=this.points,r=(s.length-1)*e,a=Math.floor(r),o=r-a,l=s[a===0?a:a-1],c=s[a],h=s[a>s.length-2?s.length-1:a+1],u=s[a>s.length-3?s.length-1:a+2];return i.set(Bl(o,l.x,c.x,h.x,u.x),Bl(o,l.y,c.y,h.y,u.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new ue().fromArray(s))}return this}}var Da=Object.freeze({__proto__:null,ArcCurve:$0,CatmullRomCurve3:q0,CubicBezierCurve:Qc,CubicBezierCurve3:tg,EllipseCurve:Qa,LineCurve:eh,LineCurve3:ng,QuadraticBezierCurve:th,QuadraticBezierCurve3:ig,SplineCurve:nh});class sg extends En{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Da[i](t,e))}return this}getPoint(e,t){const i=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=i){const a=s[r]-i,o=this.curves[r],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let i=0,s=this.curves.length;i<s;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let i;for(let s=0,r=this.curves;s<r.length;s++){const a=r[s],o=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,l=a.getPoints(o);for(let c=0;c<l.length;c++){const h=l[c];i&&i.equals(h)||(t.push(h),i=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(new Da[s.type]().fromJSON(s))}return this}}class Ua extends sg{constructor(e){super(),this.type="Path",this.currentPoint=new ue,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const i=new eh(this.currentPoint.clone(),new ue(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,s){const r=new th(this.currentPoint.clone(),new ue(e,t),new ue(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(e,t,i,s,r,a){const o=new Qc(this.currentPoint.clone(),new ue(e,t),new ue(i,s),new ue(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),i=new nh(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,s,r,a){const o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+o,t+l,i,s,r,a),this}absarc(e,t,i,s,r,a){return this.absellipse(e,t,i,i,s,r,a),this}ellipse(e,t,i,s,r,a,o,l){const c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,i,s,r,a,o,l),this}absellipse(e,t,i,s,r,a,o,l){const c=new Qa(e,t,i,s,r,a,o,l);if(this.curves.length>0){const u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);const h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class to extends It{constructor(e=[new ue(0,-.5),new ue(.5,0),new ue(0,.5)],t=12,i=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:i,phiLength:s},t=Math.floor(t),s=Et(s,0,Math.PI*2);const r=[],a=[],o=[],l=[],c=[],h=1/t,u=new R,d=new ue,f=new R,g=new R,v=new R;let p=0,m=0;for(let M=0;M<=e.length-1;M++)switch(M){case 0:p=e[M+1].x-e[M].x,m=e[M+1].y-e[M].y,f.x=m*1,f.y=-p,f.z=m*0,v.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case e.length-1:l.push(v.x,v.y,v.z);break;default:p=e[M+1].x-e[M].x,m=e[M+1].y-e[M].y,f.x=m*1,f.y=-p,f.z=m*0,g.copy(f),f.x+=v.x,f.y+=v.y,f.z+=v.z,f.normalize(),l.push(f.x,f.y,f.z),v.copy(g)}for(let M=0;M<=t;M++){const _=i+M*h*s,x=Math.sin(_),P=Math.cos(_);for(let w=0;w<=e.length-1;w++){u.x=e[w].x*x,u.y=e[w].y,u.z=e[w].x*P,a.push(u.x,u.y,u.z),d.x=M/t,d.y=w/(e.length-1),o.push(d.x,d.y);const A=l[3*w+0]*x,N=l[3*w+1],y=l[3*w+0]*P;c.push(A,N,y)}}for(let M=0;M<t;M++)for(let _=0;_<e.length-1;_++){const x=_+M*e.length,P=x,w=x+e.length,A=x+e.length+1,N=x+1;r.push(P,w,N),r.push(A,N,w)}this.setIndex(r),this.setAttribute("position",new st(a,3)),this.setAttribute("uv",new st(o,2)),this.setAttribute("normal",new st(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new to(e.points,e.segments,e.phiStart,e.phiLength)}}class Es extends to{constructor(e=1,t=1,i=4,s=8){const r=new Ua;r.absarc(0,-t/2,e,Math.PI*1.5,0),r.absarc(0,t/2,e,0,Math.PI*.5),super(r.getPoints(i),s),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:i,radialSegments:s}}static fromJSON(e){return new Es(e.radius,e.length,e.capSegments,e.radialSegments)}}class no extends It{constructor(e=1,t=32,i=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:s},t=Math.max(3,t);const r=[],a=[],o=[],l=[],c=new R,h=new ue;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=t;u++,d+=3){const f=i+u/t*s;c.x=e*Math.cos(f),c.y=e*Math.sin(f),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/e+1)/2,h.y=(a[d+1]/e+1)/2,l.push(h.x,h.y)}for(let u=1;u<=t;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new st(a,3)),this.setAttribute("normal",new st(o,3)),this.setAttribute("uv",new st(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new no(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Ze extends It{constructor(e=1,t=1,i=1,s=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};const c=this;s=Math.floor(s),r=Math.floor(r);const h=[],u=[],d=[],f=[];let g=0;const v=[],p=i/2;let m=0;M(),a===!1&&(e>0&&_(!0),t>0&&_(!1)),this.setIndex(h),this.setAttribute("position",new st(u,3)),this.setAttribute("normal",new st(d,3)),this.setAttribute("uv",new st(f,2));function M(){const x=new R,P=new R;let w=0;const A=(t-e)/i;for(let N=0;N<=r;N++){const y=[],S=N/r,D=S*(t-e)+e;for(let F=0;F<=s;F++){const X=F/s,L=X*l+o,B=Math.sin(L),H=Math.cos(L);P.x=D*B,P.y=-S*i+p,P.z=D*H,u.push(P.x,P.y,P.z),x.set(B,A,H).normalize(),d.push(x.x,x.y,x.z),f.push(X,1-S),y.push(g++)}v.push(y)}for(let N=0;N<s;N++)for(let y=0;y<r;y++){const S=v[y][N],D=v[y+1][N],F=v[y+1][N+1],X=v[y][N+1];h.push(S,D,X),h.push(D,F,X),w+=6}c.addGroup(m,w,0),m+=w}function _(x){const P=g,w=new ue,A=new R;let N=0;const y=x===!0?e:t,S=x===!0?1:-1;for(let F=1;F<=s;F++)u.push(0,p*S,0),d.push(0,S,0),f.push(.5,.5),g++;const D=g;for(let F=0;F<=s;F++){const L=F/s*l+o,B=Math.cos(L),H=Math.sin(L);A.x=y*H,A.y=p*S,A.z=y*B,u.push(A.x,A.y,A.z),d.push(0,S,0),w.x=B*.5+.5,w.y=H*.5*S+.5,f.push(w.x,w.y),g++}for(let F=0;F<s;F++){const X=P+F,L=D+F;x===!0?h.push(L,L+1,X):h.push(L+1,L,X),N+=3}c.addGroup(m,N,x===!0?1:2),m+=N}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ze(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class bn extends Ze{constructor(e=1,t=1,i=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,e,t,i,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(e){return new bn(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Tr extends It{constructor(e=[],t=[],i=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:s};const r=[],a=[];o(s),c(i),h(),this.setAttribute("position",new st(r,3)),this.setAttribute("normal",new st(r.slice(),3)),this.setAttribute("uv",new st(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(M){const _=new R,x=new R,P=new R;for(let w=0;w<t.length;w+=3)f(t[w+0],_),f(t[w+1],x),f(t[w+2],P),l(_,x,P,M)}function l(M,_,x,P){const w=P+1,A=[];for(let N=0;N<=w;N++){A[N]=[];const y=M.clone().lerp(x,N/w),S=_.clone().lerp(x,N/w),D=w-N;for(let F=0;F<=D;F++)F===0&&N===w?A[N][F]=y:A[N][F]=y.clone().lerp(S,F/D)}for(let N=0;N<w;N++)for(let y=0;y<2*(w-N)-1;y++){const S=Math.floor(y/2);y%2===0?(d(A[N][S+1]),d(A[N+1][S]),d(A[N][S])):(d(A[N][S+1]),d(A[N+1][S+1]),d(A[N+1][S]))}}function c(M){const _=new R;for(let x=0;x<r.length;x+=3)_.x=r[x+0],_.y=r[x+1],_.z=r[x+2],_.normalize().multiplyScalar(M),r[x+0]=_.x,r[x+1]=_.y,r[x+2]=_.z}function h(){const M=new R;for(let _=0;_<r.length;_+=3){M.x=r[_+0],M.y=r[_+1],M.z=r[_+2];const x=p(M)/2/Math.PI+.5,P=m(M)/Math.PI+.5;a.push(x,1-P)}g(),u()}function u(){for(let M=0;M<a.length;M+=6){const _=a[M+0],x=a[M+2],P=a[M+4],w=Math.max(_,x,P),A=Math.min(_,x,P);w>.9&&A<.1&&(_<.2&&(a[M+0]+=1),x<.2&&(a[M+2]+=1),P<.2&&(a[M+4]+=1))}}function d(M){r.push(M.x,M.y,M.z)}function f(M,_){const x=M*3;_.x=e[x+0],_.y=e[x+1],_.z=e[x+2]}function g(){const M=new R,_=new R,x=new R,P=new R,w=new ue,A=new ue,N=new ue;for(let y=0,S=0;y<r.length;y+=9,S+=6){M.set(r[y+0],r[y+1],r[y+2]),_.set(r[y+3],r[y+4],r[y+5]),x.set(r[y+6],r[y+7],r[y+8]),w.set(a[S+0],a[S+1]),A.set(a[S+2],a[S+3]),N.set(a[S+4],a[S+5]),P.copy(M).add(_).add(x).divideScalar(3);const D=p(P);v(w,S+0,M,D),v(A,S+2,_,D),v(N,S+4,x,D)}}function v(M,_,x,P){P<0&&M.x===1&&(a[_]=M.x-1),x.x===0&&x.z===0&&(a[_]=P/2/Math.PI+.5)}function p(M){return Math.atan2(M.z,-M.x)}function m(M){return Math.atan2(-M.y,Math.sqrt(M.x*M.x+M.z*M.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Tr(e.vertices,e.indices,e.radius,e.details)}}class ih extends Ua{constructor(e){super(e),this.uuid=vi(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let i=0,s=this.holes.length;i<s;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(new Ua().fromJSON(s))}return this}}const rg={triangulate:function(n,e,t=2){const i=e&&e.length,s=i?e[0]*t:n.length;let r=sh(n,0,s,t,!0);const a=[];if(!r||r.next===r.prev)return a;let o,l,c,h,u,d,f;if(i&&(r=hg(n,e,r,t)),n.length>80*t){o=c=n[0],l=h=n[1];for(let g=t;g<s;g+=t)u=n[g],d=n[g+1],u<o&&(o=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);f=Math.max(c-o,h-l),f=f!==0?32767/f:0}return gs(r,a,t,o,l,f,0),a}};function sh(n,e,t,i,s){let r,a;if(s===Sg(n,e,t,i)>0)for(r=e;r<t;r+=i)a=zl(r,n[r],n[r+1],a);else for(r=t-i;r>=e;r-=i)a=zl(r,n[r],n[r+1],a);return a&&Ar(a,a.next)&&(ys(a),a=a.next),a}function mi(n,e){if(!n)return n;e||(e=n);let t=n,i;do if(i=!1,!t.steiner&&(Ar(t,t.next)||ft(t.prev,t,t.next)===0)){if(ys(t),t=e=t.prev,t===t.next)break;i=!0}else t=t.next;while(i||t!==e);return e}function gs(n,e,t,i,s,r,a){if(!n)return;!a&&r&&mg(n,i,s,r);let o=n,l,c;for(;n.prev!==n.next;){if(l=n.prev,c=n.next,r?og(n,i,s,r):ag(n)){e.push(l.i/t|0),e.push(n.i/t|0),e.push(c.i/t|0),ys(n),n=c.next,o=c.next;continue}if(n=c,n===o){a?a===1?(n=lg(mi(n),e,t),gs(n,e,t,i,s,r,2)):a===2&&cg(n,e,t,i,s,r):gs(mi(n),e,t,i,s,r,1);break}}}function ag(n){const e=n.prev,t=n,i=n.next;if(ft(e,t,i)>=0)return!1;const s=e.x,r=t.x,a=i.x,o=e.y,l=t.y,c=i.y,h=s<r?s<a?s:a:r<a?r:a,u=o<l?o<c?o:c:l<c?l:c,d=s>r?s>a?s:a:r>a?r:a,f=o>l?o>c?o:c:l>c?l:c;let g=i.next;for(;g!==e;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=f&&Bi(s,o,r,l,a,c,g.x,g.y)&&ft(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function og(n,e,t,i){const s=n.prev,r=n,a=n.next;if(ft(s,r,a)>=0)return!1;const o=s.x,l=r.x,c=a.x,h=s.y,u=r.y,d=a.y,f=o<l?o<c?o:c:l<c?l:c,g=h<u?h<d?h:d:u<d?u:d,v=o>l?o>c?o:c:l>c?l:c,p=h>u?h>d?h:d:u>d?u:d,m=Na(f,g,e,t,i),M=Na(v,p,e,t,i);let _=n.prevZ,x=n.nextZ;for(;_&&_.z>=m&&x&&x.z<=M;){if(_.x>=f&&_.x<=v&&_.y>=g&&_.y<=p&&_!==s&&_!==a&&Bi(o,h,l,u,c,d,_.x,_.y)&&ft(_.prev,_,_.next)>=0||(_=_.prevZ,x.x>=f&&x.x<=v&&x.y>=g&&x.y<=p&&x!==s&&x!==a&&Bi(o,h,l,u,c,d,x.x,x.y)&&ft(x.prev,x,x.next)>=0))return!1;x=x.nextZ}for(;_&&_.z>=m;){if(_.x>=f&&_.x<=v&&_.y>=g&&_.y<=p&&_!==s&&_!==a&&Bi(o,h,l,u,c,d,_.x,_.y)&&ft(_.prev,_,_.next)>=0)return!1;_=_.prevZ}for(;x&&x.z<=M;){if(x.x>=f&&x.x<=v&&x.y>=g&&x.y<=p&&x!==s&&x!==a&&Bi(o,h,l,u,c,d,x.x,x.y)&&ft(x.prev,x,x.next)>=0)return!1;x=x.nextZ}return!0}function lg(n,e,t){let i=n;do{const s=i.prev,r=i.next.next;!Ar(s,r)&&rh(s,i,i.next,r)&&vs(s,r)&&vs(r,s)&&(e.push(s.i/t|0),e.push(i.i/t|0),e.push(r.i/t|0),ys(i),ys(i.next),i=n=r),i=i.next}while(i!==n);return mi(i)}function cg(n,e,t,i,s,r){let a=n;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&yg(a,o)){let l=ah(a,o);a=mi(a,a.next),l=mi(l,l.next),gs(a,e,t,i,s,r,0),gs(l,e,t,i,s,r,0);return}o=o.next}a=a.next}while(a!==n)}function hg(n,e,t,i){const s=[];let r,a,o,l,c;for(r=0,a=e.length;r<a;r++)o=e[r]*i,l=r<a-1?e[r+1]*i:n.length,c=sh(n,o,l,i,!1),c===c.next&&(c.steiner=!0),s.push(vg(c));for(s.sort(ug),r=0;r<s.length;r++)t=dg(s[r],t);return t}function ug(n,e){return n.x-e.x}function dg(n,e){const t=fg(n,e);if(!t)return e;const i=ah(t,n);return mi(i,i.next),mi(t,t.next)}function fg(n,e){let t=e,i=-1/0,s;const r=n.x,a=n.y;do{if(a<=t.y&&a>=t.next.y&&t.next.y!==t.y){const d=t.x+(a-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(d<=r&&d>i&&(i=d,s=t.x<t.next.x?t:t.next,d===r))return s}t=t.next}while(t!==e);if(!s)return null;const o=s,l=s.x,c=s.y;let h=1/0,u;t=s;do r>=t.x&&t.x>=l&&r!==t.x&&Bi(a<c?r:i,a,l,c,a<c?i:r,a,t.x,t.y)&&(u=Math.abs(a-t.y)/(r-t.x),vs(t,n)&&(u<h||u===h&&(t.x>s.x||t.x===s.x&&pg(s,t)))&&(s=t,h=u)),t=t.next;while(t!==o);return s}function pg(n,e){return ft(n.prev,n,e.prev)<0&&ft(e.next,n,n.next)<0}function mg(n,e,t,i){let s=n;do s.z===0&&(s.z=Na(s.x,s.y,e,t,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,gg(s)}function gg(n){let e,t,i,s,r,a,o,l,c=1;do{for(t=n,n=null,r=null,a=0;t;){for(a++,i=t,o=0,e=0;e<c&&(o++,i=i.nextZ,!!i);e++);for(l=c;o>0||l>0&&i;)o!==0&&(l===0||!i||t.z<=i.z)?(s=t,t=t.nextZ,o--):(s=i,i=i.nextZ,l--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;t=i}r.nextZ=null,c*=2}while(a>1);return n}function Na(n,e,t,i,s){return n=(n-t)*s|0,e=(e-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,n|e<<1}function vg(n){let e=n,t=n;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==n);return t}function Bi(n,e,t,i,s,r,a,o){return(s-a)*(e-o)>=(n-a)*(r-o)&&(n-a)*(i-o)>=(t-a)*(e-o)&&(t-a)*(r-o)>=(s-a)*(i-o)}function yg(n,e){return n.next.i!==e.i&&n.prev.i!==e.i&&!_g(n,e)&&(vs(n,e)&&vs(e,n)&&Mg(n,e)&&(ft(n.prev,n,e.prev)||ft(n,e.prev,e))||Ar(n,e)&&ft(n.prev,n,n.next)>0&&ft(e.prev,e,e.next)>0)}function ft(n,e,t){return(e.y-n.y)*(t.x-e.x)-(e.x-n.x)*(t.y-e.y)}function Ar(n,e){return n.x===e.x&&n.y===e.y}function rh(n,e,t,i){const s=Qs(ft(n,e,t)),r=Qs(ft(n,e,i)),a=Qs(ft(t,i,n)),o=Qs(ft(t,i,e));return!!(s!==r&&a!==o||s===0&&Zs(n,t,e)||r===0&&Zs(n,i,e)||a===0&&Zs(t,n,i)||o===0&&Zs(t,e,i))}function Zs(n,e,t){return e.x<=Math.max(n.x,t.x)&&e.x>=Math.min(n.x,t.x)&&e.y<=Math.max(n.y,t.y)&&e.y>=Math.min(n.y,t.y)}function Qs(n){return n>0?1:n<0?-1:0}function _g(n,e){let t=n;do{if(t.i!==n.i&&t.next.i!==n.i&&t.i!==e.i&&t.next.i!==e.i&&rh(t,t.next,n,e))return!0;t=t.next}while(t!==n);return!1}function vs(n,e){return ft(n.prev,n,n.next)<0?ft(n,e,n.next)>=0&&ft(n,n.prev,e)>=0:ft(n,e,n.prev)<0||ft(n,n.next,e)<0}function Mg(n,e){let t=n,i=!1;const s=(n.x+e.x)/2,r=(n.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(i=!i),t=t.next;while(t!==n);return i}function ah(n,e){const t=new Oa(n.i,n.x,n.y),i=new Oa(e.i,e.x,e.y),s=n.next,r=e.prev;return n.next=e,e.prev=n,t.next=s,s.prev=t,i.next=t,t.prev=i,r.next=i,i.prev=r,i}function zl(n,e,t,i){const s=new Oa(n,e,t);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function ys(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function Oa(n,e,t){this.i=n,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Sg(n,e,t,i){let s=0;for(let r=e,a=t-i;r<t;r+=i)s+=(n[a]-n[r])*(n[r+1]+n[a+1]),a=r;return s}class us{static area(e){const t=e.length;let i=0;for(let s=t-1,r=0;r<t;s=r++)i+=e[s].x*e[r].y-e[r].x*e[s].y;return i*.5}static isClockWise(e){return us.area(e)<0}static triangulateShape(e,t){const i=[],s=[],r=[];Gl(e),Hl(i,e);let a=e.length;t.forEach(Gl);for(let l=0;l<t.length;l++)s.push(a),a+=t[l].length,Hl(i,t[l]);const o=rg.triangulate(i,s);for(let l=0;l<o.length;l+=3)r.push(o.slice(l,l+3));return r}}function Gl(n){const e=n.length;e>2&&n[e-1].equals(n[0])&&n.pop()}function Hl(n,e){for(let t=0;t<e.length;t++)n.push(e[t].x),n.push(e[t].y)}class io extends It{constructor(e=new ih([new ue(.5,.5),new ue(-.5,.5),new ue(-.5,-.5),new ue(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const i=this,s=[],r=[];for(let o=0,l=e.length;o<l;o++){const c=e[o];a(c)}this.setAttribute("position",new st(s,3)),this.setAttribute("uv",new st(r,2)),this.computeVertexNormals();function a(o){const l=[],c=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,u=t.depth!==void 0?t.depth:1;let d=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,g=t.bevelSize!==void 0?t.bevelSize:f-.1,v=t.bevelOffset!==void 0?t.bevelOffset:0,p=t.bevelSegments!==void 0?t.bevelSegments:3;const m=t.extrudePath,M=t.UVGenerator!==void 0?t.UVGenerator:xg;let _,x=!1,P,w,A,N;m&&(_=m.getSpacedPoints(h),x=!0,d=!1,P=m.computeFrenetFrames(h,!1),w=new R,A=new R,N=new R),d||(p=0,f=0,g=0,v=0);const y=o.extractPoints(c);let S=y.shape;const D=y.holes;if(!us.isClockWise(S)){S=S.reverse();for(let I=0,ce=D.length;I<ce;I++){const Y=D[I];us.isClockWise(Y)&&(D[I]=Y.reverse())}}const X=us.triangulateShape(S,D),L=S;for(let I=0,ce=D.length;I<ce;I++){const Y=D[I];S=S.concat(Y)}function B(I,ce,Y){return ce||console.error("THREE.ExtrudeGeometry: vec does not exist"),I.clone().addScaledVector(ce,Y)}const H=S.length,Z=X.length;function J(I,ce,Y){let ie,K,Ae;const me=I.x-ce.x,T=I.y-ce.y,E=Y.x-I.x,G=Y.y-I.y,ae=me*me+T*T,se=me*G-T*E;if(Math.abs(se)>Number.EPSILON){const ne=Math.sqrt(ae),Ce=Math.sqrt(E*E+G*G),ge=ce.x-T/ne,xe=ce.y+me/ne,Ue=Y.x-G/Ce,He=Y.y+E/Ce,re=((Ue-ge)*G-(He-xe)*E)/(me*G-T*E);ie=ge+me*re-I.x,K=xe+T*re-I.y;const Qe=ie*ie+K*K;if(Qe<=2)return new ue(ie,K);Ae=Math.sqrt(Qe/2)}else{let ne=!1;me>Number.EPSILON?E>Number.EPSILON&&(ne=!0):me<-Number.EPSILON?E<-Number.EPSILON&&(ne=!0):Math.sign(T)===Math.sign(G)&&(ne=!0),ne?(ie=-T,K=me,Ae=Math.sqrt(ae)):(ie=me,K=T,Ae=Math.sqrt(ae/2))}return new ue(ie/Ae,K/Ae)}const j=[];for(let I=0,ce=L.length,Y=ce-1,ie=I+1;I<ce;I++,Y++,ie++)Y===ce&&(Y=0),ie===ce&&(ie=0),j[I]=J(L[I],L[Y],L[ie]);const ee=[];let le,k=j.concat();for(let I=0,ce=D.length;I<ce;I++){const Y=D[I];le=[];for(let ie=0,K=Y.length,Ae=K-1,me=ie+1;ie<K;ie++,Ae++,me++)Ae===K&&(Ae=0),me===K&&(me=0),le[ie]=J(Y[ie],Y[Ae],Y[me]);ee.push(le),k=k.concat(le)}for(let I=0;I<p;I++){const ce=I/p,Y=f*Math.cos(ce*Math.PI/2),ie=g*Math.sin(ce*Math.PI/2)+v;for(let K=0,Ae=L.length;K<Ae;K++){const me=B(L[K],j[K],ie);he(me.x,me.y,-Y)}for(let K=0,Ae=D.length;K<Ae;K++){const me=D[K];le=ee[K];for(let T=0,E=me.length;T<E;T++){const G=B(me[T],le[T],ie);he(G.x,G.y,-Y)}}}const O=g+v;for(let I=0;I<H;I++){const ce=d?B(S[I],k[I],O):S[I];x?(A.copy(P.normals[0]).multiplyScalar(ce.x),w.copy(P.binormals[0]).multiplyScalar(ce.y),N.copy(_[0]).add(A).add(w),he(N.x,N.y,N.z)):he(ce.x,ce.y,0)}for(let I=1;I<=h;I++)for(let ce=0;ce<H;ce++){const Y=d?B(S[ce],k[ce],O):S[ce];x?(A.copy(P.normals[I]).multiplyScalar(Y.x),w.copy(P.binormals[I]).multiplyScalar(Y.y),N.copy(_[I]).add(A).add(w),he(N.x,N.y,N.z)):he(Y.x,Y.y,u/h*I)}for(let I=p-1;I>=0;I--){const ce=I/p,Y=f*Math.cos(ce*Math.PI/2),ie=g*Math.sin(ce*Math.PI/2)+v;for(let K=0,Ae=L.length;K<Ae;K++){const me=B(L[K],j[K],ie);he(me.x,me.y,u+Y)}for(let K=0,Ae=D.length;K<Ae;K++){const me=D[K];le=ee[K];for(let T=0,E=me.length;T<E;T++){const G=B(me[T],le[T],ie);x?he(G.x,G.y+_[h-1].y,_[h-1].x+Y):he(G.x,G.y,u+Y)}}}V(),Q();function V(){const I=s.length/3;if(d){let ce=0,Y=H*ce;for(let ie=0;ie<Z;ie++){const K=X[ie];be(K[2]+Y,K[1]+Y,K[0]+Y)}ce=h+p*2,Y=H*ce;for(let ie=0;ie<Z;ie++){const K=X[ie];be(K[0]+Y,K[1]+Y,K[2]+Y)}}else{for(let ce=0;ce<Z;ce++){const Y=X[ce];be(Y[2],Y[1],Y[0])}for(let ce=0;ce<Z;ce++){const Y=X[ce];be(Y[0]+H*h,Y[1]+H*h,Y[2]+H*h)}}i.addGroup(I,s.length/3-I,0)}function Q(){const I=s.length/3;let ce=0;te(L,ce),ce+=L.length;for(let Y=0,ie=D.length;Y<ie;Y++){const K=D[Y];te(K,ce),ce+=K.length}i.addGroup(I,s.length/3-I,1)}function te(I,ce){let Y=I.length;for(;--Y>=0;){const ie=Y;let K=Y-1;K<0&&(K=I.length-1);for(let Ae=0,me=h+p*2;Ae<me;Ae++){const T=H*Ae,E=H*(Ae+1),G=ce+ie+T,ae=ce+K+T,se=ce+K+E,ne=ce+ie+E;Pe(G,ae,se,ne)}}}function he(I,ce,Y){l.push(I),l.push(ce),l.push(Y)}function be(I,ce,Y){Se(I),Se(ce),Se(Y);const ie=s.length/3,K=M.generateTopUV(i,s,ie-3,ie-2,ie-1);De(K[0]),De(K[1]),De(K[2])}function Pe(I,ce,Y,ie){Se(I),Se(ce),Se(ie),Se(ce),Se(Y),Se(ie);const K=s.length/3,Ae=M.generateSideWallUV(i,s,K-6,K-3,K-2,K-1);De(Ae[0]),De(Ae[1]),De(Ae[3]),De(Ae[1]),De(Ae[2]),De(Ae[3])}function Se(I){s.push(l[I*3+0]),s.push(l[I*3+1]),s.push(l[I*3+2])}function De(I){r.push(I.x),r.push(I.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,i=this.parameters.options;return bg(t,i,e)}static fromJSON(e,t){const i=[];for(let r=0,a=e.shapes.length;r<a;r++){const o=t[e.shapes[r]];i.push(o)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new Da[s.type]().fromJSON(s)),new io(i,e.options)}}const xg={generateTopUV:function(n,e,t,i,s){const r=e[t*3],a=e[t*3+1],o=e[i*3],l=e[i*3+1],c=e[s*3],h=e[s*3+1];return[new ue(r,a),new ue(o,l),new ue(c,h)]},generateSideWallUV:function(n,e,t,i,s,r){const a=e[t*3],o=e[t*3+1],l=e[t*3+2],c=e[i*3],h=e[i*3+1],u=e[i*3+2],d=e[s*3],f=e[s*3+1],g=e[s*3+2],v=e[r*3],p=e[r*3+1],m=e[r*3+2];return Math.abs(o-h)<Math.abs(a-c)?[new ue(a,1-l),new ue(c,1-u),new ue(d,1-g),new ue(v,1-m)]:[new ue(o,1-l),new ue(h,1-u),new ue(f,1-g),new ue(p,1-m)]}};function bg(n,e,t){if(t.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){const r=n[i];t.shapes.push(r.uuid)}else t.shapes.push(n.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class gi extends Tr{constructor(e=1,t=0){const i=(1+Math.sqrt(5))/2,s=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new gi(e.radius,e.detail)}}class Cr extends Tr{constructor(e=1,t=0){const i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Cr(e.radius,e.detail)}}class Pt extends It{constructor(e=1,t=32,i=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const l=Math.min(a+o,Math.PI);let c=0;const h=[],u=new R,d=new R,f=[],g=[],v=[],p=[];for(let m=0;m<=i;m++){const M=[],_=m/i;let x=0;m===0&&a===0?x=.5/t:m===i&&l===Math.PI&&(x=-.5/t);for(let P=0;P<=t;P++){const w=P/t;u.x=-e*Math.cos(s+w*r)*Math.sin(a+_*o),u.y=e*Math.cos(a+_*o),u.z=e*Math.sin(s+w*r)*Math.sin(a+_*o),g.push(u.x,u.y,u.z),d.copy(u).normalize(),v.push(d.x,d.y,d.z),p.push(w+x,1-_),M.push(c++)}h.push(M)}for(let m=0;m<i;m++)for(let M=0;M<t;M++){const _=h[m][M+1],x=h[m][M],P=h[m+1][M],w=h[m+1][M+1];(m!==0||a>0)&&f.push(_,x,w),(m!==i-1||l<Math.PI)&&f.push(x,P,w)}this.setIndex(f),this.setAttribute("position",new st(g,3)),this.setAttribute("normal",new st(v,3)),this.setAttribute("uv",new st(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Pt(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class bt extends It{constructor(e=1,t=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);const a=[],o=[],l=[],c=[],h=new R,u=new R,d=new R;for(let f=0;f<=i;f++)for(let g=0;g<=s;g++){const v=g/s*r,p=f/i*Math.PI*2;u.x=(e+t*Math.cos(p))*Math.cos(v),u.y=(e+t*Math.cos(p))*Math.sin(v),u.z=t*Math.sin(p),o.push(u.x,u.y,u.z),h.x=e*Math.cos(v),h.y=e*Math.sin(v),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/s),c.push(f/i)}for(let f=1;f<=i;f++)for(let g=1;g<=s;g++){const v=(s+1)*f+g-1,p=(s+1)*(f-1)+g-1,m=(s+1)*(f-1)+g,M=(s+1)*f+g;a.push(v,p,M),a.push(p,m,M)}this.setIndex(a),this.setAttribute("position",new st(o,3)),this.setAttribute("normal",new st(l,3)),this.setAttribute("uv",new st(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new bt(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class Ft extends Ki{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Le(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Le(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Pc,this.normalScale=new ue(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Eg extends Ft{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new ue(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Et(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Le(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Le(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Le(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class Rr extends _t{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Le(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}}class oh extends Rr{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(_t.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Le(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const pa=new pt,Vl=new R,Wl=new R;class so{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ue(512,512),this.map=null,this.mapPass=null,this.matrix=new pt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ja,this._frameExtents=new ue(1,1),this._viewportCount=1,this._viewports=[new ct(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,i=this.matrix;Vl.setFromMatrixPosition(e.matrixWorld),t.position.copy(Vl),Wl.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Wl),t.updateMatrixWorld(),pa.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(pa),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(pa)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class wg extends so{constructor(){super(new Wt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){const t=this.camera,i=Wi*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height,r=e.distance||t.far;(i!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=i,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class Tg extends Rr{constructor(e,t,i=0,s=Math.PI/3,r=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(_t.DEFAULT_UP),this.updateMatrix(),this.target=new _t,this.distance=i,this.angle=s,this.penumbra=r,this.decay=a,this.map=null,this.shadow=new wg}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const Xl=new pt,is=new R,ma=new R;class Ag extends so{constructor(){super(new Wt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new ue(4,2),this._viewportCount=6,this._viewports=[new ct(2,1,1,1),new ct(0,1,1,1),new ct(3,1,1,1),new ct(1,1,1,1),new ct(3,0,1,1),new ct(1,0,1,1)],this._cubeDirections=[new R(1,0,0),new R(-1,0,0),new R(0,0,1),new R(0,0,-1),new R(0,1,0),new R(0,-1,0)],this._cubeUps=[new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,0,1),new R(0,0,-1)]}updateMatrices(e,t=0){const i=this.camera,s=this.matrix,r=e.distance||i.far;r!==i.far&&(i.far=r,i.updateProjectionMatrix()),is.setFromMatrixPosition(e.matrixWorld),i.position.copy(is),ma.copy(i.position),ma.add(this._cubeDirections[t]),i.up.copy(this._cubeUps[t]),i.lookAt(ma),i.updateMatrixWorld(),s.makeTranslation(-is.x,-is.y,-is.z),Xl.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Xl)}}class ro extends Rr{constructor(e,t,i=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=s,this.shadow=new Ag}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Cg extends so{constructor(){super(new Vc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class mr extends Rr{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(_t.DEFAULT_UP),this.updateMatrix(),this.target=new _t,this.shadow=new Cg}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Rg{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=$l(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=$l();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}function $l(){return(typeof performance>"u"?Date:performance).now()}class Pg{constructor(e,t,i=0,s=1/0){this.ray=new ja(e,t),this.near=i,this.far=s,this.camera=null,this.layers=new Ka,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return Fa(e,this,i,t),i.sort(ql),i}intersectObjects(e,t=!0,i=[]){for(let s=0,r=e.length;s<r;s++)Fa(e[s],this,i,t);return i.sort(ql),i}}function ql(n,e){return n.distance-e.distance}function Fa(n,e,t,i){if(n.layers.test(e.layers)&&n.raycast(e,t),i===!0){const s=n.children;for(let r=0,a=s.length;r<a;r++)Fa(s[r],e,t,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Sr}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Sr);const Lg={low:{shadows:!1,shadowMap:512,pixelRatio:1,particles:"low"},medium:{shadows:!0,shadowMap:1024,pixelRatio:1.25,particles:"medium"},high:{shadows:!0,shadowMap:2048,pixelRatio:1.75,particles:"high"}};class Ig{constructor(e,t="high"){this.clock=new Rg,this.callbacks=[],this.running=!1,this.activeScene=null,this.activeCamera=null,this.quality="high",this.fps=60,this.canvas=document.createElement("canvas"),this.canvas.id="gameCanvas",e.appendChild(this.canvas),this.renderer=new Kc({canvas:this.canvas,antialias:t!=="low",powerPreference:"high-performance",stencil:!1}),this.renderer.outputColorSpace=dt,this.renderer.toneMapping=Mc,this.renderer.toneMappingExposure=1.05,this.setQuality(t),window.addEventListener("resize",()=>this.resize()),this.resize()}setQuality(e){this.quality=e;const t=Lg[e];this.renderer.shadowMap.enabled=t.shadows,this.renderer.shadowMap.type=yc,this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,t.pixelRatio)),this.resize()}resize(){const e=window.innerWidth,t=window.innerHeight;this.renderer.setSize(e,t,!1);const i=this.activeCamera;i&&i.isPerspectiveCamera&&(i.aspect=e/t,i.updateProjectionMatrix())}onFrame(e){return this.callbacks.push(e),()=>{const t=this.callbacks.indexOf(e);t>=0&&this.callbacks.splice(t,1)}}setScene(e,t){this.activeScene=e,this.activeCamera=t,this.resize()}start(){if(this.running)return;this.running=!0;const e=()=>{if(!this.running)return;requestAnimationFrame(e);const t=Math.min(.05,this.clock.getDelta()),i=this.clock.elapsedTime;this.fps=this.fps*.93+1/Math.max(t,1e-4)*.07;for(const s of this.callbacks)s(t,i);this.activeScene&&this.activeCamera&&this.renderer.render(this.activeScene,this.activeCamera)};requestAnimationFrame(e)}stop(){this.running=!1}}class Dg{constructor(e=document.body){this.keys=new Set,this.mouse={x:0,y:0,dx:0,dy:0,left:!1,right:!1,middle:!1,wheel:0},this.enabled=!0,this.target=e,window.addEventListener("keydown",t=>{this.enabled&&(this.keys.add(t.code),["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Tab"].includes(t.code)&&t.preventDefault())}),window.addEventListener("keyup",t=>this.keys.delete(t.code)),window.addEventListener("blur",()=>this.keys.clear()),e.addEventListener("mousemove",t=>{const i=e.getBoundingClientRect();this.mouse.x=(t.clientX-i.left)/i.width*2-1,this.mouse.y=-((t.clientY-i.top)/i.height*2-1),this.mouse.dx+=t.movementX??0,this.mouse.dy+=t.movementY??0}),e.addEventListener("mousedown",t=>{t.button===0&&(this.mouse.left=!0),t.button===1&&(this.mouse.middle=!0),t.button===2&&(this.mouse.right=!0)}),window.addEventListener("mouseup",t=>{t.button===0&&(this.mouse.left=!1),t.button===1&&(this.mouse.middle=!1),t.button===2&&(this.mouse.right=!1)}),e.addEventListener("contextmenu",t=>t.preventDefault()),e.addEventListener("wheel",t=>{this.mouse.wheel+=t.deltaY,t.preventDefault()},{passive:!1})}down(e){return this.enabled&&this.keys.has(e)}axis(e,t){return(this.down(t)?1:0)-(this.down(e)?1:0)}endFrame(){this.mouse.dx=0,this.mouse.dy=0,this.mouse.wheel=0}}class Ug{constructor(){this.ctx=null,this.master=null,this.musicGain=null,this.sfxGain=null,this.musicTimer=null,this.musicVolume=.45,this.sfxVolume=.75,this.started=!1,this.noiseBuffer=null}init(){if(!this.started)try{const e=window.AudioContext||window.webkitAudioContext;this.ctx=new e,this.master=this.ctx.createGain(),this.master.gain.value=.9,this.master.connect(this.ctx.destination),this.musicGain=this.ctx.createGain(),this.musicGain.gain.value=this.musicVolume*.5,this.musicGain.connect(this.master),this.sfxGain=this.ctx.createGain(),this.sfxGain.gain.value=this.sfxVolume,this.sfxGain.connect(this.master);const t=this.ctx.sampleRate*2;this.noiseBuffer=this.ctx.createBuffer(1,t,this.ctx.sampleRate);const i=this.noiseBuffer.getChannelData(0);for(let s=0;s<t;s++)i[s]=Math.random()*2-1;this.started=!0,this.startAmbient()}catch{this.ctx=null}}setVolumes(e,t){this.musicVolume=e,this.sfxVolume=t,this.musicGain&&(this.musicGain.gain.value=e*.5),this.sfxGain&&(this.sfxGain.gain.value=t)}env(e,t,i,s=1){const r=this.ctx.currentTime;e.gain.cancelScheduledValues(r),e.gain.setValueAtTime(1e-4,r),e.gain.exponentialRampToValueAtTime(Math.max(1e-4,s),r+t),e.gain.exponentialRampToValueAtTime(1e-4,r+t+i)}tone(e,t=.2,i="sine",s=.3,r){if(!this.ctx||!this.sfxGain)return;const a=this.ctx.createOscillator(),o=this.ctx.createGain();a.type=i,a.frequency.setValueAtTime(e,this.ctx.currentTime),r&&a.frequency.exponentialRampToValueAtTime(Math.max(20,r),this.ctx.currentTime+t),a.connect(o),o.connect(this.sfxGain),this.env(o,.008,t,s),a.start(),a.stop(this.ctx.currentTime+t+.05)}noise(e=.3,t=1200,i=.3,s=1){if(!this.ctx||!this.sfxGain||!this.noiseBuffer)return;const r=this.ctx.createBufferSource();r.buffer=this.noiseBuffer;const a=this.ctx.createBiquadFilter();a.type="bandpass",a.frequency.value=t,a.Q.value=s;const o=this.ctx.createGain();r.connect(a),a.connect(o),o.connect(this.sfxGain),this.env(o,.005,e,i),r.start(),r.stop(this.ctx.currentTime+e+.05)}uiClick(){this.tone(880,.06,"triangle",.18,1320)}uiHover(){this.tone(1200,.03,"sine",.06)}uiBack(){this.tone(420,.09,"triangle",.14,260)}purchase(){this.tone(523,.1,"triangle",.22),setTimeout(()=>this.tone(784,.16,"triangle",.2),70)}error(){this.tone(180,.18,"sawtooth",.16,120)}place(){this.noise(.14,420,.25,2),this.tone(320,.1,"square",.1,220)}laser(){this.tone(1400,.12,"sawtooth",.12,420)}mining(){this.noise(.12,780,.06,6)}gun(){this.noise(.09,1500,.16,1.4),this.tone(140,.07,"square",.1,70)}rocket(){this.noise(.5,420,.2,.8),this.tone(90,.4,"sawtooth",.12,40)}explosion(e=1){this.noise(.7*e,220,.35,.6),this.tone(70,.5*e,"sine",.3,32)}shieldHit(){this.tone(640,.2,"sine",.2,940),this.noise(.12,2400,.1,3)}pickup(){this.tone(1046,.07,"sine",.12,1568)}cardReveal(e){const t=440+e*110;this.tone(t,.25,"triangle",.2,t*1.5),setTimeout(()=>this.tone(t*1.5,.35,"sine",.18,t*2),110),e>=4&&setTimeout(()=>this.tone(t*2,.6,"sine",.16,t*2.6),240)}launch(){this.tone(60,1.6,"sawtooth",.32,220),this.noise(1.8,300,.26,.5)}achievement(){[523,659,784,1046].forEach((e,t)=>setTimeout(()=>this.tone(e,.22,"triangle",.16),t*85))}startAmbient(){if(!this.ctx||!this.musicGain)return;const e=[110,146.83,164.81,196,220,246.94,293.66],t=()=>{if(!this.ctx||!this.musicGain)return;const i=e[Math.floor(Math.random()*e.length)];[i,i*1.5,i*2.01].forEach((r,a)=>{const o=this.ctx.createOscillator(),l=this.ctx.createGain(),c=this.ctx.createBiquadFilter();c.type="lowpass",c.frequency.value=900+Math.random()*600,o.type=a===2?"triangle":"sawtooth",o.frequency.value=r*(1+(Math.random()-.5)*.004),o.connect(c),c.connect(l),l.connect(this.musicGain);const h=this.ctx.currentTime,u=6+Math.random()*4;l.gain.setValueAtTime(1e-4,h),l.gain.exponentialRampToValueAtTime(.06/(a+1),h+2.5),l.gain.exponentialRampToValueAtTime(1e-4,h+u),o.start(h),o.stop(h+u+.2)}),Math.random()<.4&&setTimeout(()=>{const r=this.ctx.createOscillator(),a=this.ctx.createGain();r.type="sine",r.frequency.value=1200+Math.random()*900,r.connect(a),a.connect(this.musicGain);const o=this.ctx.currentTime;a.gain.setValueAtTime(1e-4,o),a.gain.exponentialRampToValueAtTime(.03,o+.02),a.gain.exponentialRampToValueAtTime(1e-4,o+1.6),r.start(o),r.stop(o+1.8)},Math.random()*3e3)};t(),this.musicTimer=window.setInterval(t,7e3)}dispose(){var e;this.musicTimer&&window.clearInterval(this.musicTimer),(e=this.ctx)==null||e.close()}}const ve=new Ug,Ng=.18,lh=[{id:"hull_basic",name:"Structural Hull",category:"structure",size:[1,1,1],mass:120,durability:260,energy:0,price:350,tier:1,maxLevel:5,description:"Load bearing frame segment. Connects modules and carries structural loads.",stats:{armor:4,cargo:6},color:7043733,accent:10466257},{id:"hull_reinforced",name:"Reinforced Hull",category:"structure",size:[1,1,1],mass:210,durability:540,energy:0,price:1400,tier:2,maxLevel:5,description:"Dense alloy lattice. Heavier, but survives far deeper into hostile sectors.",stats:{armor:14,cargo:8},color:5924994,accent:12767978},{id:"hull_composite",name:"Composite Spine",category:"structure",size:[2,1,1],mass:300,durability:820,energy:0,price:4200,tier:3,maxLevel:5,description:"Long carbon-ceramic spine used to extend large frames with low mass penalty.",stats:{armor:20,cargo:18},color:4871792,accent:9431295},{id:"cockpit_basic",name:"Command Cockpit",category:"command",size:[1,1,1],mass:180,durability:420,energy:2,price:0,tier:1,maxLevel:4,description:"Pressurised command module. Every ship requires exactly one cockpit.",stats:{energyCap:90,energyGen:16,torque:1},color:3029596,accent:58879},{id:"cockpit_tactical",name:"Tactical Bridge",category:"command",size:[2,1,1],mass:320,durability:700,energy:4,price:9800,tier:3,maxLevel:4,description:"Fleet-grade bridge with targeting computer. Improves turret tracking and torque.",stats:{energyCap:140,energyGen:14,torque:1.5,radarRange:180},color:2568527,accent:8086015},{id:"engine_basic",name:"Ion Thruster",category:"propulsion",size:[1,1,1],mass:140,durability:220,energy:4,price:600,tier:1,maxLevel:6,surfaceMount:!0,description:"Reliable ion drive. Thrust is applied from its real mounting point on the hull.",stats:{thrust:260,torque:.9},color:3819366,accent:3394815},{id:"engine_fusion",name:"Fusion Drive",category:"propulsion",size:[1,1,2],mass:310,durability:380,energy:16,price:3800,tier:2,maxLevel:6,surfaceMount:!0,description:"High output fusion drive. Large thrust, significant energy and heat footprint.",stats:{thrust:760,torque:1.2},color:3424350,accent:16747068},{id:"engine_vector",name:"Vector Manoeuvre Pod",category:"propulsion",size:[1,1,1],mass:90,durability:180,energy:5,price:2100,tier:2,maxLevel:6,surfaceMount:!0,description:"Gimballed RCS cluster dedicated to rotation authority and stabilisation.",stats:{thrust:120,torque:3.2},color:4016745,accent:10158079},{id:"engine_warp",name:"Warp Core Thruster",category:"propulsion",size:[2,1,2],mass:520,durability:640,energy:30,price:15200,tier:4,maxLevel:6,surfaceMount:!0,description:"Experimental drive that folds local space for extreme burst acceleration.",stats:{thrust:1850,torque:1.6},color:2831447,accent:12160255},{id:"laser_basic",name:"Basic Mining Laser",category:"mining",size:[1,1,1],mass:95,durability:180,energy:5,price:0,tier:1,maxLevel:6,surfaceMount:!0,description:"Entry level cutting laser. Carves ore from asteroid surfaces at short range.",stats:{miningDps:34,miningRange:95},color:3885667,accent:16731469},{id:"laser_advanced",name:"Advanced Mining Laser",category:"mining",size:[1,1,1],mass:130,durability:230,energy:14,price:2600,tier:2,maxLevel:6,surfaceMount:!0,description:"Focused twin-emitter laser with improved beam coherence and range.",stats:{miningDps:58,miningRange:130},color:3622495,accent:16742938},{id:"drill_plasma",name:"Plasma Drill",category:"mining",size:[1,1,2],mass:260,durability:420,energy:22,price:6400,tier:3,maxLevel:6,surfaceMount:!0,description:"Contact plasma drill. Enormous damage, short reach - fly in close.",stats:{miningDps:155,miningRange:72},color:3161429,accent:5504992},{id:"extractor_crystal",name:"Crystal Extractor",category:"mining",size:[1,1,1],mass:170,durability:260,energy:18,price:8800,tier:3,maxLevel:6,surfaceMount:!0,description:"Resonance extractor tuned to crystalline lattices. Boosts rare mineral yield.",stats:{miningDps:74,miningRange:120,rareBonus:.18},color:3358812,accent:12549119},{id:"beam_heavy",name:"Heavy Mining Beam",category:"mining",size:[2,1,1],mass:390,durability:520,energy:34,price:18600,tier:4,maxLevel:6,surfaceMount:!0,description:"Capital grade beam array. Shreds the largest rocks in the Void Frontier.",stats:{miningDps:290,miningRange:165},color:2963280,accent:16765286},{id:"magnet_basic",name:"Magnetic Collector",category:"collection",size:[1,1,1],mass:85,durability:160,energy:5,price:900,tier:1,maxLevel:6,surfaceMount:!0,description:"Electromagnetic coil that drags loose ore chunks toward the cargo intake.",stats:{magnetRange:60,magnetForce:95},color:3819108,accent:4514047},{id:"magnet_advanced",name:"Advanced Magnet",category:"collection",size:[1,1,1],mass:120,durability:200,energy:9,price:3400,tier:2,maxLevel:6,surfaceMount:!0,description:"Superconducting magnet with a far stronger and wider attraction field.",stats:{magnetRange:110,magnetForce:180},color:3555935,accent:8126442},{id:"collector_vacuum",name:"Vacuum Collector",category:"collection",size:[1,1,1],mass:150,durability:240,energy:12,price:6100,tier:3,maxLevel:6,surfaceMount:!0,description:"Funnel intake that sucks debris into the hold, including non-ferrous matter.",stats:{magnetRange:95,magnetForce:240,cargo:40},color:3358297,accent:10351871},{id:"collector_wide",name:"Wide-Range Collector",category:"collection",size:[2,1,1],mass:230,durability:320,energy:18,price:12400,tier:4,maxLevel:6,surfaceMount:!0,description:"Dual-ring field projector covering a huge radius around the ship.",stats:{magnetRange:210,magnetForce:215},color:3095125,accent:7339986},{id:"gun_machine",name:"Machine Gun",category:"weapon",size:[1,1,1],mass:110,durability:200,energy:3,price:1200,tier:1,maxLevel:6,surfaceMount:!0,description:"Rapid fire kinetic turret. Tracks targets and leads its shots automatically.",stats:{damage:9,fireRate:7.5,projectileSpeed:420,weaponRange:190},color:3950432,accent:16765286},{id:"gun_laser",name:"Laser Cannon",category:"weapon",size:[1,1,1],mass:140,durability:230,energy:11,price:3600,tier:2,maxLevel:6,surfaceMount:!0,description:"Pulse laser turret with instant travel time and excellent accuracy.",stats:{damage:34,fireRate:2.2,projectileSpeed:900,weaponRange:240},color:3687519,accent:16726891},{id:"gun_plasma",name:"Plasma Cannon",category:"weapon",size:[1,1,2],mass:260,durability:340,energy:19,price:8200,tier:3,maxLevel:6,surfaceMount:!0,description:"Launches superheated plasma bolts that splash damage across a small radius.",stats:{damage:76,fireRate:1.3,projectileSpeed:300,weaponRange:260,splash:18},color:3358811,accent:5504992},{id:"rocket_launcher",name:"Rocket Launcher",category:"weapon",size:[1,1,2],mass:300,durability:300,energy:9,price:9400,tier:3,maxLevel:6,surfaceMount:!0,description:"Fires physical rockets with real flight dynamics and explosive payloads.",stats:{damage:120,fireRate:.75,projectileSpeed:210,weaponRange:320,splash:34},color:3818073,accent:16747068},{id:"missile_battery",name:"Missile Battery",category:"weapon",size:[2,1,1],mass:340,durability:330,energy:14,price:16800,tier:4,maxLevel:6,surfaceMount:!0,description:"Six-tube guided battery. Missiles steer onto their target after launch.",stats:{damage:85,fireRate:1.6,projectileSpeed:180,weaponRange:360,splash:26,homing:2.6},color:3555418,accent:16739240},{id:"railgun",name:"Railgun",category:"weapon",size:[1,1,3],mass:480,durability:420,energy:28,price:24500,tier:5,maxLevel:6,surfaceMount:!0,description:"Magnetically accelerated slug that punches straight through heavy armour.",stats:{damage:340,fireRate:.42,projectileSpeed:1400,weaponRange:520},color:2897488,accent:10545663},{id:"shield_gen",name:"Shield Generator",category:"defense",size:[1,1,1],mass:190,durability:240,energy:15,price:4800,tier:2,maxLevel:6,description:"Projects an energy barrier that absorbs incoming damage before the hull.",stats:{shield:220,shieldRegen:11,energyCap:40},color:3358809,accent:4830975},{id:"armor_plate",name:"Reinforced Armor",category:"defense",size:[1,1,1],mass:280,durability:760,energy:0,price:2200,tier:2,maxLevel:6,description:"Ablative plating. Adds large flat durability to the whole assembly.",stats:{armor:42},color:5858170,accent:13556202},{id:"repair_module",name:"Repair Module",category:"defense",size:[1,1,1],mass:165,durability:260,energy:10,price:7200,tier:3,maxLevel:6,description:"Nanite swarm bay that slowly rebuilds damaged modules during flight.",stats:{repair:6.5},color:3424860,accent:6160294},{id:"drone_defense",name:"Defensive Drone Bay",category:"defense",size:[1,1,1],mass:210,durability:280,energy:13,price:13400,tier:4,maxLevel:6,description:"Deploys autonomous escort drones that orbit the ship and engage hostiles.",stats:{drones:1,damage:16,fireRate:1.6,weaponRange:200},color:3226711,accent:16769162},{id:"radar",name:"Radar Array",category:"utility",size:[1,1,1],mass:95,durability:150,energy:6,price:1800,tier:1,maxLevel:5,surfaceMount:!0,description:"Sweeps for hostile contacts and paints them on the expedition HUD.",stats:{radarRange:420},color:3621977,accent:7798704},{id:"scanner",name:"Resource Scanner",category:"utility",size:[1,1,1],mass:110,durability:170,energy:8,price:3200,tier:2,maxLevel:5,surfaceMount:!0,description:"Spectral analyser that reveals ore content and rare veins inside asteroids.",stats:{scanRange:380,rareBonus:.08},color:3490136,accent:11992942},{id:"generator",name:"Energy Generator",category:"utility",size:[1,1,1],mass:240,durability:300,energy:0,price:2900,tier:2,maxLevel:6,description:"Compact reactor. Required to run heavy lasers, shields and weapons.",stats:{energyGen:26,energyCap:90},color:3818329,accent:16765286},{id:"cargo_bay",name:"Cargo Expansion",category:"utility",size:[1,1,2],mass:180,durability:340,energy:1,price:2400,tier:1,maxLevel:6,description:"Pressurised hold that increases how much ore you can haul home.",stats:{cargo:160},color:4279139,accent:10466257},{id:"booster",name:"Thruster Booster",category:"utility",size:[1,1,1],mass:130,durability:210,energy:12,price:5600,tier:3,maxLevel:6,description:"Overcharges every installed engine with a flat thrust multiplier.",stats:{thrust:180,torque:.6},color:3424088,accent:16752350}],ka=new Map(lh.map(n=>[n.id,n]));function Je(n){const e=ka.get(n);if(!e)throw new Error(`Unknown module id: ${n}`);return e}function Ht(n,e){return n*(1+Ng*(e-1))}function ch(n,e){return Math.round(Math.max(250,n.price*.55)*Math.pow(1.72,e-1))}const gr={structure:"Structure",command:"Command",propulsion:"Propulsion",mining:"Mining",collection:"Collection",weapon:"Weapons",defense:"Defense",utility:"Utility"},Ba={0:[0,0,1],1:[1,0,0],2:[0,0,-1],3:[-1,0,0],4:[0,1,0],5:[0,-1,0]},hh={0:"FORE",1:"STARBOARD",2:"AFT",3:"PORT",4:"DORSAL",5:"VENTRAL"},vt=(n,e,t)=>`${n},${e},${t}`,sr=n=>n.split(",").map(Number);function Pr(n,e){const[t,i,s]=n.size;switch(e){case 0:case 2:return[t,i,s];case 1:case 3:return[s,i,t];default:return[t,s,i]}}function rs(n,e,t){const[i,s,r]=Pr(n,t),a=[];for(let o=0;o<i;o++)for(let l=0;l<s;l++)for(let c=0;c<r;c++)a.push([e[0]+o,e[1]+l,e[2]+c]);return a}function Yl(n,e,t){const[i,s,r]=Pr(n,t);return[e[0]+(i-1)/2,e[1]+(s-1)/2,e[2]+(r-1)/2]}const jl=(()=>{const n=[];for(let e=-1;e<=1;e++)for(let t=-1;t<=1;t++)n.push([e,0,t]);return n.push([0,0,2]),n})();class Hn{constructor(e=!0){if(this.cells=new Set,this.purchasedCells=new Set,this.modules=[],this.uidCounter=1,e)for(const t of jl)this.cells.add(vt(...t))}static starterShip(){const e=new Hn;return e.place("cockpit_basic",[0,0,1],0),e.place("hull_basic",[0,0,0],0),e.place("hull_basic",[-1,0,0],0),e.place("hull_basic",[1,0,0],0),e.place("engine_basic",[0,0,-1],2),e.place("laser_basic",[1,0,1],1),e}nextUid(){return`m${this.uidCounter++}`}hasCell(e){return this.cells.has(vt(...e))}get purchasedCount(){return this.purchasedCells.size}occupancy(){const e=new Map;for(const t of this.modules){const i=Je(t.defId);for(const s of rs(i,t.pos,t.orientation))e.set(vt(...s),t.uid)}return e}canBuyCell(e){if(this.hasCell(e))return!1;const[t,i,s]=e;return[[t+1,i,s],[t-1,i,s],[t,i+1,s],[t,i-1,s],[t,i,s+1],[t,i,s-1]].some(a=>this.hasCell(a))}buyCell(e){if(!this.canBuyCell(e))return!1;const t=vt(...e);return this.cells.add(t),this.purchasedCells.add(t),!0}checkPlacement(e,t,i,s){const r=Je(e),a=rs(r,t,i);for(const c of a)if(!this.hasCell(c))return{code:"out_of_grid",message:"Module extends outside your construction cells.",cells:[c]};const o=this.occupancy();for(const c of a){const h=o.get(vt(...c));if(h&&h!==s)return{code:"overlap",message:"Another module already occupies this volume.",cells:[c]}}if(r.category==="command"&&this.modules.find(h=>Je(h.defId).category==="command"&&h.uid!==s))return{code:"duplicate_cockpit",message:"A ship may only carry one command module."};if(r.surfaceMount){const c=Ba[i],[h,u,d]=Pr(r,i),f=[];for(let v=0;v<h;v++)for(let p=0;p<u;p++)for(let m=0;m<d;m++){const M=t[0]+v+c[0],_=t[1]+p+c[1],x=t[2]+m+c[2];v+c[0]>=0&&v+c[0]<h&&p+c[1]>=0&&p+c[1]<u&&m+c[2]>=0&&m+c[2]<d||f.push([M,_,x])}if(f.some(v=>{const p=o.get(vt(...v));return!!p&&p!==s}))return{code:"blocked_mount",message:`${r.name} needs a clear line of fire: its ${hh[i]} face is blocked.`}}const l=this.modules.filter(c=>c.uid!==s);if(l.length>0){const c=new Map;for(const u of l){const d=Je(u.defId);for(const f of rs(d,u.pos,u.orientation))c.set(vt(...f),u.uid)}if(!a.some(([u,d,f])=>c.has(vt(u+1,d,f))||c.has(vt(u-1,d,f))||c.has(vt(u,d+1,f))||c.has(vt(u,d-1,f))||c.has(vt(u,d,f+1))||c.has(vt(u,d,f-1))))return{code:"disconnected",message:"Modules must physically connect to the rest of the ship."}}return null}place(e,t,i=0,s=1){const r=this.checkPlacement(e,t,i);if(r)return r;const a=Je(e),o={uid:this.nextUid(),defId:e,pos:t,orientation:i,level:s,health:Ht(a.durability,s)};return this.modules.push(o),o}remove(e){const t=this.modules.findIndex(s=>s.uid===e);if(t<0)return!1;const[i]=this.modules.splice(t,1);return this.isConnected()?!0:(this.modules.splice(t,0,i),!1)}forceRemove(e){const t=this.modules.findIndex(i=>i.uid===e);return t<0?!1:(this.modules.splice(t,1),!0)}moduleAt(e){const t=this.occupancy().get(vt(...e));return this.modules.find(i=>i.uid===t)}isConnected(){if(this.modules.length<=1)return!0;const e=this.occupancy(),t=this.modules.find(r=>Je(r.defId).category==="command")??this.modules[0],i=new Set([t.uid]),s=[t];for(;s.length;){const r=s.shift(),a=Je(r.defId);for(const[o,l,c]of rs(a,r.pos,r.orientation)){const h=[vt(o+1,l,c),vt(o-1,l,c),vt(o,l+1,c),vt(o,l-1,c),vt(o,l,c+1),vt(o,l,c-1)];for(const u of h){const d=e.get(u);if(d&&!i.has(d)){i.add(d);const f=this.modules.find(g=>g.uid===d);f&&s.push(f)}}}}return i.size===this.modules.length}hasCockpit(){return this.modules.some(e=>Je(e.defId).category==="command")}sumStat(e,t=!0){let i=0;for(const s of this.modules){const a=Je(s.defId).stats[e];if(!a)continue;const o=t?this.efficiency(s):1;i+=Ht(a,s.level)*o}return i}efficiency(e){const t=Je(e.defId),i=Ht(t.durability,e.level),s=Math.max(0,Math.min(1,e.health/i));return s<=0?0:s>=.35?1:.25+s/.35*.75}maxHealth(e){return Ht(Je(e.defId).durability,e.level)}stats(){let e=0,t=0,i=0,s=0;for(const f of this.modules){const g=Je(f.defId),v=g.mass*(1+.06*(f.level-1)),p=Yl(g,f.pos,f.orientation);e+=v,t+=p[0]*v,i+=p[1]*v,s+=p[2]*v}const r=e>0?[t/e,i/e,s/e]:[0,0,0],a=this.sumStat("energyGen"),o=this.modules.reduce((f,g)=>f+Je(g.defId).energy,0),l=this.sumStat("armor",!1),c=this.modules.reduce((f,g)=>f+this.maxHealth(g),0)+l*4;let h=0,u=0;for(const f of this.modules){const g=Je(f.defId);if(g.category!=="weapon"&&!(g.category==="defense"&&g.stats.drones))continue;const v=Ht(g.stats.damage??0,f.level),p=g.stats.fireRate??0;h+=v*p*this.efficiency(f)*(g.stats.drones??1),u=Math.max(u,g.stats.weaponRange??0)}const d=this.sumStat("thrust");return{moduleCount:this.modules.length,mass:e,centerOfMass:r,thrust:d,torque:this.sumStat("torque"),cargo:this.sumStat("cargo",!1),energyGen:a,energyCap:this.sumStat("energyCap",!1),energyDraw:o,energyBalance:a-o,shield:this.sumStat("shield"),shieldRegen:this.sumStat("shieldRegen"),hull:c,armor:l,repair:this.sumStat("repair"),miningDps:this.sumStat("miningDps"),miningRange:this.modules.reduce((f,g)=>Math.max(f,Je(g.defId).stats.miningRange??0),0),magnetRange:this.modules.reduce((f,g)=>Math.max(f,Ht(Je(g.defId).stats.magnetRange??0,g.level)),0),magnetForce:this.sumStat("magnetForce"),weaponDps:h,weaponRange:u,scanRange:this.modules.reduce((f,g)=>Math.max(f,Je(g.defId).stats.scanRange??0),0),radarRange:this.modules.reduce((f,g)=>Math.max(f,Je(g.defId).stats.radarRange??0),0),rareBonus:this.sumStat("rareBonus",!1),drones:Math.floor(this.sumStat("drones",!1)),thrustToMass:e>0?d/e:0}}thrusters(){return this.modules.filter(e=>Je(e.defId).stats.thrust).map(e=>{const t=Je(e.defId),i=Ba[e.orientation];return{uid:e.uid,center:Yl(t,e.pos,e.orientation),dir:[-i[0],-i[1],-i[2]],thrust:Ht(t.stats.thrust??0,e.level)*this.efficiency(e),level:e.level}})}serialize(){return{cells:[...this.cells],purchased:[...this.purchasedCells],modules:this.modules.map(e=>({...e})),uidCounter:this.uidCounter}}static deserialize(e){const t=new Hn(!1);if(!e||!Array.isArray(e.cells))return Hn.starterShip();for(const i of e.cells)typeof i=="string"&&t.cells.add(i);for(const i of e.purchased??[])typeof i=="string"&&t.purchasedCells.add(i);for(const i of jl)t.cells.add(vt(...i));if(Array.isArray(e.modules))for(const i of e.modules)try{const s=Je(i.defId),r=Math.max(1,Math.min(s.maxLevel,Number(i.level)||1));t.modules.push({uid:String(i.uid??t.nextUid()),defId:i.defId,pos:[Number(i.pos[0])||0,Number(i.pos[1])||0,Number(i.pos[2])||0],orientation:Number(i.orientation)||0,level:r,health:Number.isFinite(i.health)?Math.max(0,Number(i.health)):Ht(s.durability,r)})}catch{}return t.uidCounter=Math.max(Number(e.uidCounter)||1,t.modules.length+1),!t.hasCockpit()&&"code"in t.place("cockpit_basic",[0,0,1],0)?Hn.starterShip():t}bounds(){const e=[1/0,1/0,1/0],t=[-1/0,-1/0,-1/0];for(const i of this.cells){const[s,r,a]=sr(i);e[0]=Math.min(e[0],s),e[1]=Math.min(e[1],r),e[2]=Math.min(e[2],a),t[0]=Math.max(t[0],s),t[1]=Math.max(t[1],r),t[2]=Math.max(t[2],a)}return Number.isFinite(e[0])?{min:e,max:t}:{min:[0,0,0],max:[0,0,0]}}}const Og=[{id:"m_rocks",period:"minute",name:"Quick Cut",description:"Break apart 5 asteroids before the timer resets.",stat:"asteroidsMined",base:5,tierScale:1.12,crystals:2,rarity:"common",motif:"mining",artSeed:8101},{id:"m_iron",period:"minute",name:"Iron Pickup",description:"Collect 20 units of ore.",stat:"oreCollected",base:20,tierScale:1.2,crystals:2,rarity:"common",motif:"collection",artSeed:8102},{id:"m_drones",period:"minute",name:"Two Down",description:"Destroy 2 hostile craft.",stat:"enemiesKilled",base:2,tierScale:1.08,crystals:3,rarity:"uncommon",motif:"combat",artSeed:8103},{id:"m_chunks",period:"minute",name:"Scrap Sweep",description:"Scoop up 10 floating resource chunks.",stat:"chunksCollected",base:10,tierScale:1.15,crystals:2,rarity:"common",motif:"collection",artSeed:8104},{id:"m_distance",period:"minute",name:"Burn Run",description:"Travel 500 distance units under thrust.",stat:"distance",base:500,tierScale:1.1,crystals:2,rarity:"common",motif:"exploration",artSeed:8105},{id:"m_damage",period:"minute",name:"Opening Volley",description:"Deal 400 damage with ship weapons.",stat:"damageDealt",base:400,tierScale:1.25,crystals:3,rarity:"uncommon",motif:"combat",artSeed:8106},{id:"m_credits",period:"minute",name:"Pocket Change",description:"Earn 600 credits.",stat:"creditsEarned",base:600,tierScale:1.3,crystals:2,rarity:"common",motif:"economy",artSeed:8107},{id:"m_rare",period:"minute",name:"Lucky Seam",description:"Find 1 rare mineral deposit.",stat:"rareFinds",base:1,tierScale:1,crystals:4,rarity:"rare",motif:"mining",artSeed:8108}],Fg=[{id:"h_rocks",period:"hourly",name:"Belt Harvest",description:"Mine 50 asteroids this hour.",stat:"asteroidsMined",base:50,tierScale:1.15,crystals:14,rarity:"uncommon",motif:"mining",artSeed:8201},{id:"h_kills",period:"hourly",name:"Hostile Sweep",description:"Defeat 10 enemy craft.",stat:"enemiesKilled",base:10,tierScale:1.12,crystals:16,rarity:"uncommon",motif:"combat",artSeed:8202},{id:"h_ore",period:"hourly",name:"Full Hold",description:"Collect 500 units of ore.",stat:"oreCollected",base:500,tierScale:1.25,crystals:15,rarity:"uncommon",motif:"collection",artSeed:8203},{id:"h_credits",period:"hourly",name:"Hour of Profit",description:"Earn 8,000 credits.",stat:"creditsEarned",base:8e3,tierScale:1.35,crystals:18,rarity:"rare",motif:"economy",artSeed:8204},{id:"h_expe",period:"hourly",name:"Two Sorties",description:"Complete 2 expeditions.",stat:"expeditions",base:2,tierScale:1,crystals:20,rarity:"rare",motif:"exploration",artSeed:8205},{id:"h_damage",period:"hourly",name:"Sustained Fire",description:"Deal 6,000 weapon damage.",stat:"damageDealt",base:6e3,tierScale:1.3,crystals:16,rarity:"uncommon",motif:"combat",artSeed:8206}],kg=[{id:"d_rocks",period:"daily",name:"Day Shift",description:"Mine 100 asteroids today.",stat:"asteroidsMined",base:100,tierScale:1.18,crystals:45,rarity:"rare",motif:"mining",artSeed:8301},{id:"d_credits",period:"daily",name:"Ten Thousand",description:"Earn 10,000 credits.",stat:"creditsEarned",base:1e4,tierScale:1.4,crystals:50,rarity:"rare",motif:"economy",artSeed:8302},{id:"d_expe",period:"daily",name:"Five Sorties",description:"Complete 5 expeditions.",stat:"expeditions",base:5,tierScale:1.05,crystals:55,rarity:"rare",motif:"exploration",artSeed:8303},{id:"d_upgrade",period:"daily",name:"Shop Floor",description:"Upgrade equipment 2 times.",stat:"moduleUpgrades",base:2,tierScale:1,crystals:48,rarity:"rare",motif:"engineering",artSeed:8304},{id:"d_kills",period:"daily",name:"Clear The Lanes",description:"Destroy 40 hostiles.",stat:"enemiesKilled",base:40,tierScale:1.15,crystals:52,rarity:"rare",motif:"combat",artSeed:8305},{id:"d_ore",period:"daily",name:"Bulk Freight",description:"Collect 3,000 ore.",stat:"oreCollected",base:3e3,tierScale:1.3,crystals:46,rarity:"rare",motif:"collection",artSeed:8306},{id:"d_pack",period:"daily",name:"Crew Call",description:"Open 1 crew card pack.",stat:"packsOpened",base:1,tierScale:1,crystals:40,rarity:"uncommon",motif:"collection",artSeed:8307},{id:"d_rare",period:"daily",name:"Deep Veins",description:"Find 6 rare mineral deposits.",stat:"rareFinds",base:6,tierScale:1.12,crystals:60,rarity:"epic",motif:"mining",artSeed:8308},{id:"d_module",period:"daily",name:"Refit",description:"Install 3 modules on your ship.",stat:"modulesInstalled",base:3,tierScale:1,crystals:42,rarity:"uncommon",motif:"engineering",artSeed:8309},{id:"d_distance",period:"daily",name:"Long Haul",description:"Travel 20,000 distance units.",stat:"distance",base:2e4,tierScale:1.2,crystals:44,rarity:"rare",motif:"exploration",artSeed:8310}],Bg=[{id:"w_rocks",period:"weekly",name:"Two Thousand Rocks",description:"Mine 2,000 asteroids this week.",stat:"asteroidsMined",base:2e3,tierScale:1.2,crystals:220,rarity:"epic",motif:"mining",artSeed:8401},{id:"w_kills",period:"weekly",name:"Three Hundred Hostiles",description:"Defeat 300 enemy craft.",stat:"enemiesKilled",base:300,tierScale:1.18,crystals:240,rarity:"epic",motif:"combat",artSeed:8402},{id:"w_expe",period:"weekly",name:"Fifty Expeditions",description:"Complete 50 expeditions.",stat:"expeditions",base:50,tierScale:1.1,crystals:260,rarity:"epic",motif:"exploration",artSeed:8403},{id:"w_sectors",period:"weekly",name:"Frontier Charts",description:"Unlock a new sector.",stat:"sectorsUnlocked",base:1,tierScale:1,crystals:300,rarity:"legendary",motif:"exploration",artSeed:8404},{id:"w_cells",period:"weekly",name:"Expansion Program",description:"Purchase 10 ship expansion cells.",stat:"cellsPurchased",base:10,tierScale:1.1,crystals:280,rarity:"epic",motif:"engineering",artSeed:8405},{id:"w_cards",period:"weekly",name:"Crew Roster",description:"Own 12 distinct crew cards.",stat:"cardsOwned",base:12,tierScale:1.15,crystals:250,rarity:"epic",motif:"collection",artSeed:8406},{id:"w_credits",period:"weekly",name:"Quarter Million",description:"Earn 250,000 credits.",stat:"creditsEarned",base:25e4,tierScale:1.45,crystals:320,rarity:"legendary",motif:"economy",artSeed:8407},{id:"w_ore",period:"weekly",name:"Industrial Scale",description:"Collect 40,000 ore.",stat:"oreCollected",base:4e4,tierScale:1.35,crystals:230,rarity:"epic",motif:"collection",artSeed:8408},{id:"w_packs",period:"weekly",name:"Pack Run",description:"Open 10 crew packs.",stat:"packsOpened",base:10,tierScale:1,crystals:210,rarity:"epic",motif:"collection",artSeed:8409},{id:"w_upgrades",period:"weekly",name:"Full Refit",description:"Perform 15 module upgrades.",stat:"moduleUpgrades",base:15,tierScale:1.1,crystals:245,rarity:"epic",motif:"engineering",artSeed:8410},{id:"w_rare",period:"weekly",name:"Rare Earth",description:"Find 120 rare mineral deposits.",stat:"rareFinds",base:120,tierScale:1.25,crystals:290,rarity:"legendary",motif:"mining",artSeed:8411},{id:"w_damage",period:"weekly",name:"Fleet Breaker",description:"Deal 500,000 weapon damage.",stat:"damageDealt",base:5e5,tierScale:1.35,crystals:270,rarity:"epic",motif:"combat",artSeed:8412},{id:"w_distance",period:"weekly",name:"Deep Range",description:"Travel 400,000 distance units.",stat:"distance",base:4e5,tierScale:1.2,crystals:225,rarity:"epic",motif:"exploration",artSeed:8413},{id:"w_shield",period:"weekly",name:"Wall Of Light",description:"Absorb 25,000 damage on shields.",stat:"shieldAbsorbed",base:25e3,tierScale:1.3,crystals:235,rarity:"epic",motif:"engineering",artSeed:8414},{id:"w_modules",period:"weekly",name:"Shipwright",description:"Install 40 modules.",stat:"modulesInstalled",base:40,tierScale:1.15,crystals:255,rarity:"epic",motif:"engineering",artSeed:8415},{id:"w_crystals",period:"weekly",name:"Crystal Vault",description:"Earn 600 crystals from achievements.",stat:"crystalsEarned",base:600,tierScale:1.2,crystals:310,rarity:"legendary",motif:"economy",artSeed:8416},{id:"w_chunks",period:"weekly",name:"Vacuum Duty",description:"Collect 6,000 resource chunks.",stat:"chunksCollected",base:6e3,tierScale:1.3,crystals:215,rarity:"epic",motif:"collection",artSeed:8417}],uh={minute:6e4,hourly:36e5,daily:864e5,weekly:6048e5},zg={minute:5,hourly:3,daily:7,weekly:15},Gg={minute:"MINUTE",hourly:"HOURLY",daily:"DAILY",weekly:"WEEKLY"},Hg={minute:Og,hourly:Fg,daily:kg,weekly:Bg};class Lt{constructor(e=49734321){let t=e>>>0||2654435769;const i=()=>{t=t+2654435769>>>0;let s=t;return s=Math.imul(s^s>>>16,569420461)>>>0,s=Math.imul(s^s>>>15,1935289751)>>>0,(s^s>>>15)>>>0};this.s0=i(),this.s1=i()}next(){let e=this.s0>>>0;const t=this.s1>>>0;return this.s0=t,e^=e<<23>>>0,e=(e^e>>>17^t^t>>>26)>>>0,this.s1=e,(this.s0+this.s1>>>0)%4294967296/4294967296}range(e,t){return e+this.next()*(t-e)}int(e,t){return Math.floor(this.range(e,t+1))}chance(e){return this.next()<e}pick(e){return e[Math.min(e.length-1,Math.floor(this.next()*e.length))]}shuffle(e){for(let t=e.length-1;t>0;t--){const i=Math.floor(this.next()*(t+1));[e[t],e[i]]=[e[i],e[t]]}return e}weighted(e,t){let i=0;for(const r of t)i+=r;let s=this.next()*i;for(let r=0;r<e.length;r++)if(s-=t[r],s<=0)return e[r];return e[e.length-1]}gauss(){return(this.next()+this.next()+this.next()+this.next()+this.next()+this.next()-3)/1.2247}}const Vg=new Lt((Date.now()^1597463007)>>>0);function hi(n){const e=new Lt(n),t=new Uint8Array(512),i=new Uint8Array(256);for(let a=0;a<256;a++)i[a]=a;e.shuffle(Array.from(i)).forEach((a,o)=>i[o]=a);for(let a=0;a<512;a++)t[a]=i[a&255];const s=a=>a*a*a*(a*(a*6-15)+10),r=(a,o,l)=>{switch(a&3){case 0:return o+l;case 1:return-o+l;case 2:return o-l;default:return-o-l}};return(a,o)=>{const l=Math.floor(a)&255,c=Math.floor(o)&255,h=a-Math.floor(a),u=o-Math.floor(o),d=s(h),f=s(u),g=t[t[l]+c],v=t[t[l]+c+1],p=t[t[l+1]+c],m=t[t[l+1]+c+1],M=ga(r(g,h,u),r(p,h-1,u),d),_=ga(r(v,h,u-1),r(m,h-1,u-1),d);return(ga(M,_,f)+1)*.5}}function ga(n,e,t){return n+(e-n)*t}function ut(n,e,t){return n<e?e:n>t?t:n}function $n(n,e,t,i=5,s=2,r=.5){let a=.5,o=1,l=0,c=0;for(let h=0;h<i;h++)l+=a*n(e*o,t*o),c+=a,a*=r,o*=s;return l/c}function rr(){return{progress:{},claimed:{},periodIndex:{},lifetime:{},totalCrystals:0,completedCount:0}}function dh(n,e){return Math.floor(e/uh[n])}function Wg(n,e){return(dh(n,e)+1)*uh[n]}function Xg(n,e){const t=n.base*Math.pow(n.tierScale,Math.max(0,e-1));return t<10?Math.max(1,Math.round(t)):t<100?Math.round(t/5)*5:t<1e3?Math.round(t/10)*10:t<1e5?Math.round(t/100)*100:Math.round(t/1e3)*1e3}function $g(n,e,t){const i=Hg[n],s=Math.min(zg[n],i.length);return new Lt(e*2654435761+n.length*97+n.charCodeAt(0)*7919>>>0).shuffle([...i]).slice(0,s).map(l=>({key:`${n}:${e}:${l.id}`,templateId:l.id,period:n,periodIndex:e,name:l.name,description:l.description,stat:l.stat,target:Xg(l,t),crystals:l.crystals,rarity:l.rarity,motif:l.motif,artSeed:l.artSeed,progress:0,claimed:!1}))}class Kl{constructor(e=rr()){this.active=[],this.tier=1,this.state=e}refresh(e,t=this.tier){var r;this.tier=t;const i=["minute","hourly","daily","weekly"],s=[];for(const a of i){const o=dh(a,e),l=this.state.periodIndex[a];if(l!==o){for(const c of Object.keys(this.state.progress))c.startsWith(`${a}:`)&&!c.startsWith(`${a}:${o}:`)&&delete this.state.progress[c];for(const c of Object.keys(this.state.claimed))c.startsWith(`${a}:`)&&!c.startsWith(`${a}:${o}:`)&&delete this.state.claimed[c];this.state.periodIndex[a]=o,l!==void 0&&((r=this.onRotate)==null||r.call(this,a))}for(const c of $g(a,o,t))c.progress=this.state.progress[c.key]??0,c.claimed=!!this.state.claimed[c.key],s.push(c)}return this.active=s,s}track(e,t,i=Date.now()){if(!(t<=0)){this.state.lifetime[e]=(this.state.lifetime[e]??0)+t,this.refresh(i);for(const s of this.active){if(s.stat!==e||s.claimed)continue;const r=this.state.progress[s.key]??0;if(r>=s.target)continue;const a=Math.min(s.target,r+t);this.state.progress[s.key]=a,s.progress=a,a>=s.target&&(s.completedAt=i)}}}setStat(e,t,i=Date.now()){this.state.lifetime[e]=Math.max(this.state.lifetime[e]??0,t),this.refresh(i);for(const s of this.active){if(s.stat!==e||s.claimed)continue;const r=Math.min(s.target,t);r>(this.state.progress[s.key]??0)&&(this.state.progress[s.key]=r,s.progress=r)}}isComplete(e){return(this.state.progress[e.key]??0)>=e.target}claim(e,t=Date.now()){this.refresh(t);const i=this.active.find(s=>s.key===e);return!i||this.state.claimed[e]||(this.state.progress[e]??0)<i.target?0:(this.state.claimed[e]=!0,i.claimed=!0,this.state.totalCrystals+=i.crystals,this.state.completedCount+=1,i.crystals)}claimAllReady(e=Date.now()){this.refresh(e);let t=0;for(const i of[...this.active])!i.claimed&&this.isComplete(i)&&(t+=this.claim(i.key,e));return t}msUntilReset(e,t=Date.now()){return Wg(e,t)-t}}function qg(n){n<0&&(n=0);const e=Math.floor(n/1e3),t=Math.floor(e/86400),i=Math.floor(e%86400/3600),s=Math.floor(e%3600/60),r=e%60;return t>0?`${t}d ${i}h`:i>0?`${i}h ${String(s).padStart(2,"0")}m`:s>0?`${s}m ${String(r).padStart(2,"0")}s`:`${r}s`}const hn=["common","uncommon","rare","epic","legendary","mythic","secret"],Mn={common:13358561,uncommon:4906624,rare:6333946,epic:12616956,legendary:16498468,mythic:16020150,secret:65488},Lr={common:"COMMON",uncommon:"UNCOMMON",rare:"RARE",epic:"EPIC",legendary:"LEGENDARY",mythic:"MYTHIC",secret:"SECRET"},fh={common:540,uncommon:270,rare:125,epic:48,legendary:13,mythic:3.4,secret:.6},va={miningMult:"Mining power",damageMult:"Weapon damage",lootMult:"Resource yield",speedMult:"Thrust",turnMult:"Turn rate",energyRegenMult:"Energy regen",magnetRangeMult:"Magnet range",shieldMult:"Shield capacity",shieldRegenMult:"Shield regen",armorMult:"Hull durability",cargoMult:"Cargo capacity",creditMult:"Credits earned",crystalMult:"Crystals earned",rareChance:"Rare mineral chance",fireRateMult:"Fire rate",repairMult:"Repair rate",hazardResist:"Hazard resistance"},ao=["rareChance","hazardResist"],ui=[{id:"c_deckhand",number:1,name:"Vash Orrin",role:"Deckhand",rarity:"common",motif:"miner",artSeed:1011,description:"Twelve years hauling ore crates in the Starter Belt. Knows every bolt of a cargo rig.",bonus:{key:"cargoMult",value:1.08}},{id:"c_welder",number:2,name:"Juno Pell",role:"Hull Welder",rarity:"common",motif:"engineer",artSeed:1022,description:"Patches plating mid-burn with a plasma torch and a steady hand.",bonus:{key:"armorMult",value:1.06}},{id:"c_gunhand",number:3,name:"Rell Cado",role:"Gun Hand",rarity:"common",motif:"gunner",artSeed:1033,description:"Fires first, files the report later. Never misses twice.",bonus:{key:"damageMult",value:1.07}},{id:"c_scrapper",number:4,name:"Mira Tesk",role:"Scrapper",rarity:"common",motif:"collector",artSeed:1044,description:"Can smell a profitable wreck three sectors away.",bonus:{key:"lootMult",value:1.07}},{id:"c_navigator",number:5,name:"Olen Brask",role:"Junior Navigator",rarity:"common",motif:"pilot",artSeed:1055,description:"Plots clean burns with nothing but a slide rule and stubbornness.",bonus:{key:"speedMult",value:1.06}},{id:"c_coiler",number:6,name:"Senna Vok",role:"Coil Technician",rarity:"common",motif:"engineer",artSeed:1066,description:"Keeps magnet coils cold and the intake hungry.",bonus:{key:"magnetRangeMult",value:1.1}},{id:"c_driller",number:7,name:"Garro Finn",role:"Drill Operator",rarity:"common",motif:"miner",artSeed:1077,description:"Cuts rock at the exact angle the ore wants to break.",bonus:{key:"miningMult",value:1.08}},{id:"c_quartermaster",number:8,name:"Lida Sorn",role:"Quartermaster",rarity:"common",motif:"commander",artSeed:1088,description:"Turns scrap into credits with a ledger and zero mercy.",bonus:{key:"creditMult",value:1.07}},{id:"c_sparky",number:9,name:"Cob Ivane",role:"Power Rigger",rarity:"common",motif:"engineer",artSeed:1099,description:"Rewires reactors while they are still warm. Mostly survives.",bonus:{key:"energyRegenMult",value:1.1}},{id:"c_spotter",number:10,name:"Ryn Dask",role:"Spotter",rarity:"common",motif:"scientist",artSeed:1110,description:"Reads asteroid density by the way light bends around it.",bonus:{key:"rareChance",value:.01}},{id:"u_marksman",number:11,name:"Kade Vorren",role:"Marksman",rarity:"uncommon",motif:"gunner",artSeed:2011,description:"Calibrates every turret by ear. The hum tells him when it is true.",bonus:{key:"damageMult",value:1.14}},{id:"u_prospector",number:12,name:"Ona Delacq",role:"Prospector",rarity:"uncommon",motif:"miner",artSeed:2022,description:"Maps ore veins in her sleep. Wakes up richer.",bonus:{key:"lootMult",value:1.15}},{id:"u_fieldeng",number:13,name:"Tam Herrick",role:"Field Engineer",rarity:"uncommon",motif:"engineer",artSeed:2033,description:"Carries more spare parts than the hangar inventory system admits exist.",bonus:{key:"repairMult",value:1.3}},{id:"u_helmsman",number:14,name:"Priya Sol",role:"Helmsman",rarity:"uncommon",motif:"pilot",artSeed:2044,description:"Threads debris fields at full burn without scratching the paint.",bonus:{key:"turnMult",value:1.22}},{id:"u_magnetics",number:15,name:"Dex Halloran",role:"Magnetics Officer",rarity:"uncommon",motif:"collector",artSeed:2055,description:"Tunes collector fields until loose ore practically jumps aboard.",bonus:{key:"magnetRangeMult",value:1.25}},{id:"u_shieldtech",number:16,name:"Ivette Morr",role:"Shield Technician",rarity:"uncommon",motif:"engineer",artSeed:2066,description:"Folds barrier harmonics so impacts bleed off sideways.",bonus:{key:"shieldMult",value:1.2}},{id:"u_assayer",number:17,name:"Bram Osei",role:"Assayer",rarity:"uncommon",motif:"scientist",artSeed:2077,description:"One glance at a core sample and he names its market price.",bonus:{key:"creditMult",value:1.14}},{id:"u_loader",number:18,name:"Hestia Quon",role:"Cargo Chief",rarity:"uncommon",motif:"collector",artSeed:2088,description:"Stacks a hold so tightly physics files a complaint.",bonus:{key:"cargoMult",value:1.22}},{id:"u_stormwalker",number:19,name:"Niko Rask",role:"Storm Walker",rarity:"uncommon",motif:"void",artSeed:2099,description:"Walked a hull during a plasma storm. Came back grinning.",bonus:{key:"hazardResist",value:.12}},{id:"r_collector",number:20,name:"Sable Ferriq",role:"Rare Collector",rarity:"rare",motif:"collector",artSeed:3011,description:"Her collector rigs pull ore from distances that should not work.",bonus:{key:"magnetRangeMult",value:1.4},bonus2:{key:"lootMult",value:1.1}},{id:"r_laserist",number:21,name:"Toma Reyes",role:"Beam Specialist",rarity:"rare",motif:"miner",artSeed:3022,description:"Splits a mining beam into harmonics that shatter rock from within.",bonus:{key:"miningMult",value:1.35}},{id:"r_tactician",number:22,name:"Edda Kwan",role:"Fire Tactician",rarity:"rare",motif:"gunner",artSeed:3033,description:"Sequences turret volleys so nothing in range gets a second move.",bonus:{key:"fireRateMult",value:1.3}},{id:"r_voidscout",number:23,name:"Asha Vel",role:"Void Scout",rarity:"rare",motif:"pilot",artSeed:3044,description:"Flies the gaps between gravity wells where charts simply end.",bonus:{key:"speedMult",value:1.3},bonus2:{key:"turnMult",value:1.12}},{id:"r_reactorist",number:24,name:"Quill Baran",role:"Reactor Savant",rarity:"rare",motif:"engineer",artSeed:3055,description:"Runs the core hotter than spec and somehow keeps it stable.",bonus:{key:"energyRegenMult",value:1.45}},{id:"r_geologist",number:25,name:"Mei Thornwood",role:"Exo-Geologist",rarity:"rare",motif:"scientist",artSeed:3066,description:"Finds crystalline seams other crews fly straight past.",bonus:{key:"rareChance",value:.06}},{id:"r_armorer",number:26,name:"Bosk Tiller",role:"Master Armorer",rarity:"rare",motif:"engineer",artSeed:3077,description:"Layers ablative plate so damage sheds off in sheets.",bonus:{key:"armorMult",value:1.32}},{id:"r_broker",number:27,name:"Cyra Noll",role:"Ore Broker",rarity:"rare",motif:"commander",artSeed:3088,description:"Sells your haul twice before the hold doors finish closing.",bonus:{key:"creditMult",value:1.32}},{id:"e_engineer",number:28,name:"Dr. Ilse Varga",role:"Chief Engineer",rarity:"epic",motif:"engineer",artSeed:4011,description:"Rebuilt a fusion drive mid-expedition using salvage and spite.",bonus:{key:"energyRegenMult",value:1.5},bonus2:{key:"repairMult",value:1.4}},{id:"e_gunnery",number:29,name:"Captain Roth Vane",role:"Gunnery Officer",rarity:"epic",motif:"gunner",artSeed:4022,description:"Commands the batteries like an orchestra of very loud instruments.",bonus:{key:"damageMult",value:1.55},bonus2:{key:"fireRateMult",value:1.15}},{id:"e_driller",number:30,name:"Vonn Macek",role:"Deep Driller",rarity:"epic",motif:"miner",artSeed:4033,description:"Takes the plasma drill into cores nobody else will touch.",bonus:{key:"miningMult",value:1.6}},{id:"e_shieldwright",number:31,name:"Lyra Ashenfeld",role:"Shieldwright",rarity:"epic",motif:"commander",artSeed:4044,description:"Her barrier geometry turns direct hits into light shows.",bonus:{key:"shieldMult",value:1.6},bonus2:{key:"shieldRegenMult",value:1.35}},{id:"e_navigator",number:32,name:"Sol Arcadi",role:"Master Navigator",rarity:"epic",motif:"pilot",artSeed:4055,description:"Charts burns that arrive before the fuel budget says they should.",bonus:{key:"speedMult",value:1.5},bonus2:{key:"turnMult",value:1.3}},{id:"e_logistician",number:33,name:"Hara Dune",role:"Logistics Master",rarity:"epic",motif:"collector",artSeed:4066,description:"Every cubic metre of your hold now earns its keep.",bonus:{key:"cargoMult",value:1.7},bonus2:{key:"creditMult",value:1.2}},{id:"e_stormrider",number:34,name:"Ozan Krieg",role:"Storm Rider",rarity:"epic",motif:"void",artSeed:4077,description:"Surfs plasma discharges for the fun of it. Comes back with rare ore.",bonus:{key:"hazardResist",value:.3},bonus2:{key:"rareChance",value:.04}},{id:"l_gunner",number:35,name:'Zara "Triplecross" Bale',role:"Legendary Gunner",rarity:"legendary",motif:"gunner",artSeed:5011,description:"Three confirmed kills with one railgun slug. Triples your damage output.",bonus:{key:"damageMult",value:3}},{id:"l_pilot",number:36,name:"Kesh Orlov",role:"Legendary Pilot",rarity:"legendary",motif:"pilot",artSeed:5022,description:"The only pilot to outrun a Void Sentinel. Doubles your ship speed.",bonus:{key:"speedMult",value:2},bonus2:{key:"turnMult",value:1.4}},{id:"l_forge",number:37,name:"Magda Iversen",role:"Legendary Forgewright",rarity:"legendary",motif:"engineer",artSeed:5033,description:"Her plating survived a direct plasma lance. Twice.",bonus:{key:"armorMult",value:2},bonus2:{key:"repairMult",value:1.6}},{id:"l_prospector",number:38,name:"Idris Falk",role:"Legendary Prospector",rarity:"legendary",motif:"miner",artSeed:5044,description:"Finds the mother lode on the first core sample. Every time.",bonus:{key:"lootMult",value:2.2},bonus2:{key:"miningMult",value:1.3}},{id:"l_quartermaster",number:39,name:"Senator Vane Dulac",role:"Legendary Financier",rarity:"legendary",motif:"commander",artSeed:5055,description:"Owns the exchange. Your ore sells at frankly unreasonable prices.",bonus:{key:"creditMult",value:2.1},bonus2:{key:"crystalMult",value:1.3}},{id:"m_miner",number:40,name:"The Hollow Prospector",role:"Mythic Miner",rarity:"mythic",motif:"miner",artSeed:6011,description:"A sealed suit with no occupant on scan. It mines. The hold fills fivefold.",bonus:{key:"lootMult",value:5}},{id:"m_commander",number:41,name:"Admiral Sayen Kol",role:"Mythic Commander",rarity:"mythic",motif:"commander",artSeed:6022,description:"Lost a fleet, kept the doctrine. Doubles shield capacity outright.",bonus:{key:"shieldMult",value:2},bonus2:{key:"shieldRegenMult",value:1.8}},{id:"m_engine",number:42,name:"Oracle Unit NERA-9",role:"Mythic Intelligence",rarity:"mythic",motif:"scientist",artSeed:6033,description:"Predicts the fracture plane of every rock before the beam lands.",bonus:{key:"miningMult",value:2.4},bonus2:{key:"energyRegenMult",value:1.9}},{id:"s_scientist",number:43,name:"Dr. Ophelia Rax",role:"Secret Scientist",rarity:"secret",motif:"scientist",artSeed:7011,description:"Her resonance theory rewrites what counts as a rare mineral.",bonus:{key:"rareChance",value:.25},bonus2:{key:"crystalMult",value:1.6}},{id:"s_void",number:44,name:"THE VOID WALKER",role:"Secret Anomaly",rarity:"secret",motif:"void",artSeed:7022,description:"Signed on with no name, no record and no reflection. Everything improves.",bonus:{key:"damageMult",value:1.8},bonus2:{key:"lootMult",value:1.8}}],vr=new Map(ui.map(n=>[n.id,n])),Yg=hn.reduce((n,e)=>(n[e]=ui.filter(t=>t.rarity===e),n),{}),ph={common:2,uncommon:4,rare:9,epic:22,legendary:60,mythic:160,secret:400};function ds(n,e){if(ao.includes(n))return`+${Math.round(e*100)}% ${va[n]}`;const t=Math.round((e-1)*100);return e>=2?`x${e.toFixed(e%1===0?0:1)} ${va[n]}`:`+${t}% ${va[n]}`}function jg(n){const e={},t=new Set;for(const i of n){if(t.has(i))continue;t.add(i);const s=vr.get(i);if(s)for(const r of[s.bonus,s.bonus2]){if(!r)continue;const a=r.key;ao.includes(a)?e[a]=(e[a]??0)+r.value:e[a]=(e[a]??1)*r.value}}return e}function Ot(n,e){return n[e]??1}function Jl(n,e){return n[e]??0}function Kg(n,e){const t={...n};for(const i of e){const s=i.key;ao.includes(s)?t[s]=(t[s]??0)+i.value:t[s]=(t[s]??1)*i.value}return t}function Jg(n,e,t){const i=[];for(const s of n){if(i.length>=e)break;t.has(s)&&(i.includes(s)||vr.has(s)&&i.push(s))}return i}const Zg=420,Qg=1.055,_s=10;function mh(n){return Math.round(Zg*Math.pow(Qg,n))}function za(n){return Math.floor(Math.max(0,n)/_s)}function gh(n){const e=Math.max(0,n)%_s;return _s-e}function vh(n){return Math.max(0,n)%_s/_s}function ev(n,e,t){const i=n*.5+e*6+t*.8;return i<14?1:i<34?2:i<70?3:i<130?4:5}const tv=3,yr=5,Zl=185e3,oo=.01,Ga=[{id:"overclock",name:"Beam Overclock",description:"+35% mining damage for the whole expedition.",effect:{key:"miningMult",value:1.35},price:6500,tier:1,color:16739146},{id:"autoloader",name:"Autoloader",description:"+30% weapon fire rate.",effect:{key:"fireRateMult",value:1.3},price:8200,tier:1,color:16765286},{id:"coil_boost",name:"Coil Supercharge",description:"+60% magnet range.",effect:{key:"magnetRangeMult",value:1.6},price:5400,tier:1,color:4514047},{id:"reinforce",name:"Field Reinforcement",description:"+45% hull durability.",effect:{key:"armorMult",value:1.45},price:9100,tier:2,color:13556202},{id:"cargo_fold",name:"Folded Hold",description:"+80% cargo capacity.",effect:{key:"cargoMult",value:1.8},price:11800,tier:2,color:10466257},{id:"battle_tune",name:"Battle Tuning",description:"+50% weapon damage.",effect:{key:"damageMult",value:1.5},price:14500,tier:2,color:16726891},{id:"prospect",name:"Prospector Protocol",description:"+12% rare mineral chance.",effect:{key:"rareChance",value:.12},price:19500,tier:3,color:12549119},{id:"afterburn",name:"Afterburner Mix",description:"+45% thrust.",effect:{key:"speedMult",value:1.45},price:16200,tier:3,color:5504992},{id:"barrier",name:"Harmonic Barrier",description:"+70% shield capacity and regen.",effect:{key:"shieldMult",value:1.7},price:21800,tier:3,color:4830975},{id:"market_link",name:"Market Uplink",description:"+40% credits earned.",effect:{key:"creditMult",value:1.4},price:26500,tier:4,color:16758528}],Ql=new Map(Ga.map(n=>[n.id,n]));function ec(n,e){let t=tv;return n&&t++,e&&t++,Math.min(yr,t)}function nv(n,e){return n?!1:e<oo}const yt={iron:{id:"iron",name:"Iron",color:11581122,value:3,rare:!1},copper:{id:"copper",name:"Copper",color:14256978,value:5,rare:!1},silicate:{id:"silicate",name:"Silicate",color:10474696,value:7,rare:!1},titanium:{id:"titanium",name:"Titanium",color:14148596,value:14,rare:!1},crystal:{id:"crystal",name:"Lumen Crystal",color:8118527,value:32,rare:!0},plasmite:{id:"plasmite",name:"Plasmite",color:16747068,value:55,rare:!0},voidium:{id:"voidium",name:"Voidium",color:12160255,value:120,rare:!0},aurum:{id:"aurum",name:"Aurum Shard",color:16765286,value:85,rare:!0}},_r=[{id:"starter_belt",index:0,name:"STARTER BELT",tagline:"Common ore. Low danger.",description:"A quiet training belt of iron and copper rubble, patrolled by a handful of scout drones.",unlockCost:0,danger:1,ambient:2767974,fog:395804,sun:16773846,sun2:3828991,nebula:[2375807,1055290],resourceTable:{iron:58,copper:26,silicate:12,titanium:3,crystal:1},asteroidCount:42,asteroidScale:[5,13],rockStyle:"basalt",enemies:[{type:"scout",weight:85},{type:"raider",weight:15}],enemyBudget:5,hazard:"none",rewardMultiplier:1},{id:"crystal_nebula",index:1,name:"CRYSTAL NEBULA",tagline:"Rare crystals. Colourful cosmic clouds.",description:"Luminous gas shrouds crystalline asteroids that refract your mining beams into rainbows.",unlockCost:14e3,danger:2,ambient:4927354,fog:1181222,sun:16766719,sun2:58879,nebula:[9124824,2822240],resourceTable:{silicate:30,crystal:34,iron:18,titanium:12,aurum:6},asteroidCount:46,asteroidScale:[6,16],rockStyle:"crystal",enemies:[{type:"scout",weight:45},{type:"raider",weight:40},{type:"heavy",weight:15}],enemyBudget:8,hazard:"debris",rewardMultiplier:1.4},{id:"iron_graveyard",index:2,name:"IRON GRAVEYARD",tagline:"Abandoned hulls. Hostile drones.",description:"A battlefield frozen in vacuum: shattered capital ships, drifting plate and automated killers.",unlockCost:42e3,danger:3,ambient:3817810,fog:658708,sun:13227775,sun2:16739146,nebula:[3951200,1382431],resourceTable:{iron:40,titanium:32,copper:16,crystal:6,aurum:6},asteroidCount:40,asteroidScale:[6,18],rockStyle:"metal",enemies:[{type:"raider",weight:40},{type:"heavy",weight:38},{type:"scout",weight:22}],enemyBudget:12,hazard:"debris",rewardMultiplier:1.9},{id:"plasma_storm",index:3,name:"PLASMA STORM",tagline:"Electrical hazards. Rare minerals.",description:"Arc discharges sweep the field. Ride the gaps between strikes to reach the plasmite veins.",unlockCost:96e3,danger:4,ambient:8010271,fog:1837574,sun:16754253,sun2:4830975,nebula:[16742959,3805702],resourceTable:{plasmite:34,titanium:24,crystal:18,iron:14,aurum:10},asteroidCount:38,asteroidScale:[7,20],rockStyle:"volcanic",enemies:[{type:"plasma",weight:46},{type:"heavy",weight:30},{type:"raider",weight:24}],enemyBudget:15,hazard:"lightning",rewardMultiplier:2.6},{id:"void_frontier",index:4,name:"VOID FRONTIER",tagline:"Extreme resources. Lethal guardians.",description:"Past the last beacon. Voidium drifts here, guarded by sentinels that predate the charts.",unlockCost:22e4,danger:5,ambient:1781311,fog:198156,sun:10479871,sun2:12160255,nebula:[1724270,396314],resourceTable:{voidium:34,plasmite:22,aurum:20,crystal:14,titanium:10},asteroidCount:34,asteroidScale:[8,24],rockStyle:"void",enemies:[{type:"sentinel",weight:42},{type:"plasma",weight:30},{type:"heavy",weight:28}],enemyBudget:20,hazard:"anomaly",rewardMultiplier:3.6}];new Map(_r.map(n=>[n.id,n]));const tc={scout:{type:"scout",name:"Scout Drone",hull:120,shield:0,speed:46,turn:1.9,damage:7,fireRate:1.6,range:140,projectileSpeed:220,credits:180,scale:1,color:7176092,accent:16739179,behaviour:"orbit"},raider:{type:"raider",name:"Raider Ship",hull:340,shield:60,speed:38,turn:1.4,damage:15,fireRate:2.1,range:180,projectileSpeed:260,credits:460,scale:1.5,color:8018506,accent:16753212,behaviour:"strafe"},heavy:{type:"heavy",name:"Heavy Drone",hull:820,shield:160,speed:24,turn:.8,damage:34,fireRate:.9,range:210,projectileSpeed:190,credits:1100,scale:2.1,color:6055026,accent:16726891,behaviour:"charge"},plasma:{type:"plasma",name:"Plasma Hunter",hull:640,shield:320,speed:42,turn:1.6,damage:44,fireRate:1.1,range:250,projectileSpeed:300,credits:1850,scale:1.8,color:8011627,accent:5504992,behaviour:"strafe"},sentinel:{type:"sentinel",name:"Void Sentinel",hull:2400,shield:900,speed:30,turn:1.1,damage:78,fireRate:.75,range:330,projectileSpeed:420,credits:5200,scale:3,color:3029847,accent:12160255,behaviour:"sniper"}},nc=3,ic="spaceminer.save.v3";function sc(){return{musicVolume:.45,sfxVolume:.75,reducedMotion:!1,cameraSensitivity:1,quality:"high",invertY:!1,skipPackAnimation:!1}}function rc(){return{asteroidsMined:0,enemiesKilled:0,oreCollected:0,creditsEarned:0,crystalsEarned:0,expeditions:0,distance:0,packsOpened:0,deepestSector:0,playTimeMs:0,rareFinds:0,damageDealt:0}}function ac(n){const e=JSON.stringify(n);let t=2166136261;for(let i=0;i<e.length;i++)t^=e.charCodeAt(i),t=Math.imul(t,16777619);return t>>>0}class ri{constructor(){this.credits=2500,this.crystals=120,this.ship=Hn.starterShip(),this.inventory={hull_basic:2},this.ore={},this.crew=new Set,this.equippedCrew=[],this.activeUpgrades=[null,null,null,null,null],this.ownedUpgrades={},this.fourthSlotPurchased=!1,this.fifthSlotUnlocked=!1,this.unlockedSectors=new Set(["starter_belt"]),this.achievements=new Kl(rr()),this.settings=sc(),this.stats=rc(),this.packPity=0,this.loadWarning=null}get crewSlots(){return za(this.ship.purchasedCount)}get upgradeSlots(){return ec(this.fourthSlotPurchased,this.fifthSlotUnlocked)}get tier(){return ev(this.ship.purchasedCount,this.unlockedSectors.size,this.ship.modules.length)}bonuses(){const e=jg(this.equippedCrew),t=this.activeUpgrades.slice(0,this.upgradeSlots).filter(i=>!!i).map(i=>{var s;return(s=Ql.get(i))==null?void 0:s.effect}).filter(i=>!!i);return Kg(e,t)}addCredits(e){e<=0||(this.credits+=e,this.stats.creditsEarned+=e,this.achievements.track("creditsEarned",e))}spendCredits(e){return e>this.credits?!1:(this.credits-=e,!0)}addCrystals(e){e<=0||(this.crystals+=e,this.stats.crystalsEarned+=e,this.achievements.track("crystalsEarned",e))}spendCrystals(e){return e>this.crystals?!1:(this.crystals-=e,!0)}trackStat(e,t){this.achievements.track(e,t)}buyModule(e){const t=ka.get(e);return!t||!this.spendCredits(t.price)?!1:(this.inventory[e]=(this.inventory[e]??0)+1,!0)}takeFromInventory(e){return(this.inventory[e]??0)<=0?!1:(this.inventory[e]-=1,this.inventory[e]<=0&&delete this.inventory[e],!0)}returnToInventory(e){this.inventory[e]=(this.inventory[e]??0)+1}upgradeModule(e){const t=this.ship.modules.find(r=>r.uid===e);if(!t)return!1;const i=Je(t.defId);if(t.level>=i.maxLevel)return!1;const s=ch(i,t.level);return this.spendCredits(s)?(t.level+=1,t.health=Ht(i.durability,t.level),this.achievements.track("moduleUpgrades",1),!0):!1}equipCrew(e){return!this.crew.has(e)||this.equippedCrew.includes(e)||this.equippedCrew.length>=this.crewSlots?!1:(this.equippedCrew.push(e),!0)}unequipCrew(e){const t=this.equippedCrew.indexOf(e);return t<0?!1:(this.equippedCrew.splice(t,1),!0)}grantCard(e){return!vr.has(e)||this.crew.has(e)?!1:(this.crew.add(e),this.achievements.setStat("cardsOwned",this.crew.size),!0)}setActiveUpgrade(e,t){return e<0||e>=this.upgradeSlots||t&&!this.ownedUpgrades[t]||t&&this.activeUpgrades.indexOf(t)>=0&&this.activeUpgrades.indexOf(t)!==e?!1:(this.activeUpgrades[e]=t,this.achievements.setStat("upgradesInstalled",this.activeUpgrades.filter(Boolean).length),!0)}unlockSector(e){const t=_r.find(i=>i.id===e);return!t||this.unlockedSectors.has(e)||!this.spendCredits(t.unlockCost)?!1:(this.unlockedSectors.add(e),this.stats.deepestSector=Math.max(this.stats.deepestSector,t.index),this.achievements.track("sectorsUnlocked",1),this.achievements.setStat("cardsOwned",this.crew.size),!0)}serialize(){const e={version:nc,savedAt:Date.now(),credits:Math.round(this.credits),crystals:Math.round(this.crystals),ship:this.ship.serialize(),inventory:{...this.inventory},ore:{...this.ore},crew:[...this.crew],equippedCrew:[...this.equippedCrew],activeUpgrades:[...this.activeUpgrades],ownedUpgrades:{...this.ownedUpgrades},fourthSlotPurchased:this.fourthSlotPurchased,fifthSlotUnlocked:this.fifthSlotUnlocked,unlockedSectors:[...this.unlockedSectors],achievements:this.achievements.state,settings:{...this.settings},stats:{...this.stats},packPity:this.packPity};return e.checksum=ac({...e,checksum:void 0}),e}static deserialize(e){const t=new ri;let i=null;if(!e||typeof e!="object")return{state:t,warning:"No save data found - starting a new campaign."};const s=e;if(typeof s.version!="number"||s.version>nc)return{state:t,warning:"Save was written by a newer version - starting fresh to avoid corruption."};s.checksum!==void 0&&ac({...s,checksum:void 0})!==s.checksum&&(i="Save checksum mismatch - recovered what could be validated.");const r=(c,h)=>Number.isFinite(c)&&c>=0?c:h;t.credits=r(s.credits,2500),t.crystals=r(s.crystals,120),t.packPity=r(s.packPity,0);try{t.ship=Hn.deserialize(s.ship)}catch{i="Ship layout could not be restored - rebuilt the starter frame.",t.ship=Hn.starterShip()}if(t.inventory={},s.inventory&&typeof s.inventory=="object")for(const[c,h]of Object.entries(s.inventory))ka.has(c)&&Number.isFinite(h)&&h>0&&(t.inventory[c]=Math.floor(h));if(t.ore={},s.ore&&typeof s.ore=="object")for(const[c,h]of Object.entries(s.ore))Number.isFinite(h)&&h>0&&(t.ore[c]=h);if(t.crew=new Set((s.crew??[]).filter(c=>vr.has(c))),t.fourthSlotPurchased=!!s.fourthSlotPurchased,t.fifthSlotUnlocked=!!s.fifthSlotUnlocked,t.equippedCrew=Jg(s.equippedCrew??[],za(t.ship.purchasedCount),t.crew),t.ownedUpgrades={},s.ownedUpgrades&&typeof s.ownedUpgrades=="object")for(const[c,h]of Object.entries(s.ownedUpgrades))Ql.has(c)&&Number.isFinite(h)&&(t.ownedUpgrades[c]=Math.max(1,Math.floor(h)));const a=ec(t.fourthSlotPurchased,t.fifthSlotUnlocked),o=new Set;t.activeUpgrades=[null,null,null,null,null],(s.activeUpgrades??[]).slice(0,yr).forEach((c,h)=>{h>=a||!c||!t.ownedUpgrades[c]||o.has(c)||(o.add(c),t.activeUpgrades[h]=c)}),t.unlockedSectors=new Set(["starter_belt"]);for(const c of s.unlockedSectors??[])_r.some(h=>h.id===c)&&t.unlockedSectors.add(c);const l=s.achievements&&typeof s.achievements=="object"?{...rr(),...s.achievements}:rr();return t.achievements=new Kl(l),t.settings={...sc(),...s.settings??{}},t.stats={...rc(),...s.stats??{}},{state:t,warning:i}}save(e=typeof localStorage<"u"?localStorage:null){if(!e)return!1;try{return e.setItem(ic,JSON.stringify(this.serialize())),!0}catch{return!1}}static load(e=typeof localStorage<"u"?localStorage:null){if(!e)return new ri;try{const t=e.getItem(ic);if(!t)return new ri;const i=JSON.parse(t),{state:s,warning:r}=ri.deserialize(i);return s.loadWarning=r,s}catch{const t=new ri;return t.loadWarning="Save file was unreadable - a new campaign was created.",t}}}function In(n,e=!1){const t=n[0].index!==null,i=new Set(Object.keys(n[0].attributes)),s=new Set(Object.keys(n[0].morphAttributes)),r={},a={},o=n[0].morphTargetsRelative,l=new It;let c=0;for(let h=0;h<n.length;++h){const u=n[h];let d=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const f in u.attributes){if(!i.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(u.attributes[f]),d++}if(d!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const f in u.morphAttributes){if(!s.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;a[f]===void 0&&(a[f]=[]),a[f].push(u.morphAttributes[f])}if(e){let f;if(t)f=u.index.count;else if(u.attributes.position!==void 0)f=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,f,h),c+=f}}if(t){let h=0;const u=[];for(let d=0;d<n.length;++d){const f=n[d].index;for(let g=0;g<f.count;++g)u.push(f.getX(g)+h);h+=n[d].attributes.position.count}l.setIndex(u)}for(const h in r){const u=oc(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(const h in a){const u=a[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){const f=[];for(let v=0;v<a[h].length;++v)f.push(a[h][v][d]);const g=oc(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(g)}}return l}function oc(n){let e,t,i,s=-1,r=0;for(let c=0;c<n.length;++c){const h=n[c];if(h.isInterleavedBufferAttribute)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. InterleavedBufferAttributes are not supported."),null;if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=h.normalized),i!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.array.length}const a=new e(r);let o=0;for(let c=0;c<n.length;++c)a.set(n[c].array,o),o+=n[c].array.length;const l=new jt(a,t,i);return s!==void 0&&(l.gpuType=s),l}const $i=new Map;function dn(n){const e=document.createElement("canvas");return e.width=n,e.height=n,e}function $t(n,e=1,t=!1){const i=new bs(n);return i.wrapS=i.wrapT=lr,i.repeat.set(e,e),i.anisotropy=4,t&&(i.colorSpace=dt),i.needsUpdate=!0,i}function lo(n,e,t=2.4){const i=dn(e),s=i.getContext("2d"),r=s.createImageData(e,e),a=(o,l)=>n[(l+e)%e*e+(o+e)%e];for(let o=0;o<e;o++)for(let l=0;l<e;l++){const c=(a(l+1,o)-a(l-1,o))*t,h=(a(l,o+1)-a(l,o-1))*t;let u=-c,d=-h,f=1;const g=Math.hypot(u,d,f)||1;u/=g,d/=g,f/=g;const v=(o*e+l)*4;r.data[v]=(u*.5+.5)*255,r.data[v+1]=(d*.5+.5)*255,r.data[v+2]=(f*.5+.5)*255,r.data[v+3]=255}return s.putImageData(r,0,0),i}function qi(n,e){const t=dn(e),i=t.getContext("2d"),s=i.createImageData(e,e);for(let r=0;r<n.length;r++){const a=ut(n[r],0,1)*255;s.data[r*4]=a,s.data[r*4+1]=a,s.data[r*4+2]=a,s.data[r*4+3]=255}return i.putImageData(s,0,0),t}function Yi(n){return[n>>16&255,n>>8&255,n&255]}function iv(n,e,t,i=512){const s=`hull:${n}:${e}:${t}:${i}`,r=$i.get(s);if(r)return r;const a=new Lt(t),o=hi(t),l=hi(t+77),[c,h,u]=Yi(n),[d,f,g]=Yi(e),v=dn(i),p=v.getContext("2d"),m=new Float32Array(i*i),M=new Float32Array(i*i),_=new Float32Array(i*i),x=dn(i),P=x.getContext("2d");P.fillStyle="#000",P.fillRect(0,0,i,i);const w=p.createImageData(i,i);for(let S=0;S<i;S++)for(let D=0;D<i;D++){const F=D/i,X=S/i,L=$n(o,F*7,X*7,5)*.55+$n(l,F*23,X*23,3)*.45,B=.72+L*.5,H=(S*i+D)*4;w.data[H]=ut(c*B,0,255),w.data[H+1]=ut(h*B,0,255),w.data[H+2]=ut(u*B,0,255),w.data[H+3]=255,m[S*i+D]=L*.12,M[S*i+D]=.42+L*.38,_[S*i+D]=.82-L*.2}p.putImageData(w,0,0);const A=[],N=S=>{if(S.d>3||S.w<i*.16||S.h<i*.16){A.push(S);return}const D=S.w<S.h?!0:a.chance(.5),F=a.range(.34,.66);if(D){const X=Math.floor(S.h*F);N({x:S.x,y:S.y,w:S.w,h:X,d:S.d+1}),N({x:S.x,y:S.y+X,w:S.w,h:S.h-X,d:S.d+1})}else{const X=Math.floor(S.w*F);N({x:S.x,y:S.y,w:X,h:S.h,d:S.d+1}),N({x:S.x+X,y:S.y,w:S.w-X,h:S.h,d:S.d+1})}};N({x:0,y:0,w:i,h:i,d:0}),p.lineWidth=Math.max(1.4,i/300);for(const S of A){const D=a.range(-.1,.12);p.fillStyle=`rgba(${ut(c*(1+D),0,255)|0},${ut(h*(1+D),0,255)|0},${ut(u*(1+D),0,255)|0},0.5)`,p.fillRect(S.x+2,S.y+2,S.w-4,S.h-4),p.strokeStyle="rgba(8,12,20,0.75)",p.strokeRect(S.x+2.5,S.y+2.5,S.w-5,S.h-5),p.strokeStyle="rgba(255,255,255,0.08)",p.strokeRect(S.x+4.5,S.y+4.5,S.w-9,S.h-9);for(let F=S.y;F<S.y+S.h;F++)for(const X of[S.x,S.x+S.w-1]){const L=(F+i)%i*i+(X+i)%i;m[L]-=.55,M[L]=.85}for(let F=S.x;F<S.x+S.w;F++)for(const X of[S.y,S.y+S.h-1]){const L=(X+i)%i*i+(F+i)%i;m[L]-=.55,M[L]=.85}if(S.w>i*.2&&S.h>i*.2&&a.chance(.75)){const F=Math.floor(S.w/(i/22));for(let X=1;X<F;X++){const L=S.x+X*S.w/F;for(const B of[S.y+7,S.y+S.h-7]){p.fillStyle="rgba(230,238,255,0.18)",p.beginPath(),p.arc(L,B,i/220,0,Math.PI*2),p.fill();const H=Math.floor(B)%i*i+Math.floor(L)%i;m[H]+=.9}}}a.chance(.18)&&(p.fillStyle=`rgba(${d},${f},${g},0.5)`,p.fillRect(S.x+6,S.y+S.h*.5-i/200,S.w-12,i/100)),a.chance(.1)&&(P.fillStyle=`rgba(${d},${f},${g},0.95)`,P.fillRect(S.x+S.w*.25,S.y+S.h*.18,S.w*.5,Math.max(2,i/150)),p.fillStyle=`rgba(${Math.min(255,d+60)},${Math.min(255,f+60)},${Math.min(255,g+60)},0.85)`,p.fillRect(S.x+S.w*.25,S.y+S.h*.18,S.w*.5,Math.max(2,i/150)))}for(let S=0;S<90;S++){const D=a.range(0,i),F=a.range(0,i),X=a.range(i*.02,i*.18),L=a.range(0,Math.PI*2);p.strokeStyle=`rgba(${Math.min(255,c+90)},${Math.min(255,h+95)},${Math.min(255,u+100)},${a.range(.05,.22)})`,p.lineWidth=a.range(.6,1.8),p.beginPath(),p.moveTo(D,F),p.lineTo(D+Math.cos(L)*X,F+Math.sin(L)*X),p.stroke()}const y={map:$t(v,1,!0),normalMap:$t(lo(m,i,2)),roughnessMap:$t(qi(M,i)),metalnessMap:$t(qi(_,i)),emissiveMap:$t(x,1,!0)};return $i.set(s,y),y}function sv(n,e,t=512){const i=`rock:${n}:${e}:${t}`,s=$i.get(i);if(s)return s;const r=hi(e),a=hi(e+311),o=hi(e+913),l=dn(t),c=l.getContext("2d"),h=c.createImageData(t,t),u=new Float32Array(t*t),d=new Float32Array(t*t),f=new Float32Array(t*t),g=dn(t),v=g.getContext("2d");v.fillStyle="#000",v.fillRect(0,0,t,t);const p=v.getImageData(0,0,t,t),M={basalt:{base:[78,76,72],vein:[164,150,120],glow:0},crystal:{base:[70,92,126],vein:[140,228,255],glow:.75},metal:{base:[96,101,112],vein:[206,216,232],glow:.08},volcanic:{base:[62,46,42],vein:[255,126,48],glow:.85},void:{base:[44,44,62],vein:[171,124,255],glow:.6}}[n];for(let x=0;x<t;x++)for(let P=0;P<t;P++){const w=P/t,A=x/t,N=$n(r,w*5,A*5,6,2.1,.52),y=$n(a,w*38,A*38,3),S=N*.78+y*.22,D=Math.abs($n(o,w*9+3.1,A*9-1.7,4)-.5)*2,F=ut(1-D*3.2,0,1),X=.55+S*.85,L=(x*t+P)*4,B=M.base[0]*X+M.vein[0]*F*.9,H=M.base[1]*X+M.vein[1]*F*.9,Z=M.base[2]*X+M.vein[2]*F*.9;h.data[L]=ut(B,0,255),h.data[L+1]=ut(H,0,255),h.data[L+2]=ut(Z,0,255),h.data[L+3]=255,u[x*t+P]=S*.9+F*.25,d[x*t+P]=ut(.95-F*.55-(n==="metal"?.25:0),.08,1),f[x*t+P]=n==="metal"?.55+F*.4:F*(n==="crystal"?.35:.15);const J=F*M.glow;p.data[L]=ut(M.vein[0]*J,0,255),p.data[L+1]=ut(M.vein[1]*J,0,255),p.data[L+2]=ut(M.vein[2]*J,0,255),p.data[L+3]=255}c.putImageData(h,0,0),v.putImageData(p,0,0);const _={map:$t(l,1,!0),normalMap:$t(lo(u,t,3.4)),roughnessMap:$t(qi(d,t)),metalnessMap:$t(qi(f,t)),emissiveMap:$t(g,1,!0)};return $i.set(i,_),_}function rv(n=4242,e=1024){const t=`floor:${n}`,i=$i.get(t);if(i)return i;const s=new Lt(n),r=hi(n),a=dn(e),o=a.getContext("2d"),l=new Float32Array(e*e),c=new Float32Array(e*e).fill(.72),h=new Float32Array(e*e).fill(.6);o.fillStyle="#20252f",o.fillRect(0,0,e,e);const u=e/4;for(let f=0;f<4;f++)for(let g=0;g<4;g++){const v=34+s.range(-8,10);o.fillStyle=`rgb(${v},${v+4},${v+10})`,o.fillRect(f*u+3,g*u+3,u-6,u-6),o.strokeStyle="rgba(0,0,0,0.65)",o.lineWidth=4,o.strokeRect(f*u+3,g*u+3,u-6,u-6),o.strokeStyle="rgba(255,255,255,0.05)",o.lineWidth=2;for(let p=0;p<10;p++){const m=p/10*u;o.beginPath(),o.moveTo(f*u+m,g*u),o.lineTo(f*u+m+u*.1,g*u+u),o.stroke()}}o.save(),o.translate(e/2,e/2);for(let f=0;f<24;f++)o.rotate(Math.PI*2/24),o.fillStyle=f%2===0?"rgba(255,183,0,0.85)":"rgba(22,26,34,0.9)",o.fillRect(e*.3,-e*.022,e*.08,e*.044);o.restore();for(let f=0;f<180;f++){const g=s.range(0,e),v=s.range(0,e);o.fillStyle=`rgba(10,12,16,${s.range(.04,.12)})`,o.beginPath(),o.ellipse(g,v,s.range(10,70),s.range(6,30),s.range(0,Math.PI),0,Math.PI*2),o.fill()}for(let f=0;f<e;f++)for(let g=0;g<e;g++){const v=$n(r,g/e*12,f/e*12,4);l[f*e+g]=v*.25,c[f*e+g]=.55+v*.4}const d={map:$t(a,1,!0),normalMap:$t(lo(l,e,1.4)),roughnessMap:$t(qi(c,e)),metalnessMap:$t(qi(h,e))};return $i.set(t,d),d}function av(n,e=11,t=512){const i=dn(t),s=i.getContext("2d"),r=new Lt(e),a=$t(i,1,!0);a.wrapS=a.wrapT=ln;const o=Array.from({length:48},()=>r.range(.2,.9)),l=c=>{s.fillStyle="#05101e",s.fillRect(0,0,t,t),s.strokeStyle="rgba(0,229,255,0.12)",s.lineWidth=1;for(let u=0;u<=16;u++){const d=u/16*t;s.beginPath(),s.moveTo(d,0),s.lineTo(d,t),s.stroke(),s.beginPath(),s.moveTo(0,d),s.lineTo(t,d),s.stroke()}s.fillStyle="#00e5ff",s.font=`bold ${t*.055}px "Orbitron", sans-serif`;const h={telemetry:"SHIP TELEMETRY",blueprint:"FRAME BLUEPRINT",market:"ORE EXCHANGE",radar:"SECTOR RADAR"};if(s.fillText(h[n],t*.06,t*.11),n==="telemetry"||n==="market")o.push(ut(o[o.length-1]+Math.sin(c*1.7+o.length)*.08+r.range(-.05,.05),.12,.95)),o.shift(),s.strokeStyle=n==="market"?"#00ff9d":"#7b61ff",s.lineWidth=t*.008,s.beginPath(),o.forEach((u,d)=>{const f=t*.06+d/(o.length-1)*t*.88,g=t*.82-u*t*.55;d===0?s.moveTo(f,g):s.lineTo(f,g)}),s.stroke(),s.fillStyle="rgba(0,229,255,0.12)",s.lineTo(t*.94,t*.82),s.lineTo(t*.06,t*.82),s.closePath(),s.fill();else if(n==="blueprint"){s.strokeStyle="rgba(0,229,255,0.85)",s.lineWidth=t*.006;const u=t/2,d=t*.55,f=t*.3;s.beginPath(),s.moveTo(u,d-f),s.lineTo(u+f*.55,d+f*.2),s.lineTo(u+f*.3,d+f*.7),s.lineTo(u-f*.3,d+f*.7),s.lineTo(u-f*.55,d+f*.2),s.closePath(),s.stroke(),s.strokeStyle=`rgba(123,97,255,${.4+Math.sin(c*3)*.3})`,s.strokeRect(u-f*.75,d-f*1.1,f*1.5,f*2)}else{const u=t/2,d=t*.56,f=t*.33;s.strokeStyle="rgba(0,255,157,0.5)";for(let p=1;p<=3;p++)s.beginPath(),s.arc(u,d,f*p/3,0,Math.PI*2),s.stroke();const g=c*1.6,v=s.createConicGradient?s.createConicGradient(g,u,d):null;v&&(v.addColorStop(0,"rgba(0,255,157,0.55)"),v.addColorStop(.12,"rgba(0,255,157,0)"),v.addColorStop(1,"rgba(0,255,157,0)"),s.fillStyle=v,s.beginPath(),s.arc(u,d,f,0,Math.PI*2),s.fill());for(let p=0;p<5;p++){const m=p*1.9+c*.3,M=f*(.3+p*37%70/100);s.fillStyle="#ff3b6b",s.beginPath(),s.arc(u+Math.cos(m)*M,d+Math.sin(m)*M,t*.012,0,Math.PI*2),s.fill()}}s.fillStyle="rgba(0,0,0,0.18)";for(let u=0;u<t;u+=4)s.fillRect(0,u,t,2);a.needsUpdate=!0};return l(0),{texture:a,draw:l}}function ov(n,e,t,i=2048){const s=dn(i);s.height=i/2;const r=s.getContext("2d"),a=s.width,o=s.height,l=new Lt(t),c=hi(t+5),[h,u,d]=Yi(n),[f,g,v]=Yi(e);r.fillStyle="#01030a",r.fillRect(0,0,a,o);const p=256,m=dn(p);m.height=p/2;const M=m.getContext("2d"),_=M.createImageData(p,p/2);for(let P=0;P<p/2;P++)for(let w=0;w<p;w++){const A=w/p,N=P/(p/2),y=$n(c,A*4,N*4,6,2.2,.55),S=$n(c,A*9+11,N*9-4,4),D=ut((y*1.35-.42)*1.6,0,1),F=ut((S*1.2-.5)*1.4,0,1),X=(P*p+w)*4;_.data[X]=ut(h*D+f*F*.7,0,255),_.data[X+1]=ut(u*D+g*F*.7,0,255),_.data[X+2]=ut(d*D+v*F*.7,0,255),_.data[X+3]=255}M.putImageData(_,0,0),r.globalCompositeOperation="lighter",r.filter="blur(12px)",r.drawImage(m,0,0,a,o),r.filter="none";for(let P=0;P<2600;P++){const w=l.range(0,a),A=l.range(0,o),N=Math.pow(l.next(),3.2),y=.4+N*2.4,S=l.next(),D=S<.2?[180,205,255]:S<.8?[255,255,255]:[255,214,170];r.fillStyle=`rgba(${D[0]},${D[1]},${D[2]},${.25+N*.75})`,r.beginPath(),r.arc(w,A,y,0,Math.PI*2),r.fill(),N>.82&&(r.strokeStyle=`rgba(${D[0]},${D[1]},${D[2]},0.35)`,r.lineWidth=.8,r.beginPath(),r.moveTo(w-y*4,A),r.lineTo(w+y*4,A),r.moveTo(w,A-y*4),r.lineTo(w,A+y*4),r.stroke())}r.globalCompositeOperation="source-over";const x=new bs(s);return x.mapping=or,x.colorSpace=dt,x.needsUpdate=!0,x}function ya(n,e=1,t=128){const i=dn(t),s=i.getContext("2d"),[r,a,o]=Yi(n),l=s.createRadialGradient(t/2,t/2,0,t/2,t/2,t/2);l.addColorStop(0,"rgba(255,255,255,1)"),l.addColorStop(.22,`rgba(${r},${a},${o},0.95)`),l.addColorStop(.55,`rgba(${r},${a},${o},0.35)`),l.addColorStop(1,`rgba(${r},${a},${o},0)`),s.fillStyle=l,s.fillRect(0,0,t,t);const c=new bs(i);return c.colorSpace=dt,c}function lv(n,e=64){const t=dn(e),i=t.getContext("2d"),[s,r,a]=Yi(n),o=i.createLinearGradient(0,e/2,e,e/2);o.addColorStop(0,`rgba(${s},${r},${a},0)`),o.addColorStop(.5,"rgba(255,255,255,1)"),o.addColorStop(1,`rgba(${s},${r},${a},0)`),i.fillStyle=o,i.fillRect(0,e*.42,e,e*.16);const l=new bs(t);return l.colorSpace=dt,l}const we=4,Mr=new Map;function co(n,e,t,i=.9){const s=`${n}:${e}:${t}:${i}`,r=Mr.get(s);if(r)return r;const a=iv(n,e,t,512),o=new Ft({map:a.map,normalMap:a.normalMap,roughnessMap:a.roughnessMap,metalnessMap:a.metalnessMap,emissiveMap:a.emissiveMap,emissive:new Le(e).multiplyScalar(i),metalness:1,roughness:1,normalScale:new ue(1.1,1.1)});return Mr.set(s,o),o}function nn(n,e=2.2){const t=`emissive:${n}:${e}`,i=Mr.get(t);if(i)return i;const s=new Ft({color:1119e3,emissive:new Le(n),emissiveIntensity:e,roughness:.3,metalness:.2});return Mr.set(t,s),s}function cv(n=7330047){return new Eg({color:n,metalness:.1,roughness:.06,transmission:.82,thickness:.6,ior:1.4,transparent:!0,opacity:.72,clearcoat:1,clearcoatRoughness:.05,emissive:new Le(n).multiplyScalar(.12)})}function en(n,e,t,i=.08){const s=new ih,r=Math.min(i,n*.3,e*.3);s.moveTo(-n/2+r,-e/2),s.lineTo(n/2-r,-e/2),s.quadraticCurveTo(n/2,-e/2,n/2,-e/2+r),s.lineTo(n/2,e/2-r),s.quadraticCurveTo(n/2,e/2,n/2-r,e/2),s.lineTo(-n/2+r,e/2),s.quadraticCurveTo(-n/2,e/2,-n/2,e/2-r),s.lineTo(-n/2,-e/2+r),s.quadraticCurveTo(-n/2,-e/2,-n/2+r,-e/2);const a=new io(s,{depth:t,bevelEnabled:!0,bevelThickness:i*.6,bevelSize:i*.6,bevelSegments:2,steps:1});return a.translate(0,0,-t/2),a.computeVertexNormals(),a}function it(n,e,t,i){return n.translate(e,t,i),n}function er(n,e,t,i){return e&&n.rotateX(e),t&&n.rotateY(t),i&&n.rotateZ(i),n}function _a(n,e,t,i,s){const r=[];for(let a=0;a<s;a++){const o=n.range(.06,.2)*e,l=n.range(.04,.12)*t,c=n.range(.06,.22)*i,h=n.int(0,3),u=new Fe(o,l,c),d=n.range(-e/2+o,e/2-o),f=n.range(-i/2+c,i/2-c);h===0?u.translate(d,t/2,f):h===1?u.translate(d,-t/2,f):h===2?u.translate(e/2,n.range(-t/3,t/3),f):u.translate(-e/2,n.range(-t/3,t/3),f),r.push(u)}return r}const lc=new Map;function Ha(n){const e=Je(n),t=n;let i=lc.get(t);i||(i=hv(e),lc.set(t,i));const s=i.clone(!0),r=[],a=[];let o,l;return s.traverse(c=>{c.name==="muzzle"?r.push(c):c.name==="nozzle"?a.push(c):c.name==="turret"?o=c:c.name==="spin"&&(l=c)}),{group:s,muzzles:r,nozzles:a,turret:o,spin:l}}function ss(n,e,t,i){const s=new _t;return s.name=n,s.position.set(e,t,i),s}function hv(n){const e=new et,[t,i,s]=n.size,r=t*we,a=i*we,o=s*we,l=new Lt(cc(n.id)),c=co(n.color,n.accent,cc(n.id),.55),h=nn(n.accent,2.6),u=new Ft({color:1316895,metalness:.9,roughness:.45}),d=[],f=[];switch(n.category){case"structure":{const g=n.id==="hull_composite"?.76:.88;d.push(en(r*g,a*g,o*g,.3));const v=.16*we;for(const m of[-1,1])for(const M of[-1,1])d.push(it(new Ze(v,v,a*.98,8),m*(r*g)/2,0,M*(o*g)/2));const p=Math.max(1,Math.round(s));for(let m=0;m<p;m++){const M=-o/2+o*((m+.5)/p);f.push(it(new Fe(r*.94,a*.1,o*.06),0,a*.46,M))}d.push(..._a(l,r*g,a*g,o*g,n.id==="hull_basic"?6:10));break}case"command":{const g=en(r*.86,a*.62,o*.9,.34);d.push(it(g,0,-a*.14,0));const v=new Pt(Math.min(r,o)*.34,20,14,0,Math.PI*2,0,Math.PI/2);v.scale(1.15,.95,1.5),v.translate(0,a*.14,o*.08);const p=new oe(v,cv(8381439));p.castShadow=!0,e.add(p);for(let m=-1;m<=1;m++){const M=new bt(Math.min(r,o)*.345,.06*we,6,20,Math.PI);M.rotateY(Math.PI/2+m*.5),M.translate(0,a*.14,o*.08),f.push(M)}if(f.push(it(new Fe(r*.08,a*.42,o*.3),0,a*.4,-o*.3)),d.push(..._a(l,r*.8,a*.5,o*.8,8)),n.id==="cockpit_tactical"){const m=new et;m.name="spin";const M=new oe(new Pt(we*.26,16,10,0,Math.PI*2,0,Math.PI/2.4),c);M.rotation.x=Math.PI,m.add(M),m.position.set(r*.3,a*.42,-o*.2),e.add(m)}break}case"propulsion":{const g=o*.55;d.push(it(en(r*.72,a*.72,g,.28),0,0,-o*.5+g/2+o*.08));const v=n.id==="engine_fusion"?2:n.id==="engine_vector"?4:n.id==="engine_warp"?2:1,p=(n.id==="engine_vector"?.16:n.id==="engine_warp"?.42:.3)*we*Math.min(t,i);for(let m=0;m<v;m++){const M=m/v*Math.PI*2,_=v>1?Math.cos(M)*r*.22:0,x=v>1?Math.sin(M)*a*.22:0,P=new Ze(p*1.35,p*.75,o*.42,18,1,!0);P.rotateX(Math.PI/2),d.push(it(P,_,x,o*.22));const w=new bt(p*1.32,p*.12,8,20);f.push(it(w,_,x,o*.42));const A=new oe(new Ze(p*.95,p*.5,o*.3,16,1,!0),h);A.rotation.x=Math.PI/2,A.position.set(_,x,o*.26),e.add(A),e.add(ss("nozzle",_,x,o*.46))}if(n.id==="engine_warp"){const m=new bt(Math.min(r,a)*.42,.1*we,10,32),M=new oe(m,h);M.name="spin",M.position.z=-o*.1,e.add(M)}for(let m=0;m<4;m++){const M=new Fe(r*.06,a*.5,o*.3),_=m/4*Math.PI*2+Math.PI/4;f.push(er(it(M,Math.cos(_)*r*.36,Math.sin(_)*a*.3,-o*.2),0,0,_))}break}case"mining":{d.push(it(en(r*.66,a*.66,o*.6,.26),0,0,-o*.16));const g=n.id==="laser_advanced"?2:n.id==="beam_heavy"?3:1,v=(n.id==="drill_plasma"?.3:.14)*we;for(let p=0;p<g;p++){const m=g===1?0:(p-(g-1)/2)*r*.25,M=new Ze(v,v*.82,o*.72,14);M.rotateX(Math.PI/2),d.push(it(M,m,0,o*.25));const _=new oe(new Pt(v*.9,12,10),h);_.position.set(m,0,o*.6),e.add(_),e.add(ss("muzzle",m,0,o*.62));for(let x=0;x<3;x++){const P=new bt(v*1.25,v*.18,6,14);P.rotateY(0),f.push(it(P,m,0,o*(.05+x*.16)))}}if(n.id==="drill_plasma"){const p=new bn(we*.28,o*.5,10);p.rotateX(Math.PI/2),f.push(it(p,0,0,o*.5))}d.push(..._a(l,r*.6,a*.6,o*.5,5));break}case"collection":{d.push(it(en(r*.6,a*.6,o*.52,.24),0,0,-o*.2));const g=n.id==="collector_wide"?2:1;for(let v=0;v<g;v++){const p=g===1?0:(v-.5)*r*.45,m=Math.min(r,a)*(g===1?.38:.3);for(let _=0;_<3;_++){const x=new bt(m*(1-_*.14),.09*we,8,26);f.push(it(x,p,0,o*(.12+_*.14)))}const M=new oe(new bt(m*.72,.05*we,8,24),h);M.position.set(p,0,o*.3),e.add(M),e.add(ss("muzzle",p,0,o*.36))}if(n.id==="collector_vacuum"){const v=new Ze(Math.min(r,a)*.42,Math.min(r,a)*.2,o*.4,16,1,!0);v.rotateX(-Math.PI/2),d.push(it(v,0,0,o*.3))}break}case"weapon":{d.push(it(new Ze(Math.min(r,o)*.34,Math.min(r,o)*.4,a*.22,18),0,-a*.3,0));const g=new et;g.name="turret",g.position.y=-a*.14;const v=en(r*.5,a*.42,o*.45,.2),p=new oe(v,c);p.castShadow=!0,g.add(p);const m=n.id==="missile_battery"?6:n.id==="gun_machine"||n.id==="railgun"?2:1,M=n.id==="railgun"?.09*we:n.id==="rocket_launcher"?.2*we:.12*we,_=o*(n.id==="railgun"?.95:.6);for(let P=0;P<m;P++){let w=0,A=0;n.id==="missile_battery"?(w=(P%3-1)*r*.17,A=(Math.floor(P/3)-.5)*a*.2):m===2&&(w=(P-.5)*r*.2);const N=new Ze(M,M*.9,_,12);N.rotateX(Math.PI/2),N.translate(w,A,_/2+o*.1);const y=new oe(N,u);y.castShadow=!0,g.add(y);const S=ss("muzzle",w,A,_+o*.12);if(g.add(S),n.id==="gun_plasma"||n.id==="gun_laser"){const D=new oe(new Pt(M*1.2,10,8),h);D.position.set(w,A,_+o*.08),g.add(D)}}if(n.id==="railgun"){const P=new Fe(r*.05,a*.06,_*1.05);for(const w of[-r*.14,r*.14]){const A=new oe(P.clone(),nn(n.accent,1.8));A.position.set(w,a*.12,_/2+o*.1),g.add(A)}}const x=new oe(new Ze(a*.2,a*.2,r*.5,14),c);x.rotation.z=Math.PI/2,x.position.set(0,-a*.02,-o*.22),g.add(x),e.add(g);break}case"defense":{if(n.id==="shield_gen"){d.push(it(en(r*.62,a*.5,o*.62,.22),0,-a*.18,0));const g=new oe(new gi(Math.min(r,a)*.3,1),nn(n.accent,1.6));g.position.y=a*.18,g.name="spin",e.add(g);for(let v=0;v<4;v++){const p=v/4*Math.PI*2,m=new Ze(.05*we,.07*we,a*.5,8);f.push(it(m,Math.cos(p)*r*.26,0,Math.sin(p)*o*.26))}}else if(n.id==="armor_plate"){d.push(en(r*.95,a*.95,o*.95,.4));for(let g=0;g<8;g++){const v=new Ze(.07*we,.07*we,.06*we,8);v.rotateX(Math.PI/2),f.push(it(v,(g%4-1.5)*r*.26,(Math.floor(g/4)-.5)*a*.5,o*.48))}}else if(n.id==="repair_module"){d.push(it(en(r*.7,a*.55,o*.7,.25),0,-a*.1,0));const g=new et;g.name="spin";for(let v=0;v<3;v++){const p=v/3*Math.PI*2,m=new oe(new Ze(.05*we,.04*we,a*.55,8),c);m.position.set(Math.cos(p)*r*.2,a*.22,Math.sin(p)*o*.2),m.rotation.z=Math.cos(p)*.5,m.rotation.x=-Math.sin(p)*.5,g.add(m);const M=new oe(new Pt(.07*we,8,8),h);M.position.set(Math.cos(p)*r*.3,a*.45,Math.sin(p)*o*.3),g.add(M)}e.add(g)}else{d.push(it(en(r*.8,a*.5,o*.8,.22),0,-a*.2,0));const g=new et;g.name="spin";const v=new oe(new Cr(.22*we,0),c);g.add(v);for(const p of[-1,1]){const m=new oe(new Fe(.3*we,.04*we,.12*we),u);m.position.x=p*.26*we,g.add(m);const M=new oe(new Pt(.05*we,8,8),h);M.position.set(p*.4*we,0,0),g.add(M)}g.position.y=a*.25,e.add(g)}break}case"utility":{if(n.id==="radar"){d.push(it(new Ze(r*.22,r*.3,a*.3,14),0,-a*.3,0));const g=new et;g.name="spin";const v=new Pt(Math.min(r,o)*.38,20,12,0,Math.PI*2,0,Math.PI/2.6),p=new oe(v,c);p.rotation.x=-Math.PI*.35,p.position.y=a*.1,g.add(p);const m=new oe(new Ze(.03*we,.03*we,a*.3,6),u);m.position.set(0,a*.25,o*.12),m.rotation.x=-Math.PI*.35,g.add(m);const M=new oe(new Pt(.06*we,8,8),h);M.position.set(0,a*.38,o*.2),g.add(M),e.add(g)}else if(n.id==="scanner"){d.push(it(en(r*.6,a*.45,o*.6,.2),0,-a*.2,0));for(let v=0;v<5;v++){const p=new Fe(r*.07,a*(.2+v*.09),o*.07);f.push(it(p,(v-2)*r*.14,a*(.05+v*.045),0))}const g=new oe(new Pt(.1*we,10,8),h);g.position.set(0,a*.42,o*.2),e.add(g)}else if(n.id==="generator"){d.push(en(r*.8,a*.8,o*.8,.3));const g=new oe(new gi(Math.min(r,a)*.22,1),nn(n.accent,3.2));g.name="spin",e.add(g);for(let v=0;v<3;v++){const p=new bt(Math.min(r,a)*(.3+v*.04),.045*we,8,24);f.push(er(p,v*Math.PI/3,v*.4,0))}}else if(n.id==="cargo_bay"){d.push(en(r*.92,a*.92,o*.94,.16));for(let v=0;v<Math.max(2,s*2);v++){const p=new Fe(r*.96,a*.08,o*.04);f.push(it(p,0,0,-o*.45+(v+.5)*(o*.9)/Math.max(2,s*2)))}const g=new oe(new Fe(r*.5,a*.32,o*.04),nn(n.accent,.8));g.position.set(0,0,o*.48),e.add(g)}else{d.push(it(new Es(Math.min(r,a)*.28,o*.4,6,14),0,0,0)),er(d[d.length-1],Math.PI/2,0,0);for(let v=0;v<3;v++){const p=new Fe(r*.05,a*.34,o*.3),m=v/3*Math.PI*2;f.push(er(it(p,Math.cos(m)*r*.26,Math.sin(m)*a*.26,-o*.1),0,0,m))}const g=new oe(new Ze(Math.min(r,a)*.2,Math.min(r,a)*.26,o*.12,14),h);g.rotation.x=Math.PI/2,g.position.z=o*.42,e.add(g),e.add(ss("nozzle",0,0,o*.48))}break}}if(d.length){const g=In(d.map(v=>v.toNonIndexed()),!1);if(g){g.computeVertexNormals();const v=new oe(g,c);v.castShadow=!0,v.receiveShadow=!0,e.add(v)}}if(f.length){const g=In(f.map(v=>v.toNonIndexed()),!1);if(g){g.computeVertexNormals();const v=new Ft({color:2765122,metalness:.95,roughness:.3}),p=new oe(g,v);p.castShadow=!0,e.add(p)}}return e}function cc(n){let e=2166136261;for(let t=0;t<n.length;t++)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return e>>>0}function Va(n,e,t,i){const s=Je(e),[r,a,o]=Pr(s,i),l=(t[0]+(r-1)/2)*we,c=(t[1]+(a-1)/2)*we,h=(t[2]+(o-1)/2)*we;n.position.set(l,c,h),n.rotation.set(0,0,0);const u=Ba[i];u[1]===1?n.rotation.x=-Math.PI/2:u[1]===-1?n.rotation.x=Math.PI/2:n.rotation.y=Math.atan2(u[0],u[2])}const an=110;function uv(n="high"){const e=new et,t=new Lt(20260315),i=[],s=[],r=co(5923446,9431295,7701,.25),a=new Ft({color:2501430,metalness:.92,roughness:.42}),o=new Ft({color:3359068,metalness:.6,roughness:.6}),l=new Ft({color:16758528,metalness:.4,roughness:.6,emissive:3810816}),c=rv(4242,n==="low"?512:1024);c.map.repeat.set(6,6),c.normalMap.repeat.set(6,6),c.roughnessMap.repeat.set(6,6),c.metalnessMap.repeat.set(6,6);const h=new oe(new no(an,64),new Ft({map:c.map,normalMap:c.normalMap,roughnessMap:c.roughnessMap,metalnessMap:c.metalnessMap,metalness:1,roughness:1}));h.rotation.x=-Math.PI/2,h.receiveShadow=!0,e.add(h);const u=new et,d=new oe(new Ze(26,28,1.2,48),a);d.position.y=.6,d.receiveShadow=!0,u.add(d);const f=new oe(new bt(26.5,.5,8,64),nn(58879,2.4));f.rotation.x=Math.PI/2,f.position.y=1.3,u.add(f);for(let k=0;k<16;k++){const O=k/16*Math.PI*2,V=new oe(new Fe(5,.3,2.4),k%2?l:a);V.position.set(Math.cos(O)*23,1.25,Math.sin(O)*23),V.rotation.y=-O,u.add(V)}e.add(u),s.push(k=>{f.material=f.material,f.rotation.z=k*.2});const g=[],v=28;for(let k=0;k<v;k++){const O=k/v*Math.PI*2,V=Math.cos(O)*an,Q=Math.sin(O)*an,te=new Fe(26,46,3);te.rotateY(-O+Math.PI/2),te.translate(V,23,Q),g.push(te);const he=new Fe(2.4,50,5);he.rotateY(-O+Math.PI/2),he.translate(Math.cos(O+.11)*(an-1),25,Math.sin(O+.11)*(an-1)),g.push(he)}const p=new oe(In(g.map(k=>k.toNonIndexed()),!1),r);p.receiveShadow=!0,e.add(p);const m=new oe(new bt(an-9,1.1,8,72),a);m.rotation.x=Math.PI/2,m.position.y=26,e.add(m);const M=[];for(let k=0;k<72;k++){const O=k/72*Math.PI*2,V=new Fe(.4,4,.4);V.translate(Math.cos(O)*(an-9),28,Math.sin(O)*(an-9)),M.push(V)}e.add(new oe(In(M.map(k=>k.toNonIndexed()),!1),a));const _=[];for(let k=0;k<8;k++){const O=k/8*Math.PI,V=new Fe(an*2-6,2.2,2.2);V.rotateY(O),V.translate(0,44,0),_.push(V);for(let Q=-6;Q<=6;Q++){if(Q===0)continue;const te=new Fe(1,4.5,1);te.rotateY(O),te.translate(Math.cos(O)*Q*15,41.5,Math.sin(O)*Q*15),_.push(te)}}const x=new oe(In(_.map(k=>k.toNonIndexed()),!1),a);e.add(x);const P=n==="low"?4:7;for(let k=0;k<P;k++){const O=k/P*Math.PI*2,V=52,Q=new oe(new Ze(2.4,3.4,2.6,12),a);Q.position.set(Math.cos(O)*V,42,Math.sin(O)*V),e.add(Q);const te=new oe(new Ze(3.2,3.2,.4,12),nn(13625599,3.4));te.position.set(Math.cos(O)*V,40.6,Math.sin(O)*V),e.add(te);const he=new Tg(14216447,n==="low"?320:520,180,Math.PI/5.2,.45,1.6);he.position.set(Math.cos(O)*V,40,Math.sin(O)*V),he.target.position.set(Math.cos(O)*V*.25,0,Math.sin(O)*V*.25),he.castShadow=n==="high"&&k<3,he.castShadow&&(he.shadow.mapSize.set(1024,1024),he.shadow.bias=-.0015),e.add(he,he.target)}const w=new et,A=new oe(new Fe(150,3,5),r);A.position.y=34,w.add(A);for(const k of[-1,1]){const O=new oe(new Fe(3.4,34,3.4),r);O.position.set(k*72,17,0),w.add(O);const V=new oe(new Ze(2.2,2.2,2,14),a);V.rotation.z=Math.PI/2,V.position.set(k*72,1.6,0),w.add(V)}const N=new et,y=new oe(new Fe(8,4,7),o);y.position.y=31,N.add(y);const S=new oe(new Ze(.18,.18,16,6),a);S.position.y=21,N.add(S);const D=new oe(new bt(1.4,.35,8,14),a);D.position.y=13,N.add(D),w.add(N),w.position.z=-34,e.add(w),s.push(k=>{w.position.z=-34+Math.sin(k*.14)*22,N.position.x=Math.sin(k*.21)*48,S.scale.y=1+Math.sin(k*.33)*.25,D.position.y=13-Math.sin(k*.33)*2});const F=[[-44,18],[44,18],[-44,-18],[44,-18]];for(const[k,O]of F){const V=new et,Q=new oe(new Ze(3.2,4.2,2.4,14),a);Q.position.y=1.2,V.add(Q);const te=new et;te.position.y=2.4;const he=new oe(new Fe(2.4,16,2.4),r);he.position.y=8,te.add(he);const be=new et;be.position.y=16;const Pe=new oe(new Fe(2,13,2),r);Pe.position.y=6.5,be.add(Pe);const Se=new et;Se.position.y=13;const De=new oe(new bn(1.1,3.2,10),nn(5504992,1.8));De.rotation.x=Math.PI,De.position.y=1.5,Se.add(De);const I=new oe(new Fe(.5,2.6,.8),a);I.position.set(1.1,1.4,0);const ce=I.clone();ce.position.x=-1.1,Se.add(I,ce),be.add(Se),te.add(be),V.add(te),V.position.set(k,0,O),e.add(V);const Y=t.range(0,Math.PI*2);s.push(ie=>{te.rotation.y=Math.sin(ie*.3+Y)*.9+Math.atan2(-O,-k),be.rotation.x=-.6+Math.sin(ie*.45+Y)*.45,Se.rotation.x=Math.sin(ie*.7+Y)*.5,I.position.x=1.1+Math.sin(ie*1.6+Y)*.35,ce.position.x=-1.1-Math.sin(ie*1.6+Y)*.35})}const X=[{id:"builder",label:"SHIP CONSTRUCTION",angle:Math.PI*.5,color:58879,kind:"blueprint"},{id:"shop",label:"EQUIPMENT SHOP",angle:Math.PI*.9,color:16758528,kind:"market"},{id:"crew",label:"CREW TERMINAL",angle:Math.PI*1.22,color:8086015,kind:"telemetry"},{id:"packs",label:"CARD PACK STATION",angle:Math.PI*1.55,color:16020150,kind:"telemetry"},{id:"upgrades",label:"UPGRADE TERMINAL",angle:Math.PI*1.85,color:65437,kind:"blueprint"},{id:"missions",label:"MISSION BOARD",angle:Math.PI*.18,color:4830975,kind:"radar"}];for(const k of X){const V=Math.cos(k.angle)*62,Q=Math.sin(k.angle)*62,te=new et;te.position.set(V,0,Q),te.rotation.y=-k.angle+Math.PI/2;const he=new oe(new Ze(4.4,5.6,2.4,10),a);he.position.y=1.2,he.receiveShadow=!0,te.add(he);const be=new oe(new Fe(3.2,9,3.2),r);be.position.y=6.6,te.add(be);const Pe=new Fe(11,7,1.2),Se=new oe(Pe,o);Se.position.set(0,12.5,0),Se.rotation.x=-.22,te.add(Se);const{texture:De,draw:I}=av(k.kind,k.angle*1e3,n==="low"?256:512),ce=new oe(new pi(10,6.2),new Yt({map:De,transparent:!0,opacity:.96}));ce.position.set(0,12.6,.72),ce.rotation.x=-.22,te.add(ce),s.push(me=>I(me));const Y=new oe(new pi(13,3.6),new Yt({color:k.color,transparent:!0,opacity:.18,side:Xt,blending:un,depthWrite:!1}));Y.position.set(0,18.5,0),te.add(Y);const ie=yh(k.label,k.color);ie.position.set(0,18.5,.08),te.add(ie);const K=new oe(new bn(5.2,7.5,18,1,!0),new Yt({color:k.color,transparent:!0,opacity:.07,blending:un,depthWrite:!1,side:Xt}));K.position.y=15.5,te.add(K);const Ae=new ro(k.color,34,46,2);Ae.position.set(0,13,2),te.add(Ae),s.push(me=>{Y.position.y=18.5+Math.sin(me*1.2+k.angle)*.35,ie.position.y=Y.position.y+.08,Y.material.opacity=.14+Math.sin(me*2+k.angle)*.05,Ae.intensity=30+Math.sin(me*3+k.angle)*6}),e.add(te),i.push({id:k.id,label:k.label,position:new R(V,14,Q),object:te,color:k.color})}const L=new Ft({color:4147804,metalness:.7,roughness:.55}),B=new Ft({color:7033648,metalness:.5,roughness:.7}),H=new et;for(let k=0;k<(n==="low"?18:34);k++){const O=t.range(0,Math.PI*2),V=t.range(40,an-16),Q=t.range(3,7),te=t.range(2.4,5.5),he=t.range(3,7),be=new oe(new Fe(Q,te,he),t.chance(.5)?L:B);if(be.position.set(Math.cos(O)*V,te/2,Math.sin(O)*V),be.rotation.y=t.range(0,Math.PI),be.castShadow=!0,be.receiveShadow=!0,H.add(be),t.chance(.35)){const Pe=new oe(new Fe(Q*.8,te*.7,he*.8),L);Pe.position.set(be.position.x+t.range(-.6,.6),te+te*.7/2,be.position.z+t.range(-.6,.6)),Pe.rotation.y=t.range(0,Math.PI),Pe.castShadow=!0,H.add(Pe)}}e.add(H);for(let k=0;k<(n==="low"?6:14);k++){const O=t.range(0,Math.PI*2),V=t.range(46,an-20),Q=new oe(new Ze(1.6,1.6,4.2,14),B);Q.position.set(Math.cos(O)*V,2.1,Math.sin(O)*V),Q.castShadow=!0,e.add(Q);const te=new oe(new bt(1.65,.12,6,16),nn(16747068,1.4));te.rotation.x=Math.PI/2,te.position.copy(Q.position).setY(3.2),e.add(te)}const Z=[];for(let k=0;k<5;k++){const O=an-6-k*1.6,V=new bt(O,.45,8,60,Math.PI*t.range(.5,1.6));V.rotateX(Math.PI/2),V.translate(0,8+k*3.4,0),V.rotateY(t.range(0,Math.PI*2)),Z.push(V)}e.add(new oe(In(Z.map(k=>k.toNonIndexed()),!1),a));for(const k of[-1,1]){const O=new et,V=[];for(let Q=0;Q<4;Q++){const te=new Fe(.8,22,.8);te.translate(Q%2?4:-4,11,Q<2?3:-3),V.push(te)}for(let Q=1;Q<=3;Q++){const te=new Fe(9.4,.5,7);te.translate(0,Q*6.5,0),V.push(te)}O.add(new oe(In(V.map(Q=>Q.toNonIndexed()),!1),r)),O.position.set(k*38,0,10),e.add(O)}for(let k=0;k<24;k++){const O=k/24*Math.PI*2,V=new oe(new Fe(1.6,.14,.7),nn(58879,2.2));V.position.set(Math.cos(O)*34,.1,Math.sin(O)*34),V.rotation.y=-O,e.add(V)}const J=new oh(6258623,1053465,.55);e.add(J);const j=new mr(14412287,1.25);if(j.position.set(60,90,40),j.castShadow=n!=="low",j.castShadow){j.shadow.mapSize.set(n==="high"?2048:1024,n==="high"?2048:1024),j.shadow.camera.near=10,j.shadow.camera.far=260;const k=90;j.shadow.camera.left=-k,j.shadow.camera.right=k,j.shadow.camera.top=k,j.shadow.camera.bottom=-k,j.shadow.bias=-.0012}e.add(j);const ee=new mr(8086015,.5);return ee.position.set(-70,40,-60),e.add(ee),{group:e,stations:i,update:(k,O)=>{for(const V of s)V(k,O)}}}function yh(n,e,t=13,i=3.6){const s=document.createElement("canvas");s.width=1024,s.height=256;const r=s.getContext("2d");r.clearRect(0,0,s.width,s.height);const a=new Le(e);r.fillStyle=`rgba(${a.r*255|0},${a.g*255|0},${a.b*255|0},1)`,r.font="bold 92px Orbitron, Arial, sans-serif",r.textAlign="center",r.textBaseline="middle",r.shadowColor=r.fillStyle,r.shadowBlur=28,r.fillText(n,s.width/2,s.height/2);const o=new bs(s);o.colorSpace=dt;const l=new Yt({map:o,transparent:!0,blending:un,depthWrite:!1,side:Xt});return new oe(new pi(t,i),l)}class tr{constructor(e,t,i=un){this.particles=[],this.cursor=0,this.capacity=e,this.positions=new Float32Array(e*3),this.colors=new Float32Array(e*3),this.sizes=new Float32Array(e);const s=new It;s.setAttribute("position",new jt(this.positions,3)),s.setAttribute("color",new jt(this.colors,3)),s.setAttribute("size",new jt(this.sizes,1));const r=new Zc({size:1,map:t,transparent:!0,blending:i,depthWrite:!1,vertexColors:!0,sizeAttenuation:!0});r.onBeforeCompile=a=>{a.vertexShader=`attribute float size;
`+a.vertexShader.replace("gl_PointSize = size;","gl_PointSize = size;").replace("uniform float size;","uniform float sizeUnused;"),a.vertexShader=a.vertexShader.replace("gl_PointSize = sizeUnused;","gl_PointSize = size;")},this.points=new X0(s,r),this.points.frustumCulled=!1;for(let a=0;a<e;a++)this.particles.push({life:0,maxLife:1,vel:new R,drag:.98,size:0,startSize:0,color:new Le}),this.sizes[a]=0}spawn(e,t,i,s,r,a=.96){const o=this.cursor;this.cursor=(this.cursor+1)%this.capacity;const l=this.particles[o];l.life=r,l.maxLife=r,l.vel.copy(t),l.drag=a,l.size=s,l.startSize=s,l.color.set(i),this.positions[o*3]=e.x,this.positions[o*3+1]=e.y,this.positions[o*3+2]=e.z,this.colors[o*3]=l.color.r,this.colors[o*3+1]=l.color.g,this.colors[o*3+2]=l.color.b,this.sizes[o]=s}update(e){for(let i=0;i<this.capacity;i++){const s=this.particles[i];if(s.life<=0){this.sizes[i]!==0&&(this.sizes[i]=0);continue}s.life-=e;const r=Math.max(0,s.life/s.maxLife);s.vel.multiplyScalar(Math.pow(s.drag,e*60)),this.positions[i*3]+=s.vel.x*e,this.positions[i*3+1]+=s.vel.y*e,this.positions[i*3+2]+=s.vel.z*e,this.sizes[i]=s.startSize*(.25+r*.75);const a=r*r;this.colors[i*3]=s.color.r*a,this.colors[i*3+1]=s.color.g*a,this.colors[i*3+2]=s.color.b*a,s.life<=0&&(this.sizes[i]=0)}const t=this.points.geometry;t.attributes.position.needsUpdate=!0,t.attributes.color.needsUpdate=!0,t.attributes.size.needsUpdate=!0}}class _h{constructor(e,t="high"){this.beams=[],this.flashes=[],this.shockwaves=[],this.rng=new Lt(99),this.scene=e;const i=t==="low"?.4:t==="medium"?.7:1;this.sparks=new tr(Math.floor(2200*i),lv(16765286)),this.smoke=new tr(Math.floor(900*i),ya(8952234),ai),this.embers=new tr(Math.floor(1600*i),ya(16747068)),this.dust=new tr(Math.floor(1200*i),ya(10474751)),e.add(this.sparks.points,this.smoke.points,this.embers.points,this.dust.points)}update(e){this.sparks.update(e),this.smoke.update(e),this.embers.update(e),this.dust.update(e);for(let t=this.beams.length-1;t>=0;t--){const i=this.beams[t];i.life-=e;const s=Math.max(0,i.life/i.maxLife);i.mesh.material.opacity=s,i.life<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.beams.splice(t,1))}for(let t=this.flashes.length-1;t>=0;t--){const i=this.flashes[t];i.life-=e;const s=Math.max(0,i.life/i.maxLife);i.light.intensity=i.intensity*s*s,i.life<=0&&(this.scene.remove(i.light),this.flashes.splice(t,1))}for(let t=this.shockwaves.length-1;t>=0;t--){const i=this.shockwaves[t];i.life-=e;const s=1-Math.max(0,i.life/i.maxLife);i.mesh.scale.setScalar(1+s*i.scale),i.mesh.material.opacity=(1-s)*.75,i.life<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.shockwaves.splice(t,1))}}beam(e,t,i,s=.35,r=.08){const a=new R().subVectors(t,e),o=a.length();if(o<.01)return;const l=new Ze(s*.5,s,o,8,1,!0);l.translate(0,-o/2,0);const c=new Yt({color:i,transparent:!0,opacity:1,blending:un,depthWrite:!1,side:Xt}),h=new oe(l,c);h.position.copy(e),h.quaternion.setFromUnitVectors(new R(0,-1,0),a.clone().normalize()),this.scene.add(h),this.beams.push({mesh:h,life:r,maxLife:r})}impact(e,t,i=14,s=24){const r=new Le(t);for(let a=0;a<i;a++){const o=new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).normalize().multiplyScalar(s*this.rng.range(.3,1.2));this.sparks.spawn(e,o,r,this.rng.range(.9,2.1),this.rng.range(.25,.65),.9)}this.flash(e,t,24,.14)}explosion(e,t=1,i=16747068){const s=new Le(i),r=Math.floor(28*t);for(let a=0;a<r;a++){const o=new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).normalize().multiplyScalar(this.rng.range(6,40)*t);this.embers.spawn(e,o,s,this.rng.range(1.5,4.5)*t,this.rng.range(.4,1.3),.93)}for(let a=0;a<Math.floor(14*t);a++){const o=new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).normalize().multiplyScalar(this.rng.range(2,12)*t);this.smoke.spawn(e,o,new Le(3817290),this.rng.range(4,9)*t,this.rng.range(.9,2),.9)}this.flash(e,i,120*t,.5),this.shockwave(e,i,10*t)}shockwave(e,t,i=10){const s=new Pt(1,20,12),r=new Yt({color:t,transparent:!0,opacity:.8,blending:un,depthWrite:!1,side:qt,wireframe:!1}),a=new oe(s,r);a.position.copy(e),this.scene.add(a),this.shockwaves.push({mesh:a,life:.5,maxLife:.5,scale:i})}flash(e,t,i=40,s=.2){const r=new ro(t,i,160,2);r.position.copy(e),this.scene.add(r),this.flashes.push({light:r,life:s,maxLife:s,intensity:i})}shieldHit(e,t,i=4830975){const s=new Le(i);for(let r=0;r<16;r++){const a=t.clone().multiplyScalar(this.rng.range(4,18)).add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(6));this.sparks.spawn(e,a,s,this.rng.range(.8,1.8),this.rng.range(.2,.5),.88)}this.flash(e,i,30,.18)}pickup(e,t){const i=new Le(t);for(let s=0;s<10;s++){const r=new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(6);this.dust.spawn(e,r,i,this.rng.range(.6,1.4),this.rng.range(.3,.7),.9)}}thrusterPuff(e,t,i,s){if(s<=.02)return;const r=new Le(i),a=t.clone().multiplyScalar(26*s).add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(1.6));this.embers.spawn(e,a,r,this.rng.range(.8,2)*(.5+s),this.rng.range(.12,.3),.9)}ambientDust(e,t,i,s=2){const r=new Le(i);for(let a=0;a<s;a++){const o=new R(e.x+this.rng.range(-t,t),e.y+this.rng.range(-t,t),e.z+this.rng.range(-t,t));this.dust.spawn(o,new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(.6),r,this.rng.range(.4,1.6),this.rng.range(2,5),.995)}}lightning(e,t,i=10479871){let r=e.clone();for(let a=1;a<=8;a++){const o=a/8,l=e.clone().lerp(t,o);a<8&&l.add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(e.distanceTo(t)*.06)),this.beam(r,l,i,.22,.14),r=l}this.flash(t,i,60,.25)}}class Wa{constructor(e,t=1){this.group=new et,this.baseLength=5*t;const i=new bn(.7*t,this.baseLength,12,1,!0);i.translate(0,-this.baseLength/2,0),i.rotateX(Math.PI/2);const s=new Yt({color:e,transparent:!0,opacity:.55,blending:un,depthWrite:!1,side:Xt});this.cone=new oe(i,s);const r=new bn(.34*t,this.baseLength*.65,10,1,!0);r.translate(0,-this.baseLength*.325,0),r.rotateX(Math.PI/2),this.inner=new oe(r,new Yt({color:16777215,transparent:!0,opacity:.8,blending:un,depthWrite:!1,side:Xt})),this.light=new ro(e,0,40,2),this.group.add(this.cone,this.inner,this.light)}setThrottle(e,t){const i=Math.max(0,Math.min(1.4,e)),s=.88+Math.sin(performance.now()*.03)*.12,r=i*s;this.cone.scale.set(.6+r*.6,.6+r*.6,Math.max(.001,r*1.3)),this.inner.scale.set(.6+r*.4,.6+r*.4,Math.max(.001,r*1.1)),this.cone.material.opacity=.5*Math.min(1,i),this.inner.material.opacity=.85*Math.min(1,i),this.light.intensity=i*18}}class dv{constructor(e,t,i,s){this.scene=new Jc,this.stations=[],this.shipGroup=new et,this.gridGroup=new et,this.ghostGroup=new et,this.mode="view",this.selectedModule=null,this.selectedOrientation=0,this.hoveredCell=null,this.hoveredModuleUid=null,this.placementValid=!1,this.placementMessage="",this.cellPurchaseMode=!1,this.onStationClick=null,this.onShipChanged=null,this.onNotify=null,this.raycaster=new Pg,this.orbit={theta:Math.PI*.22,phi:Math.PI*.34,radius:78,target:new R(0,10,0)},this.dragging="none",this.lastPointer={x:0,y:0},this.moduleObjects=new Map,this.plumes=[],this.placementAnims=[],this.ghostMesh=null,this.stationLabels=new Map,this.pointerDownAt={x:0,y:0,time:0},this.time=0,this.state=e,this.input=t,this.canvas=i,this.camera=new Wt(52,window.innerWidth/window.innerHeight,.4,2600),this.scene.fog=new wr(461590,.0032),this.scene.background=new Le(329487);const r=uv(s);this.scene.add(r.group),this.stations=r.stations,this.hangarUpdate=r.update;for(const l of this.stations)this.stationLabels.set(l.id,l.object);this.scene.add(this.shipGroup,this.gridGroup,this.ghostGroup),this.shipGroup.position.set(0,14,0),this.gridGroup.position.copy(this.shipGroup.position),this.ghostGroup.position.copy(this.shipGroup.position),this.fx=new _h(this.scene,s),this.cellMaterialOwned=new Yt({color:58879,wireframe:!0,transparent:!0,opacity:.16}),this.cellMaterialBuy=new Yt({color:16758528,wireframe:!0,transparent:!0,opacity:.3});const a=new et,o=new oe(new Pt(.55,16,12),nn(16726891,3));a.add(o);for(let l=0;l<3;l++){const c=new oe(new bt(1.1,.07,8,28),nn(16726891,1.6));c.rotation.set(l===0?Math.PI/2:0,l===1?Math.PI/2:0,0),a.add(c)}a.visible=!1,this.comMarker=a,this.shipGroup.add(a),this.bindPointer(),this.rebuildShip()}bindPointer(){this.canvas.addEventListener("pointerdown",e=>{this.pointerDownAt={x:e.clientX,y:e.clientY,time:performance.now()},this.lastPointer={x:e.clientX,y:e.clientY},e.button===2||e.button===0&&e.shiftKey?this.dragging="pan":e.button===0?this.dragging="orbit":e.button===1&&(this.dragging="pan")}),window.addEventListener("pointerup",e=>{const t=Math.hypot(e.clientX-this.pointerDownAt.x,e.clientY-this.pointerDownAt.y),i=performance.now()-this.pointerDownAt.time<400;this.dragging!=="none"&&t<5&&i&&e.button===0&&this.handleClick(),this.dragging="none"}),window.addEventListener("pointermove",e=>{const t=e.clientX-this.lastPointer.x,i=e.clientY-this.lastPointer.y;this.lastPointer={x:e.clientX,y:e.clientY};const s=this.state.settings.cameraSensitivity;if(this.dragging==="orbit")this.orbit.theta-=t*.005*s,this.orbit.phi=tn.clamp(this.orbit.phi-i*.004*s*(this.state.settings.invertY?-1:1),.08,Math.PI*.49);else if(this.dragging==="pan"){const r=this.orbit.radius*.0016,a=new R().setFromSphericalCoords(1,Math.PI/2,this.orbit.theta+Math.PI/2);this.orbit.target.addScaledVector(a,-t*r),this.orbit.target.y=tn.clamp(this.orbit.target.y+i*r,0,60)}}),this.canvas.addEventListener("wheel",e=>{this.orbit.radius=tn.clamp(this.orbit.radius+e.deltaY*.05,18,190)},{passive:!0})}handleClick(){var t;if(this.mode==="build"){if(this.cellPurchaseMode&&this.hoveredCell){this.tryBuyCell(this.hoveredCell);return}if(this.selectedModule&&this.hoveredCell){this.tryPlace();return}if(this.hoveredModuleUid){this.tryRemove(this.hoveredModuleUid);return}return}const e=this.pickStation();e&&(ve.uiClick(),(t=this.onStationClick)==null||t.call(this,e.id))}pickStation(){this.raycaster.setFromCamera(new ue(this.input.mouse.x,this.input.mouse.y),this.camera);let e=null;for(const t of this.stations){const i=new Ss(t.position.clone(),12),s=new R;if(this.raycaster.ray.intersectSphere(i,s)){const r=s.distanceTo(this.camera.position);(!e||r<e.dist)&&(e={st:t,dist:r})}}return(e==null?void 0:e.st)??null}setMode(e){this.mode=e,this.gridGroup.visible=e==="build",this.ghostGroup.visible=e==="build",this.comMarker.visible=e==="build",e==="build"?(this.orbit.radius=58,this.orbit.target.set(0,14,0),this.rebuildGrid()):(this.orbit.radius=82,this.orbit.target.set(0,10,0),this.selectedModule=null,this.cellPurchaseMode=!1,this.clearGhost())}selectModule(e){if(this.selectedModule=e,this.cellPurchaseMode=!1,this.clearGhost(),e){const t=Ha(e);t.group.traverse(i=>{const s=i;s.isMesh&&(s.material=new Yt({color:58879,transparent:!0,opacity:.42,wireframe:!1}),s.castShadow=!1)}),this.ghostMesh=t.group,this.ghostGroup.add(t.group)}}setCellPurchaseMode(e){this.cellPurchaseMode=e,e&&(this.selectedModule=null,this.clearGhost()),this.rebuildGrid()}rotateSelection(e=1){const t=[0,1,2,3,4,5],i=t.indexOf(this.selectedOrientation);this.selectedOrientation=t[(i+e+t.length)%t.length],ve.uiClick()}clearGhost(){this.ghostMesh&&(this.ghostGroup.remove(this.ghostMesh),this.ghostMesh.traverse(e=>{var i,s,r,a;const t=e;t.isMesh&&((s=(i=t.geometry)==null?void 0:i.dispose)==null||s.call(i),(a=(r=t.material)==null?void 0:r.dispose)==null||a.call(r))}),this.ghostMesh=null)}rebuildShip(){for(const t of this.moduleObjects.values())this.shipGroup.remove(t);this.moduleObjects.clear(),this.plumes=[];const e=this.state.ship;for(const t of e.modules){const i=Ha(t.defId);Va(i.group,t.defId,t.pos,t.orientation),i.group.userData.uid=t.uid,this.shipGroup.add(i.group),this.moduleObjects.set(t.uid,i.group);const s=Je(t.defId);if(s.stats.thrust)for(const r of i.nozzles){const a=new Wa(s.accent,.8);r.add(a.group),this.plumes.push({plume:a,uid:t.uid})}}this.centerShip(),this.updateCOM(),this.rebuildGrid()}centerShip(){const e=this.state.ship.bounds(),t=(e.min[0]+e.max[0])/2*we,i=(e.min[2]+e.max[2])/2*we,s=e.min[1]*we;this.shipGroup.position.set(-t,14-s+2,-i),this.gridGroup.position.copy(this.shipGroup.position),this.ghostGroup.position.copy(this.shipGroup.position)}updateCOM(){const e=this.state.ship.stats();this.comMarker.position.set(e.centerOfMass[0]*we,e.centerOfMass[1]*we,e.centerOfMass[2]*we)}rebuildGrid(){if(this.gridGroup.clear(),this.mode!=="build")return;const e=this.state.ship,t=new Fe(we*.98,we*.98,we*.98),i=e.occupancy();for(const s of e.cells){const[r,a,o]=sr(s);if(i.has(s))continue;const l=new oe(t,this.cellMaterialOwned);l.position.set(r*we,a*we,o*we),l.userData.cell=[r,a,o],this.gridGroup.add(l)}if(this.cellPurchaseMode){const s=new Set;for(const r of e.cells){const[a,o,l]=sr(r),c=[[a+1,o,l],[a-1,o,l],[a,o+1,l],[a,o-1,l],[a,o,l+1],[a,o,l-1]];for(const h of c){const u=vt(...h);e.cells.has(u)||s.add(u)}}for(const r of s){const[a,o,l]=sr(r),c=new oe(t,this.cellMaterialBuy);c.position.set(a*we,o*we,l*we),c.userData.cell=[a,o,l],c.userData.buyable=!0,this.gridGroup.add(c)}}}tryPlace(){var r,a,o;if(!this.selectedModule||!this.hoveredCell)return;const e=this.selectedModule;if((this.state.inventory[e]??0)<=0){(r=this.onNotify)==null||r.call(this,"You do not own that module - buy it in the Equipment Shop.","error"),ve.error();return}const t=this.state.ship.checkPlacement(e,this.hoveredCell,this.selectedOrientation);if(t){(a=this.onNotify)==null||a.call(this,t.message,"error"),ve.error();return}this.state.takeFromInventory(e);const i=this.state.ship.place(e,this.hoveredCell,this.selectedOrientation);if("code"in i){this.state.returnToInventory(e);return}ve.place(),this.state.trackStat("modulesInstalled",1),this.rebuildShip();const s=this.moduleObjects.get(i.uid);if(s){s.scale.setScalar(.01),this.placementAnims.push({obj:s,t:0,duration:.42});const l=s.getWorldPosition(new R);this.fx.impact(l,Je(e).accent,18,14)}(this.state.inventory[e]??0)<=0&&this.selectModule(null),(o=this.onShipChanged)==null||o.call(this)}tryRemove(e){var a,o,l;const t=this.state.ship.modules.find(c=>c.uid===e);if(!t)return;if(Je(t.defId).category==="command"){(a=this.onNotify)==null||a.call(this,"The command cockpit cannot be removed.","error"),ve.error();return}const s=this.moduleObjects.get(e),r=s?s.getWorldPosition(new R):new R;if(!this.state.ship.remove(e)){(o=this.onNotify)==null||o.call(this,"Removing that module would split the hull into disconnected pieces.","error"),ve.error();return}this.state.returnToInventory(t.defId),this.fx.impact(r,16747068,14,12),ve.uiBack(),this.rebuildShip(),(l=this.onShipChanged)==null||l.call(this)}tryBuyCell(e){var r,a,o,l;const t=this.state.ship;if(!t.canBuyCell(e)){(r=this.onNotify)==null||r.call(this,"Expansion cells must touch the existing frame.","error"),ve.error();return}const i=mh(t.purchasedCount);if(this.state.credits<i){(a=this.onNotify)==null||a.call(this,`Not enough credits - this cell costs ${i.toLocaleString()} CR.`,"error"),ve.error();return}this.state.spendCredits(i),t.buyCell(e),this.state.trackStat("cellsPurchased",1),ve.purchase(),(o=this.onNotify)==null||o.call(this,`Expansion cell installed for ${i.toLocaleString()} CR.`,"success"),this.rebuildGrid(),this.centerShip();const s=new R(e[0]*we,e[1]*we,e[2]*we).add(this.gridGroup.position);this.fx.impact(s,16758528,20,16),(l=this.onShipChanged)==null||l.call(this)}update(e){this.time+=e,this.hangarUpdate(this.time,e),this.fx.update(e);const t=new R().setFromSphericalCoords(this.orbit.radius,this.orbit.phi,this.orbit.theta);this.camera.position.copy(this.orbit.target).add(t),this.camera.lookAt(this.orbit.target),this.shipGroup.rotation.y=this.mode==="view"?Math.sin(this.time*.12)*.12:0,this.shipGroup.children.forEach(i=>{var s;(s=i.traverse)==null||s.call(i,r=>{r.name==="spin"&&(r.rotation.y+=e*1.2)})});for(const{plume:i}of this.plumes)i.setThrottle(this.mode==="view"?.22+Math.sin(this.time*2)*.05:.08,e);for(let i=this.placementAnims.length-1;i>=0;i--){const s=this.placementAnims[i];s.t+=e;const r=Math.min(1,s.t/s.duration),a=1-Math.pow(1-r,3),o=1+Math.sin(r*Math.PI)*.18;s.obj.scale.setScalar(a*o),r>=1&&(s.obj.scale.setScalar(1),this.placementAnims.splice(i,1))}this.mode==="build"?this.updateBuildCursor():this.updateStationHover(),Math.random()<.25&&this.fx.ambientDust(new R(0,20,0),70,11192575,1)}updateStationHover(){const e=this.pickStation();for(const t of this.stations){const s=(e==null?void 0:e.id)===t.id?1.08:1;t.object.scale.lerp(new R(s,s,s),.15)}this.canvas.style.cursor=e?"pointer":"grab"}updateBuildCursor(){this.raycaster.setFromCamera(new ue(this.input.mouse.x,this.input.mouse.y),this.camera),this.hoveredCell=null,this.hoveredModuleUid=null;const e=this.raycaster.intersectObjects(this.gridGroup.children,!1);if(e.length>0){const t=e[0].object.userData.cell;t&&(this.hoveredCell=[...t])}if(!this.hoveredCell||!this.cellPurchaseMode){const t=this.raycaster.intersectObjects(this.shipGroup.children,!0);if(t.length>0){let i=t[0].object;for(;i&&!i.userData.uid;)i=i.parent;i!=null&&i.userData.uid&&(this.hoveredModuleUid=i.userData.uid)}}if(this.ghostMesh&&this.selectedModule)if(this.hoveredCell){this.ghostMesh.visible=!0,Va(this.ghostMesh,this.selectedModule,this.hoveredCell,this.selectedOrientation);const t=this.state.ship.checkPlacement(this.selectedModule,this.hoveredCell,this.selectedOrientation);this.placementValid=!t,this.placementMessage=(t==null?void 0:t.message)??"Valid placement";const i=t?16726891:65437;this.ghostMesh.traverse(s=>{const r=s;r.isMesh&&r.material.color.setHex(i)}),rs(Je(this.selectedModule),this.hoveredCell,this.selectedOrientation)}else this.ghostMesh.visible=!1,this.placementMessage="";this.canvas.style.cursor=this.hoveredCell||this.hoveredModuleUid?"crosshair":"grab"}playLaunchSequence(e){ve.launch();const t=this.shipGroup.position.y,i=performance.now(),s=2100;for(const{plume:a}of this.plumes)a.setThrottle(1.4,.016);const r=()=>{const a=Math.min(1,(performance.now()-i)/s),o=a*a*a;this.shipGroup.position.y=t+o*160,this.orbit.radius=78+o*60,this.orbit.phi=Math.max(.1,.34-o*.2),Math.random()<.8&&this.fx.explosion(new R((Math.random()-.5)*20,6,(Math.random()-.5)*20),.35,16747068),a<1?requestAnimationFrame(r):(this.shipGroup.position.y=t,e())};requestAnimationFrame(r)}addCallout(e,t){const i=this.stations.find(r=>r.id===e);if(!i)return;const s=yh(t,i.color,10,2.6);s.position.copy(i.position).add(new R(0,8,0)),this.scene.add(s)}}const hc=new Map;function fv(n,e){const t=`${n}:${e}`,i=hc.get(t);if(i)return i;const s=sv(n,e,512),r=n==="volcanic"?16742959:n==="crystal"?8118527:n==="void"?12160255:0,a=new Ft({map:s.map,normalMap:s.normalMap,roughnessMap:s.roughnessMap,metalnessMap:s.metalnessMap,emissiveMap:s.emissiveMap,emissive:new Le(r),emissiveIntensity:n==="basalt"?0:1.1,metalness:1,roughness:1,normalScale:new ue(1.6,1.6)});return hc.set(t,a),a}function pv(n){const e=[];for(let a=0;a<256;a++){const o=[n.range(-1,1),n.range(-1,1),n.range(-1,1)],l=Math.hypot(o[0],o[1],o[2])||1;e.push([o[0]/l,o[1]/l,o[2]/l])}const t=new Uint8Array(512),i=n.shuffle(Array.from({length:256},(a,o)=>o));for(let a=0;a<512;a++)t[a]=i[a&255];const s=a=>a*a*a*(a*(a*6-15)+10),r=(a,o,l,c)=>a[0]*o+a[1]*l+a[2]*c;return(a,o,l)=>{const c=Math.floor(a)&255,h=Math.floor(o)&255,u=Math.floor(l)&255,d=a-Math.floor(a),f=o-Math.floor(o),g=l-Math.floor(l),v=s(d),p=s(f),m=s(g),M=(D,F,X)=>t[t[t[D]+F&255]+X&255],_=(D,F,X)=>D+(F-D)*X,x=(D,F,X,L,B,H)=>r(e[M(D,F,X)],L,B,H),P=_(x(c,h,u,d,f,g),x(c+1,h,u,d-1,f,g),v),w=_(x(c,h+1,u,d,f-1,g),x(c+1,h+1,u,d-1,f-1,g),v),A=_(P,w,p),N=_(x(c,h,u+1,d,f,g-1),x(c+1,h,u+1,d-1,f,g-1),v),y=_(x(c,h+1,u+1,d,f-1,g-1),x(c+1,h+1,u+1,d-1,f-1,g-1),v),S=_(N,y,p);return(_(A,S,m)+1)*.5}}function mv(n,e,t,i=2,s=0){const r=new Lt(e),a=pv(new Lt(e+17)),o=new gi(t,i),l=o.attributes.position,c=new R,h=[],u=3+Math.floor(r.next()*5)+Math.round(s*5);for(let p=0;p<u;p++)h.push({dir:new R(r.range(-1,1),r.range(-1,1),r.range(-1,1)).normalize(),r:r.range(.18,.55),depth:r.range(.1,.3)*(1+s)});for(let p=0;p<l.count;p++){c.fromBufferAttribute(l,p);const m=c.clone().normalize(),M=a(m.x*1.6+10,m.y*1.6,m.z*1.6)-.5,_=a(m.x*4.2,m.y*4.2+5,m.z*4.2)-.5,x=a(m.x*9.5,m.y*9.5,m.z*9.5+3)-.5;let P=1+M*.42+_*.2+x*.09;for(const w of h){const A=m.dot(w.dir),N=ut((A-(1-w.r))/w.r,0,1);P-=N*N*w.depth}P*=1-s*.18,c.copy(m).multiplyScalar(t*P),l.setXYZ(p,c.x,c.y,c.z)}o.computeVertexNormals(),o.computeBoundingSphere();const d=[o];if(n==="crystal"||n==="void"){const p=4+r.int(0,5);for(let m=0;m<p;m++){const M=new R(r.range(-1,1),r.range(-1,1),r.range(-1,1)).normalize(),_=t*r.range(.4,.95),x=new bn(t*r.range(.08,.17),_,r.int(4,6));x.translate(0,_*.45,0);const P=new xn().setFromUnitVectors(new R(0,1,0),M);x.applyQuaternion(P),x.translate(M.x*t*.72,M.y*t*.72,M.z*t*.72),d.push(x)}}else if(n==="metal"){const p=3+r.int(0,4);for(let m=0;m<p;m++){const M=new R(r.range(-1,1),r.range(-1,1),r.range(-1,1)).normalize(),_=new Fe(t*r.range(.35,.8),t*r.range(.06,.14),t*r.range(.3,.7)),x=new xn().setFromUnitVectors(new R(0,1,0),M);_.applyQuaternion(x),_.translate(M.x*t*.85,M.y*t*.85,M.z*t*.85),d.push(_)}}else if(n==="volcanic"){const p=3+r.int(0,3);for(let m=0;m<p;m++){const M=new R(r.range(-1,1),r.range(-1,1),r.range(-1,1)).normalize(),_=new bt(t*r.range(.12,.26),t*.05,6,12),x=new xn().setFromUnitVectors(new R(0,0,1),M);_.applyQuaternion(x),_.translate(M.x*t*.92,M.y*t*.92,M.z*t*.92),d.push(_)}}const f=d.length>1?In(d.map(p=>p.toNonIndexed()),!1)??o:o;if(f.computeVertexNormals(),!f.attributes.uv){const p=f.attributes.position,m=new Float32Array(p.count*2),M=new R;for(let _=0;_<p.count;_++)M.fromBufferAttribute(p,_).normalize(),m[_*2]=.5+Math.atan2(M.z,M.x)/(Math.PI*2),m[_*2+1]=.5-Math.asin(ut(M.y,-1,1))/Math.PI;f.setAttribute("uv",new jt(m,2))}const g=fv(n,e%4+1),v=new oe(f,g);return v.castShadow=!0,v.receiveShadow=!0,{mesh:v,radius:t}}function Ma(n,e,t=1){const i=new Lt(e),s=new gi(t,0),r=s.attributes.position,a=new R;for(let c=0;c<r.count;c++)a.fromBufferAttribute(r,c),a.multiplyScalar(i.range(.72,1.3)),r.setXYZ(c,a.x,a.y,a.z);s.computeVertexNormals();const o=new Ft({color:n,emissive:new Le(n).multiplyScalar(.45),metalness:.75,roughness:.35,flatShading:!0}),l=new oe(s,o);return l.castShadow=!0,l}function gv(n,e=1){const t=new Lt(n),i=new et,s=new Ft({color:5067876,metalness:.95,roughness:.55,flatShading:!0}),r=new Ft({color:2369583,metalness:.8,roughness:.7}),a=t.range(18,46)*e,o=new oe(new Ze(2.2*e,3.1*e,a,8,1,!0),s);o.rotation.z=Math.PI/2,i.add(o);const l=t.int(4,9);for(let c=0;c<l;c++){const h=(c/(l-1)-.5)*a,u=new oe(new bt(t.range(3,6.5)*e,.45*e,6,12,Math.PI*t.range(.6,1.8)),s);u.position.x=h,u.rotation.y=Math.PI/2,u.rotation.x=t.range(0,Math.PI),i.add(u)}for(let c=0;c<t.int(3,7);c++){const h=new oe(new Fe(t.range(2,7)*e,t.range(.3,.8)*e,t.range(2,6)*e),r);h.position.set(t.range(-a/2,a/2),t.range(-4,4)*e,t.range(-4,4)*e),h.rotation.set(t.range(0,3),t.range(0,3),t.range(0,3)),i.add(h)}return i}const uc=new Map;function dc(n){let e=uc.get(n.type);e||(e=vv(n),uc.set(n.type,e));const t=e.clone(!0),i=[],s=[];return t.traverse(r=>{r.name==="muzzle"&&i.push(r),r.name==="engine"&&s.push(r)}),{group:t,muzzles:i,engines:s}}function _n(n,e,t,i){const s=new _t;return s.name=n,s.position.set(e,t,i),s}function vv(n){const e=new et,t=n.scale*3.2,i=new Lt(n.name.length*7919+n.hull),s=co(n.color,n.accent,n.hull|0,.4),r=nn(n.accent,2.8);new Ft({color:1382431,metalness:.9,roughness:.4});const a=[];switch(n.type){case"scout":{const l=new bn(t*.35,t*1.6,7);l.rotateX(Math.PI/2),a.push(l);for(const u of[-1,1]){const d=new Fe(t*.7,t*.07,t*.44);d.translate(u*t*.45,0,-t*.2),d.rotateY(u*.22),a.push(d);const f=new Ze(t*.07,t*.07,t*.4,8);f.rotateX(Math.PI/2),f.translate(u*t*.78,0,-t*.1),a.push(f),e.add(_n("muzzle",u*t*.78,0,t*.12))}const c=new oe(new Pt(t*.14,12,10),r);c.position.set(0,t*.1,t*.55),e.add(c);const h=new oe(new Ze(t*.17,t*.22,t*.25,12,1,!0),r);h.rotation.x=Math.PI/2,h.position.z=-t*.78,e.add(h),e.add(_n("engine",0,0,-t*.9));break}case"raider":{const l=new Fe(t*.6,t*.4,t*1.5);a.push(l);const c=new Fe(t*1.25,t*.3,t*.42);c.translate(0,0,t*.72),a.push(c);for(const d of[-1,1]){const f=new Ze(t*.17,t*.2,t*1.1,10);f.rotateX(Math.PI/2),f.translate(d*t*.52,-t*.1,-t*.15),a.push(f),e.add(_n("muzzle",d*t*.58,0,t*.85));const g=new oe(new Ze(t*.14,t*.18,t*.22,10,1,!0),r);g.rotation.x=Math.PI/2,g.position.set(d*t*.52,-t*.1,-t*.74),e.add(g),e.add(_n("engine",d*t*.52,-t*.1,-t*.85))}const h=new Fe(t*.06,t*.6,t*.5);h.translate(0,t*.42,-t*.5),a.push(h);const u=new oe(new Fe(t*.9,t*.08,t*.08),r);u.position.set(0,t*.06,t*.9),e.add(u);break}case"heavy":{const l=new Fe(t*.9,t*.75,t*1.3);a.push(l);for(let c=0;c<5;c++){const h=new Fe(t*(1.05-c*.07),t*.1,t*(.32+c*.05));h.translate(0,t*(.42-c*.2),t*(.3-c*.18)),a.push(h)}for(const c of[-1,1]){const h=new Fe(t*.22,t*.3,t*.95);h.translate(c*t*.62,0,t*.1),a.push(h);const u=new Ze(t*.09,t*.09,t*.75,10);u.rotateX(Math.PI/2),u.translate(c*t*.62,0,t*.7),a.push(u),e.add(_n("muzzle",c*t*.62,0,t*1.05))}for(const c of[-1,1]){const h=new oe(new Ze(t*.2,t*.26,t*.3,12,1,!0),r);h.rotation.x=Math.PI/2,h.position.set(c*t*.34,0,-t*.78),e.add(h),e.add(_n("engine",c*t*.34,0,-t*.95))}break}case"plasma":{const l=new Pt(t*.46,16,12);l.scale(1,.7,1.7),a.push(l);for(const d of[-1,1]){const f=new bn(t*.2,t*1.25,4);f.rotateZ(d*Math.PI/2.2),f.rotateX(-Math.PI/2.4),f.translate(d*t*.6,t*.1,-t*.15),a.push(f),e.add(_n("muzzle",d*t*.42,0,t*.72))}const c=new oe(new Es(t*.09,t*.9,6,12),r);c.rotation.x=Math.PI/2,c.position.set(0,t*.26,-t*.05),e.add(c);const h=new oe(new Pt(t*.17,14,12),r);h.position.set(0,0,t*.72),e.add(h);const u=new oe(new bt(t*.24,t*.07,8,18),r);u.position.z=-t*.82,e.add(u),e.add(_n("engine",0,0,-t*.95));break}default:{const l=new Cr(t*.5,1);l.scale(1,1.25,1),a.push(l);const c=new bt(t*.95,t*.1,10,28);c.rotateX(Math.PI/2),a.push(c);const h=new bt(t*.72,t*.07,8,24);h.rotateY(Math.PI/2),a.push(h);for(let d=0;d<4;d++){const f=d/4*Math.PI*2+Math.PI/4,g=new Fe(t*.12,t*.12,t*.8);g.translate(Math.cos(f)*t*.62,0,Math.sin(f)*t*.62),g.rotateY(-f),a.push(g),e.add(_n("muzzle",Math.cos(f)*t*.95,0,Math.sin(f)*t*.95))}const u=new oe(new gi(t*.28,1),r);e.add(u);for(const d of[-1,1])e.add(_n("engine",d*t*.3,-t*.3,-t*.6));break}}for(let l=0;l<8;l++){const c=new Fe(t*i.range(.05,.16),t*i.range(.04,.1),t*i.range(.08,.26));c.translate(i.range(-t*.4,t*.4),i.range(-t*.25,t*.3),i.range(-t*.6,t*.5)),a.push(c)}const o=In(a.map(l=>l.toNonIndexed()),!1);if(o){o.computeVertexNormals();const l=new oe(o,s);l.castShadow=!0,l.receiveShadow=!0,e.add(l)}for(let l=0;l<3;l++){const c=new oe(new Pt(t*.05,8,6),r);c.position.set(i.range(-t*.5,t*.5),i.range(-t*.2,t*.3),i.range(-t*.5,t*.5)),e.add(c)}return e}const nr=new R(0,1,0),yv=120;function Sa(n,e,t,i){const s=e.clone().sub(n),r=s.lengthSq();if(r<1e-8)return n.distanceTo(t)<=i;const a=tn.clamp(t.clone().sub(n).dot(s)/r,0,1);return n.clone().addScaledVector(s,a).distanceTo(t)<=i}class _v{constructor(e,t,i,s){this.scene=new Jc,this.active=!1,this.onReturn=null,this.onNotify=null,this.shipGroup=new et,this.shipPivot=new et,this.asteroids=[],this.chunks=[],this.projectiles=[],this.enemies=[],this.plumes=[],this.miningMuzzles=[],this.weaponMounts=[],this.magnets=[],this.droneBays=[],this.velocity=new R,this.angularVelocity=new R,this.mass=1e3,this.comOffset=new R,this.throttle=0,this.boost=0,this.shield=0,this.maxShield=0,this.energy=0,this.maxEnergy=100,this.cargo=0,this.cargoCap=100,this.oreHold={},this.creditsEarned=0,this.elapsed=0,this.spawnTimer=0,this.hazardTimer=0,this.miningTargets=new Set,this.cameraShake=0,this.cameraDistance=34,this.lastDamageTime=-99,this.statsCache={asteroidsMined:0,enemiesKilled:0,distance:0,chunks:0,damageDealt:0,rareFinds:0,shieldAbsorbed:0},this.bounds=1200,this.targetLock=null,this.hazardWarning="",this.state=e,this.input=t,this.sector=i,this.quality=s,this.rng=new Lt((Date.now()^i.index*7919)>>>0),this.camera=new Wt(66,window.innerWidth/window.innerHeight,.5,6e3),this.fx=new _h(this.scene,s),this.hud=this.freshHud(),this.buildEnvironment(),this.buildShip(),this.spawnField()}freshHud(){return{hull:1,maxHull:1,shield:0,maxShield:0,energy:0,maxEnergy:1,cargo:0,cargoCap:1,speed:0,throttle:0,sector:this.sector.name,asteroidsMined:0,enemiesKilled:0,credits:0,ore:{},targetName:null,targetHealth:0,targetMaxHealth:0,radarBlips:[],warnings:[],elapsed:0}}buildEnvironment(){const e=ov(this.sector.nebula[0],this.sector.nebula[1],this.sector.index*1337+7,this.quality==="low"?1024:2048);this.scene.background=e,this.scene.environment=null,this.scene.fog=new wr(this.sector.fog,this.sector.hazard==="lightning"?.0016:8e-4);const t=new oh(this.sector.ambient,329228,.9);this.scene.add(t);const i=new mr(this.sector.sun,2.1);if(i.position.set(300,200,120),i.castShadow=this.quality==="high",i.castShadow){i.shadow.mapSize.set(1024,1024),i.shadow.camera.near=20,i.shadow.camera.far=900;const a=180;i.shadow.camera.left=-a,i.shadow.camera.right=a,i.shadow.camera.top=a,i.shadow.camera.bottom=-a}this.scene.add(i);const s=new mr(this.sector.sun2,.9);s.position.set(-220,-80,-160),this.scene.add(s);const r=this.quality==="low"?6:14;for(let a=0;a<r;a++){const o=new pi(this.rng.range(400,1100),this.rng.range(300,800)),l=new Yt({color:a%2?this.sector.nebula[0]:this.sector.nebula[1],transparent:!0,opacity:this.rng.range(.05,.16),blending:un,depthWrite:!1}),c=new oe(o,l),h=new R(this.rng.gauss(),this.rng.gauss()*.4,this.rng.gauss()).normalize();c.position.copy(h.multiplyScalar(this.rng.range(1400,2400))),c.lookAt(0,0,0),this.scene.add(c)}}spawnField(){const e=this.quality==="low"?Math.floor(this.sector.asteroidCount*.6):this.sector.asteroidCount;for(let t=0;t<e;t++)this.spawnAsteroid(!0);if(this.sector.id==="iron_graveyard")for(let t=0;t<7;t++){const i=gv(t*991+3,this.rng.range(.9,2.2));i.position.set(this.rng.range(-700,700),this.rng.range(-200,200),this.rng.range(-700,700)),i.rotation.set(this.rng.range(0,6),this.rng.range(0,6),this.rng.range(0,6)),this.scene.add(i)}}spawnAsteroid(e=!1){const[t,i]=this.sector.asteroidScale,s=this.rng.range(t,i),r=this.rng.int(1,1e6),a=this.quality==="low"?1:s>14?3:2,o=mv(this.sector.rockStyle,r,s,a),l=new R;if(e)l.set(this.rng.range(-800,800),this.rng.range(-260,260),this.rng.range(-800,800));else{const p=new R(this.rng.gauss(),this.rng.gauss()*.3,this.rng.gauss()).normalize();l.copy(this.shipPivot.position).add(p.multiplyScalar(this.rng.range(520,820)))}o.mesh.position.copy(l),o.mesh.rotation.set(this.rng.range(0,6.3),this.rng.range(0,6.3),this.rng.range(0,6.3));const c=this.sector.resourceTable,h=Object.keys(c),u=h.map(p=>c[p]),d=this.rng.weighted(h,u),f=1+this.sector.danger*.45,g=s*20*f,v={mesh:o.mesh,radius:s,health:g,maxHealth:g,resource:d,amount:Math.round(s*this.rng.range(2.2,4.4)*(yt[d].rare?.5:1)),spin:new R(this.rng.range(-.25,.25),this.rng.range(-.25,.25),this.rng.range(-.25,.25)),velocity:new R(this.rng.range(-2,2),this.rng.range(-1,1),this.rng.range(-2,2)),rare:yt[d].rare,damageStage:0};this.scene.add(o.mesh),this.asteroids.push(v)}buildShip(){this.shipPivot.add(this.shipGroup),this.scene.add(this.shipPivot);const e=this.state.ship,t=e.stats(),i=this.state.bonuses();this.mass=Math.max(200,t.mass),this.comOffset.set(t.centerOfMass[0]*we,t.centerOfMass[1]*we,t.centerOfMass[2]*we);for(const s of e.modules){const r=Ha(s.defId);Va(r.group,s.defId,s.pos,s.orientation),r.group.position.sub(this.comOffset),r.group.userData.uid=s.uid,this.shipGroup.add(r.group);const a=Je(s.defId);if(a.stats.thrust){const o=e.thrusters().find(l=>l.uid===s.uid);for(const l of r.nozzles){const c=new Wa(a.accent,.9);l.add(c.group);const h=o?new R(...o.dir):new R(0,0,1),u=new R(s.pos[0]*we-this.comOffset.x,s.pos[1]*we-this.comOffset.y,s.pos[2]*we-this.comOffset.z);this.plumes.push({plume:c,dir:h,offset:u})}}if(a.stats.miningDps)for(const o of r.muzzles)this.miningMuzzles.push({obj:o,dps:Ht(a.stats.miningDps,s.level)*e.efficiency(s)*Ot(i,"miningMult"),range:(a.stats.miningRange??80)*1,uid:s.uid});if(a.category==="weapon"&&a.stats.damage&&this.weaponMounts.push({obj:r.group,turret:r.turret,uid:s.uid,defId:s.defId,cooldown:0,damage:Ht(a.stats.damage,s.level)*Ot(i,"damageMult"),rate:(a.stats.fireRate??1)*Ot(i,"fireRateMult"),speed:a.stats.projectileSpeed??400,range:a.stats.weaponRange??200,splash:a.stats.splash??0,homing:a.stats.homing??0,color:a.accent}),a.stats.magnetRange&&this.magnets.push({range:Ht(a.stats.magnetRange,s.level)*Ot(i,"magnetRangeMult"),force:Ht(a.stats.magnetForce??100,s.level)}),a.category==="defense"&&a.stats.drones)for(let o=0;o<(a.stats.drones??0);o++)this.droneBays.push({cooldown:0,damage:Ht(a.stats.damage??10,s.level)*Ot(i,"damageMult"),rate:a.stats.fireRate??1,range:a.stats.weaponRange??180})}this.maxShield=t.shield*Ot(i,"shieldMult"),this.shield=this.maxShield,this.maxEnergy=Math.max(40,t.energyCap),this.energy=this.maxEnergy,this.cargoCap=Math.max(40,t.cargo*Ot(i,"cargoMult")),this.shipPivot.position.set(0,0,0),this.shipPivot.quaternion.identity();for(let s=0;s<this.droneBays.length;s++){const r=dc(tc.scout).group;r.scale.setScalar(.35),r.userData.droneIndex=s,r.name="escortDrone",this.shipPivot.add(r)}}handleControls(e){const t=this.state.bonuses(),s=this.state.ship.stats(),r=Ot(t,"speedMult"),a=Ot(t,"turnMult"),o=tn.clamp(this.input.mouse.x,-1,1),l=tn.clamp(this.input.mouse.y,-1,1)*(this.state.settings.invertY?-1:1),c=this.state.settings.cameraSensitivity,h=(.9+s.torque*.55)*a*c,u=.08,d=Math.abs(o)>u?-(o-Math.sign(o)*u)/(1-u):0,f=Math.abs(l)>u?(l-Math.sign(l)*u)/(1-u):0,g=this.input.axis("KeyE","KeyQ"),v=Math.max(.25,1600/Math.max(400,this.mass));this.angularVelocity.x+=f*h*e*1.5*v,this.angularVelocity.y+=d*h*e*1.8*v,this.angularVelocity.z+=g*h*e*2.2*v;const p=Math.pow(.02,e);this.angularVelocity.multiplyScalar(p*.65+.35*Math.pow(.35,e));const m=new xn().setFromEuler(new xs(this.angularVelocity.x*e,this.angularVelocity.y*e,this.angularVelocity.z*e,"XYZ"));this.shipPivot.quaternion.multiply(m).normalize();const M=this.input.axis("KeyS","KeyW"),_=this.input.axis("KeyA","KeyD"),x=this.input.axis("KeyC","Space"),P=this.input.down("ShiftLeft")||this.input.down("ShiftRight");this.boost=tn.lerp(this.boost,P&&this.energy>5?1:0,e*6);const A=Math.max(60,s.thrust)*r*(1+this.boost*.65)/this.mass*yv,N=new R(0,0,1).applyQuaternion(this.shipPivot.quaternion),y=new R(1,0,0).applyQuaternion(this.shipPivot.quaternion),S=new R(0,1,0).applyQuaternion(this.shipPivot.quaternion);this.throttle=tn.lerp(this.throttle,Math.abs(M)>.1?M:0,e*5),M!==0&&this.velocity.addScaledVector(N,A*M*e*(M>0?1:.55)),_!==0&&this.velocity.addScaledVector(y,A*_*e*.42),x!==0&&this.velocity.addScaledVector(S,A*x*e*.42),this.input.down("KeyX")?this.velocity.multiplyScalar(Math.pow(.12,e)):this.velocity.multiplyScalar(Math.pow(.86,e));const D=240*r*(1+this.boost*.5);this.velocity.length()>D&&this.velocity.setLength(D);const X=s.energyGen*Ot(t,"energyRegenMult")-s.energyDraw-this.boost*12;this.energy=tn.clamp(this.energy+X*e,0,this.maxEnergy);for(const L of this.plumes){const B=L.dir.dot(new R(0,0,1));let H=0;if(M>0&&B>.5?H=.7+this.boost*.6:M<0&&B<-.5?H=.5:Math.abs(_)>0||Math.abs(x)>0||Math.abs(d)>.2?H=.3:H=.12,L.plume.setThrottle(H,e),H>.4&&Math.random()<.5){const Z=this.shipPivot.localToWorld(L.offset.clone().addScaledVector(L.dir,-2)),J=L.dir.clone().applyQuaternion(this.shipPivot.quaternion).multiplyScalar(-1);this.fx.thrusterPuff(Z,J,6737151,H*.7)}}}updateMining(e){var a;const t=this.input.mouse.right;if(this.miningTargets.clear(),!t||this.miningMuzzles.length===0)return;if(this.energy<=.5){Math.random()<.01&&((a=this.onNotify)==null||a.call(this,"Not enough power for the mining array.","error"));return}const i=this.state.bonuses(),s=Jl(i,"rareChance")+this.state.ship.stats().rareBonus,r=this.aimPoint(600);for(const o of this.miningMuzzles){const l=o.obj.getWorldPosition(new R),c=r.clone().sub(l).normalize();let h=null;for(const g of this.asteroids){const v=g.mesh.position.clone().sub(l),p=v.length();if(p>o.range+g.radius)continue;const m=v.dot(c);if(!(m<=0||v.clone().addScaledVector(c,-m).length()>g.radius*1.05)&&(!h||p<h.dist)){const _=l.clone().addScaledVector(c,Math.max(0,m-g.radius*.85));h={ast:g,point:_,dist:p}}}if(!h){this.fx.beam(l,l.clone().addScaledVector(c,o.range),16733491,.12,.05);continue}this.fx.beam(l,h.point,16739117,.3,.05),Math.random()<.6&&this.fx.impact(h.point,16751164,3,16),Math.random()<.08&&ve.mining();const u=o.dps*e;h.ast.health-=u,this.miningTargets.add(h.ast),this.statsCache.damageDealt+=u*.25;const d=h.ast.health/h.ast.maxHealth,f=d<.33?2:d<.66?1:0;if(f!==h.ast.damageStage){h.ast.damageStage=f;const g=h.ast.mesh.material;h.ast.mesh.material=g.clone(),h.ast.mesh.material.emissiveIntensity=1.1+f*.9,h.ast.mesh.material.color.offsetHSL(0,0,-.04),this.fx.impact(h.point,16765286,10,22)}h.ast.health<=0&&this.destroyAsteroid(h.ast,s)}}destroyAsteroid(e,t){var h;const i=this.asteroids.indexOf(e);if(i<0)return;this.asteroids.splice(i,1),this.scene.remove(e.mesh),e.mesh.geometry.dispose(),this.fx.explosion(e.mesh.position,Math.min(2.4,e.radius*.14),this.sector.rockStyle==="volcanic"?16747068:10532044),ve.explosion(Math.min(1.4,e.radius*.1)),this.cameraShake=Math.min(1.2,this.cameraShake+e.radius*.02),this.statsCache.asteroidsMined+=1;const s=this.state.bonuses(),r=Ot(s,"lootMult");let a=Math.min(9,2+Math.floor(e.radius/3));const o=Math.max(1,Math.round(e.amount*r)),l=Math.max(1,Math.round(o/a));let c=e.resource;if(!yt[c].rare&&Math.random()<t){const u=Object.keys(this.sector.resourceTable).filter(d=>yt[d].rare);u.length&&(c=this.rng.pick(u),this.statsCache.rareFinds+=1,(h=this.onNotify)==null||h.call(this,`Rare vein uncovered: ${yt[c].name}!`,"success"))}else yt[c].rare&&(this.statsCache.rareFinds+=1);for(let u=0;u<a;u++){const d=Ma(yt[c].color,this.rng.int(1,1e6),this.rng.range(.7,1.5));d.position.copy(e.mesh.position).add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(e.radius*.5)),this.scene.add(d),this.chunks.push({mesh:d,velocity:new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(this.rng.range(4,16)).add(e.velocity),resource:c,amount:l,life:70,collected:!1,spin:new R(this.rng.range(-3,3),this.rng.range(-3,3),this.rng.range(-3,3))})}this.spawnAsteroid(!1)}updateChunks(e){var a;const t=this.shipPivot.position,i=this.magnets.reduce((o,l)=>Math.max(o,l.range),0),s=this.magnets.reduce((o,l)=>o+l.force,0),r=9;for(let o=this.chunks.length-1;o>=0;o--){const l=this.chunks[o];l.life-=e;const c=t.clone().sub(l.mesh.position),h=c.length();if(i>0&&h<i){const u=s/Math.max(1,this.mass*.02)*(1-h/i);l.velocity.addScaledVector(c.normalize(),u*e*6),Math.random()<.02&&this.fx.pickup(l.mesh.position,yt[l.resource].color)}if(l.velocity.multiplyScalar(Math.pow(.9,e)),l.mesh.position.addScaledVector(l.velocity,e),l.mesh.rotation.x+=l.spin.x*e,l.mesh.rotation.y+=l.spin.y*e,!l.collected&&h<r){l.collected=!0;const u=this.cargoCap-this.cargo;if(u<=0)Math.random()<.05&&((a=this.onNotify)==null||a.call(this,"Cargo hold is full - return to the hangar.","error")),l.collected=!1,l.velocity.addScaledVector(c.normalize(),-20);else{const d=Math.min(u,l.amount);this.cargo+=d,this.oreHold[l.resource]=(this.oreHold[l.resource]??0)+d,this.statsCache.chunks+=1,this.fx.pickup(l.mesh.position,yt[l.resource].color),ve.pickup(),this.removeChunk(o);continue}}l.life<=0&&this.removeChunk(o)}}removeChunk(e){const t=this.chunks[e];this.scene.remove(t.mesh),t.mesh.geometry.dispose(),t.mesh.material.dispose(),this.chunks.splice(e,1)}aimPoint(e){const t=new R(0,0,1).applyQuaternion(this.shipPivot.quaternion);return this.shipPivot.position.clone().addScaledVector(t,e)}updateWeapons(e){const t=this.input.mouse.left,i=this.aimPoint(500);for(const s of this.weaponMounts){s.cooldown-=e;const r=s.obj.getWorldPosition(new R);let a=null,o=1/0;for(const d of this.enemies){if(d.dead)continue;const f=d.group.position.distanceTo(r);f<s.range&&f<o&&(o=f,a=d)}if(s.turret){const d=a?a.group.position:i,f=s.obj.worldToLocal(d.clone());let v=Math.atan2(f.x,f.z)-s.turret.rotation.y;for(;v>Math.PI;)v-=Math.PI*2;for(;v<-Math.PI;)v+=Math.PI*2;s.turret.rotation.y+=tn.clamp(v,-3.2*e,3.2*e)}if(!t||s.cooldown>0||this.energy<2)continue;s.cooldown=1/Math.max(.05,s.rate),this.energy=Math.max(0,this.energy-1.2);const l=new R;let c=null;(s.turret??s.obj).traverse(d=>{d.name==="muzzle"&&!c&&(c=d)}),c?c.getWorldPosition(l):l.copy(r);const u=(a?this.leadTarget(l,a,s.speed):i).clone().sub(l).normalize();if(s.speed>=900){const d=this.raycastEnemies(l,u,s.range);this.fx.beam(l,d?d.point:l.clone().addScaledVector(u,s.range),s.color,.28,.07),d&&(this.damageEnemy(d.enemy,s.damage,d.point),this.fx.impact(d.point,s.color,12,26)),ve.laser()}else this.spawnProjectile(l,u.multiplyScalar(s.speed).add(this.velocity.clone().multiplyScalar(.4)),s.damage,!0,s.splash,s.homing,a,s.color),s.splash>20?ve.rocket():ve.gun();this.fx.flash(l,s.color,18,.08),this.cameraShake=Math.min(.8,this.cameraShake+.04)}for(const s of this.droneBays){if(s.cooldown-=e,s.cooldown>0)continue;const r=this.enemies.find(o=>!o.dead&&o.group.position.distanceTo(this.shipPivot.position)<s.range);if(!r)continue;s.cooldown=1/Math.max(.1,s.rate);const a=this.shipPivot.position.clone().add(new R(this.rng.range(-8,8),this.rng.range(-4,4),this.rng.range(-8,8)));r.group.position.clone().sub(a).normalize(),this.fx.beam(a,r.group.position,16769162,.14,.06),this.damageEnemy(r,s.damage,r.group.position.clone())}}leadTarget(e,t,i){const r=t.group.position.clone().sub(e).length()/Math.max(1,i);return t.group.position.clone().addScaledVector(t.velocity,r)}raycastEnemies(e,t,i){let s=null;for(const r of this.enemies){if(r.dead)continue;const a=r.group.position.clone().sub(e),o=a.dot(t);if(o<0||o>i)continue;const l=a.clone().addScaledVector(t,-o).length(),c=r.def.scale*4;l>c||(!s||o<s.dist)&&(s={enemy:r,point:e.clone().addScaledVector(t,o),dist:o})}return s?{enemy:s.enemy,point:s.point}:null}spawnProjectile(e,t,i,s,r=0,a=0,o=null,l=16765286){const c=r>20?new Es(.5,2.4,4,8):new Pt(.42,8,6),h=new Yt({color:l,transparent:!0,opacity:.95,blending:un,depthWrite:!1}),u=new oe(c,h);u.position.copy(e),u.scale.setScalar(r>20?1.6:1.2),this.scene.add(u),this.projectiles.push({mesh:u,velocity:t,damage:i,life:4.5,friendly:s,splash:r,homing:a,target:o,color:l,trail:0})}updateProjectiles(e){for(let t=this.projectiles.length-1;t>=0;t--){const i=this.projectiles[t];if(i.life-=e,i.homing>0&&((!i.target||i.target.dead)&&(i.target=this.enemies.find(a=>!a.dead)??null),i.target)){const a=i.target.group.position.clone().sub(i.mesh.position).normalize().multiplyScalar(i.velocity.length());i.velocity.lerp(a,Math.min(1,i.homing*e))}const s=i.mesh.position.clone();i.mesh.position.addScaledVector(i.velocity,e),i.velocity.lengthSq()>.01&&i.mesh.quaternion.setFromUnitVectors(new R(0,1,0),i.velocity.clone().normalize()),i.trail+=e,i.trail>.02&&(i.trail=0,this.fx.thrusterPuff(i.mesh.position,i.velocity.clone().normalize().multiplyScalar(-1),i.color,.35));let r=!1;if(i.friendly){for(const a of this.enemies)if(!a.dead&&Sa(s,i.mesh.position,a.group.position,a.def.scale*4.6)){this.damageEnemy(a,i.damage,i.mesh.position.clone()),r=!0;break}if(!r){for(const a of this.asteroids)if(Sa(s,i.mesh.position,a.mesh.position,a.radius)){a.health-=i.damage*.5,this.fx.impact(i.mesh.position,16753510,10,20),a.health<=0&&this.destroyAsteroid(a,0),r=!0;break}}}else Sa(s,i.mesh.position,this.shipPivot.position,7)&&(this.damagePlayer(i.damage,i.mesh.position.clone()),r=!0);if(r||i.life<=0){if(r&&i.splash>0){this.fx.explosion(i.mesh.position,i.splash/24,i.color),ve.explosion(.6);for(const a of this.enemies){if(a.dead)continue;const o=a.group.position.distanceTo(i.mesh.position);o<i.splash&&i.friendly&&this.damageEnemy(a,i.damage*.5*(1-o/i.splash),a.group.position.clone())}}this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.projectiles.splice(t,1)}}}damageEnemy(e,t,i){if(!e.dead){if(this.statsCache.damageDealt+=t,e.shield>0){const s=Math.min(e.shield,t);e.shield-=s,t-=s,this.fx.shieldHit(i,i.clone().sub(e.group.position).normalize(),10147583),ve.shieldHit()}t>0&&(e.hull-=t,this.fx.impact(i,16747068,8,22)),e.hull<=0&&this.killEnemy(e)}}killEnemy(e){var o;e.dead=!0,this.fx.explosion(e.group.position,e.def.scale*.9,16757575),ve.explosion(e.def.scale*.6),this.cameraShake=Math.min(1.4,this.cameraShake+e.def.scale*.12),this.statsCache.enemiesKilled+=1;const t=this.state.bonuses(),i=Math.round(e.def.credits*this.sector.rewardMultiplier*Ot(t,"creditMult"));this.creditsEarned+=i;const s=this.rng.int(2,5),r=this.rng.pick(Object.keys(this.sector.resourceTable));for(let l=0;l<s;l++){const c=Ma(yt[r].color,this.rng.int(1,1e6),this.rng.range(.8,1.4));c.position.copy(e.group.position).add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(4)),this.scene.add(c),this.chunks.push({mesh:c,velocity:new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(12),resource:r,amount:Math.round(6*this.sector.rewardMultiplier),life:60,collected:!1,spin:new R(this.rng.range(-3,3),this.rng.range(-3,3),this.rng.range(-3,3))})}this.scene.remove(e.group);const a=this.enemies.indexOf(e);a>=0&&this.enemies.splice(a,1),(o=this.onNotify)==null||o.call(this,`${e.def.name} destroyed  ·  +${i.toLocaleString()} CR`,"success")}damagePlayer(e,t){var h;this.lastDamageTime=this.elapsed;const i=this.state.bonuses();if(this.shield>0){const u=Math.min(this.shield,e);this.shield-=u,e-=u,this.statsCache.shieldAbsorbed+=u,this.fx.shieldHit(t,t.clone().sub(this.shipPivot.position).normalize()),ve.shieldHit(),this.cameraShake=Math.min(1,this.cameraShake+.12)}if(e<=0)return;const s=this.state.ship,r=Ot(i,"armorMult"),a=s.modules.filter(u=>u.health>0);if(a.length===0)return;const o=a[Math.floor(Math.random()*a.length)],l=e/Math.max(1,r);o.health=Math.max(0,o.health-l),this.cameraShake=Math.min(1.5,this.cameraShake+.2),ve.explosion(.35);const c=this.shipGroup.children.find(u=>u.userData.uid===o.uid);if(c){const u=c.getWorldPosition(new R);this.fx.impact(u,16734780,14,26),o.health<=0&&(this.fx.explosion(u,.6,16739146),(h=this.onNotify)==null||h.call(this,`${Je(o.defId).name} disabled!`,"error"))}(s.modules.every(u=>u.health<=0)||!s.hasCockpit())&&this.failExpedition()}updateEnemies(e){const t=this.state.ship.stats();this.spawnTimer-=e;const i=Math.min(this.sector.enemyBudget,3+Math.floor(this.elapsed/25));this.spawnTimer<=0&&this.enemies.length<i&&(this.spawnTimer=Math.max(3.5,11-this.sector.danger*1.2),this.spawnEnemy());for(const r of this.enemies){if(r.dead)continue;const a=this.shipPivot.position.clone().sub(r.group.position),o=a.length(),l=a.clone().normalize();r.phase+=e;let c=new R;const h=r.def.range*.65;switch(r.def.behaviour){case"orbit":{const g=new R().crossVectors(l,nr).normalize();c=l.clone().multiplyScalar(o>h?1:-.6).add(g.multiplyScalar(.9));break}case"strafe":{const g=new R().crossVectors(l,nr).normalize().multiplyScalar(Math.sin(r.phase*.7)*1.2);c=l.clone().multiplyScalar(o>h?1:-.4).add(g);break}case"charge":{c=l.clone().multiplyScalar(o>r.def.range*.35?1.2:-.3);break}default:{c=l.clone().multiplyScalar(o>r.def.range*.9?1:o<r.def.range*.6?-.8:.05);const g=new R().crossVectors(l,nr).normalize().multiplyScalar(.4*Math.sin(r.phase*.4));c.add(g);break}}c.normalize().multiplyScalar(r.def.speed),r.velocity.lerp(c,Math.min(1,e*r.def.turn)),r.group.position.addScaledVector(r.velocity,e);const u=this.shipPivot.position.clone(),d=new pt().lookAt(r.group.position,u,nr),f=new xn().setFromRotationMatrix(d);r.group.quaternion.slerp(f,Math.min(1,e*r.def.turn*1.6));for(const g of r.plumes)g.setThrottle(.6+Math.sin(r.phase*4)*.2,e);if(r.maxShield>0&&(r.shield=Math.min(r.maxShield,r.shield+r.maxShield*.04*e)),r.cooldown-=e,o<r.def.range&&r.cooldown<=0){r.cooldown=1/r.def.fireRate;const v=(r.muzzles.length?r.muzzles[Math.floor(Math.random()*r.muzzles.length)]:r.group).getWorldPosition(new R),m=this.shipPivot.position.clone().addScaledVector(this.velocity,o/r.def.projectileSpeed*.8).sub(v).normalize();m.add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(.03)).normalize(),this.spawnProjectile(v,m.multiplyScalar(r.def.projectileSpeed),r.def.damage,!1,0,0,null,r.def.accent),this.fx.flash(v,r.def.accent,12,.07),ve.gun()}o<r.def.scale*4+6&&(this.damagePlayer(r.def.damage*.5*e*6,r.group.position.clone()),r.velocity.addScaledVector(l,-r.def.speed*.6))}const s=this.state.bonuses();if(this.maxShield>0&&this.elapsed-this.lastDamageTime>3&&(this.shield=Math.min(this.maxShield,this.shield+t.shieldRegen*Ot(s,"shieldRegenMult")*e)),t.repair>0&&this.elapsed-this.lastDamageTime>5){const r=t.repair*Ot(s,"repairMult")*e;for(const a of this.state.ship.modules){const o=this.state.ship.maxHealth(a);if(a.health<o){a.health=Math.min(o,a.health+r);break}}}}spawnEnemy(){var o;const e=this.sector.enemies,t=tc[this.rng.weighted(e.map(l=>l.type),e.map(l=>l.weight))],i=dc(t),s=new R(this.rng.gauss(),this.rng.gauss()*.3,this.rng.gauss()).normalize();i.group.position.copy(this.shipPivot.position).add(s.multiplyScalar(this.rng.range(280,420))),this.scene.add(i.group);const r=[];for(const l of i.engines){const c=new Wa(t.accent,t.scale*.6);l.add(c.group),r.push(c)}const a=1+this.state.tier*.12;this.enemies.push({def:t,group:i.group,muzzles:i.muzzles,hull:t.hull*a,maxHull:t.hull*a,shield:t.shield*a,maxShield:t.shield*a,velocity:new R,cooldown:this.rng.range(.5,2),state:"approach",phase:this.rng.range(0,10),plumes:r,dead:!1}),(t.type==="sentinel"||t.type==="heavy")&&((o=this.onNotify)==null||o.call(this,`${t.name} inbound!`,"error"))}updateHazards(e){var s;this.hazardTimer-=e,this.hazardWarning="";const t=this.state.bonuses(),i=Jl(t,"hazardResist");switch(this.sector.hazard){case"lightning":{if(this.hazardTimer<=0){this.hazardTimer=this.rng.range(2.2,5.5);const r=this.shipPivot.position.clone().add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(260)),a=this.rng.chance(.45),o=a?this.shipPivot.position.clone():this.shipPivot.position.clone().add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(120));if(this.fx.lightning(r,o,10479871),ve.explosion(.5),a){const l=26*this.sector.danger*(1-Math.min(.85,i));this.damagePlayer(l,this.shipPivot.position.clone()),(s=this.onNotify)==null||s.call(this,"Plasma arc strike!","error")}}this.hazardTimer<.7&&(this.hazardWarning="ARC DISCHARGE IMMINENT");break}case"debris":{if(this.hazardTimer<=0){this.hazardTimer=this.rng.range(1.5,4);const r=new R(this.rng.gauss(),this.rng.gauss()*.4,this.rng.gauss()).normalize(),a=Ma(9081766,this.rng.int(1,1e6),this.rng.range(1.4,3));a.position.copy(this.shipPivot.position).add(r.multiplyScalar(420)),this.scene.add(a),this.chunks.push({mesh:a,velocity:r.multiplyScalar(-this.rng.range(40,90)),resource:"iron",amount:4,life:25,collected:!1,spin:new R(this.rng.range(-4,4),this.rng.range(-4,4),this.rng.range(-4,4))})}break}case"anomaly":{const a=new R(Math.sin(this.elapsed*.08)*300,Math.cos(this.elapsed*.05)*120,Math.cos(this.elapsed*.07)*300).clone().sub(this.shipPivot.position),o=a.length();if(o<420){const l=(1-o/420)*26*(1-Math.min(.8,i));this.velocity.addScaledVector(a.normalize(),l*e),this.hazardWarning="GRAVITY ANOMALY",Math.random()<.3&&this.fx.ambientDust(this.shipPivot.position,60,12160255,2)}break}}}updateCamera(e){const t=new R(0,0,-1).applyQuaternion(this.shipPivot.quaternion),i=new R(0,1,0).applyQuaternion(this.shipPivot.quaternion);this.cameraDistance=tn.clamp(this.cameraDistance+this.input.mouse.wheel*.02,16,90);const s=Math.min(14,this.velocity.length()*.06),r=this.shipPivot.position.clone().addScaledVector(t,this.cameraDistance+s).addScaledVector(i,this.cameraDistance*.32);this.camera.position.lerp(r,Math.min(1,e*5.5));const a=this.shipPivot.position.clone().addScaledVector(new R(0,0,1).applyQuaternion(this.shipPivot.quaternion),26);this.camera.up.lerp(i,Math.min(1,e*4)),this.camera.lookAt(a),this.cameraShake>.001&&(this.camera.position.add(new R(this.rng.gauss(),this.rng.gauss(),this.rng.gauss()).multiplyScalar(this.cameraShake*.9)),this.cameraShake*=Math.pow(.02,e));const o=62+Math.min(18,this.velocity.length()*.07)+this.boost*6;this.camera.fov+=(o-this.camera.fov)*Math.min(1,e*3),this.camera.updateProjectionMatrix()}update(e){if(!this.active)return;this.elapsed+=e;const t=this.shipPivot.position.clone();this.handleControls(e),this.shipPivot.position.addScaledVector(this.velocity,e),this.statsCache.distance+=t.distanceTo(this.shipPivot.position);const i=this.shipPivot.position.length();if(i>this.bounds){const s=this.shipPivot.position.clone().multiplyScalar(-1).normalize();this.velocity.addScaledVector(s,(i-this.bounds)*.6*e),this.hazardWarning="RETURNING TO SECTOR"}this.updateMining(e),this.updateWeapons(e),this.updateProjectiles(e),this.updateChunks(e),this.updateEnemies(e),this.updateHazards(e),this.updateCamera(e),this.fx.update(e);for(const s of this.asteroids)if(s.mesh.position.addScaledVector(s.velocity,e),s.mesh.rotation.x+=s.spin.x*e,s.mesh.rotation.y+=s.spin.y*e,s.mesh.rotation.z+=s.spin.z*e,s.mesh.position.distanceTo(this.shipPivot.position)<s.radius+6){const a=this.shipPivot.position.clone().sub(s.mesh.position).normalize();this.velocity.addScaledVector(a,60*e*6),this.damagePlayer(this.velocity.length()*.12,this.shipPivot.position.clone()),this.cameraShake=Math.min(1.2,this.cameraShake+.3)}this.shipPivot.children.forEach(s=>{if(s.name!=="escortDrone")return;const r=s.userData.droneIndex??0,a=this.elapsed*1.1+r*2.2;s.position.set(Math.cos(a)*16,Math.sin(a*.7)*6+4,Math.sin(a)*16),s.lookAt(this.shipPivot.position.clone().add(new R(Math.cos(a+.4)*30,0,Math.sin(a+.4)*30)))}),Math.random()<.6&&this.fx.ambientDust(this.shipPivot.position,180,this.sector.nebula[0],this.quality==="low"?1:2),this.updateHud()}updateHud(){const e=this.state.ship,t=e.stats(),i=e.modules.reduce((g,v)=>g+v.health,0),s=e.modules.reduce((g,v)=>g+e.maxHealth(v),0),r=[],a=this.shipPivot.quaternion.clone().invert(),o=(g,v)=>{const p=g.clone().sub(this.shipPivot.position).applyQuaternion(a),m=600,M=tn.clamp(p.x/m,-1,1),_=tn.clamp(p.z/m,-1,1);r.push({x:M,y:_,type:v})};for(const g of this.enemies)g.dead||o(g.group.position,"enemy");const l=Math.max(260,t.radarRange);for(const g of this.asteroids)g.mesh.position.distanceTo(this.shipPivot.position)<l&&o(g.mesh.position,"rock");for(const g of this.chunks.slice(0,40))o(g.mesh.position,"chunk");const c=[];this.hazardWarning&&c.push(this.hazardWarning),this.cargo>=this.cargoCap&&c.push("CARGO FULL"),i/Math.max(1,s)<.3&&c.push("HULL CRITICAL"),t.energyBalance<0&&c.push("ENERGY DEFICIT");let h=null,u=0,d=0;const f=[...this.miningTargets][0];if(f)h=`${yt[f.resource].name} Asteroid`,u=f.health,d=f.maxHealth;else{const g=new R(0,0,1).applyQuaternion(this.shipPivot.quaternion);let v=null;for(const p of this.enemies){if(p.dead)continue;const M=p.group.position.clone().sub(this.shipPivot.position).normalize().dot(g);M>.9&&(!v||M>v.dot)&&(v={e:p,dot:M})}v&&(h=v.e.def.name,u=v.e.hull+v.e.shield,d=v.e.maxHull+v.e.maxShield)}this.hud={hull:i,maxHull:s,shield:this.shield,maxShield:this.maxShield,energy:this.energy,maxEnergy:this.maxEnergy,cargo:this.cargo,cargoCap:this.cargoCap,speed:this.velocity.length(),throttle:this.throttle,sector:this.sector.name,asteroidsMined:this.statsCache.asteroidsMined,enemiesKilled:this.statsCache.enemiesKilled,credits:this.creditsEarned,ore:{...this.oreHold},targetName:h,targetHealth:u,targetMaxHealth:d,radarBlips:r,warnings:c,elapsed:this.elapsed}}start(){this.active=!0}failExpedition(){var e;this.active&&((e=this.onNotify)==null||e.call(this,"Hull integrity lost - emergency extraction engaged.","error"),this.complete(!0))}complete(e=!1){var c;this.active=!1;const t=this.state.bonuses(),i=Ot(t,"creditMult");let s=0;const r={},a=e?.45:1;for(const[h,u]of Object.entries(this.oreHold)){const d=Math.floor(u*a);d<=0||(r[h]=d,s+=d*yt[h].value)}const o=Math.round((this.creditsEarned+s)*(e?.6:1)*i),l={sector:this.sector,failed:e,credits:o,ore:r,oreUnits:Object.values(r).reduce((h,u)=>h+u,0),asteroidsMined:this.statsCache.asteroidsMined,enemiesKilled:this.statsCache.enemiesKilled,distance:Math.round(this.statsCache.distance),chunks:this.statsCache.chunks,damageDealt:Math.round(this.statsCache.damageDealt),rareFinds:this.statsCache.rareFinds,shieldAbsorbed:Math.round(this.statsCache.shieldAbsorbed),duration:this.elapsed,fifthSlotUnlocked:!1};return(c=this.onReturn)==null||c.call(this,l),l}dispose(){this.active=!1,this.scene.traverse(e=>{var i,s,r;const t=e;if(t.isMesh){(s=(i=t.geometry)==null?void 0:i.dispose)==null||s.call(i);const a=t.material;Array.isArray(a)?a.forEach(o=>o.dispose()):(r=a==null?void 0:a.dispose)==null||r.call(a)}}),this.scene.clear()}}function b(n,e={},t=[]){const i=document.createElement(n);for(const[s,r]of Object.entries(e))r!=null&&(s==="class"?i.className=String(r):s==="style"&&typeof r=="object"?Object.assign(i.style,r):s.startsWith("on")&&typeof r=="function"?i.addEventListener(s.slice(2).toLowerCase(),r):s==="html"?i.innerHTML=String(r):s in i?i[s]=r:i.setAttribute(s,String(r)));for(const s of t)s!=null&&i.appendChild(typeof s=="string"?document.createTextNode(s):s);return i}function St(n){for(;n.firstChild;)n.removeChild(n.firstChild)}function Ee(n){return Number.isFinite(n)?Math.abs(n)>=1e6?`${(n/1e6).toFixed(2)}M`:Math.abs(n)>=1e4?`${(n/1e3).toFixed(1)}k`:Math.round(n).toLocaleString("en-US"):"0"}const Mv=[{id:"hangar",label:"HANGAR BAY",icon:"H"},{id:"builder",label:"SHIP BUILDER",icon:"B"},{id:"shop",label:"EQUIPMENT SHOP",icon:"E"},{id:"crew",label:"CREW COLLECTION",icon:"C"},{id:"packs",label:"CARD PACKS",icon:"P"},{id:"achievements",label:"ACHIEVEMENTS",icon:"A"},{id:"upgrades",label:"ACTIVE UPGRADES",icon:"U"},{id:"sectors",label:"SECTOR MAP",icon:"S"},{id:"stats",label:"LOGBOOK",icon:"L"},{id:"settings",label:"SETTINGS",icon:"O"}];class Sv{constructor(e,t){this.current="hangar",this.onNavigate=null,this.navButtons=new Map,this.root=e,this.state=t,this.layer=b("div",{class:"ui-layer"}),this.creditsEl=b("b",{},["0"]),this.crystalsEl=b("b",{},["0"]),this.crewEl=b("b",{},["0/0"]),this.cargoEl=b("b",{},["0"]),this.topbar=b("div",{class:"topbar"},[b("div",{class:"brand"},[b("span",{},["SPACE MINER"]),": BUILD & CONQUER"]),b("div",{class:"stats"},[b("div",{class:"pill gold",title:"Credits - earned from ore and bounties"},["CR ",this.creditsEl]),b("div",{class:"pill crystal",title:"Crystals - earned from achievements, spent on card packs"},["CRYSTALS ",this.crystalsEl]),b("div",{class:"pill",title:"Equipped crew / unlocked crew slots"},["CREW ",this.crewEl]),b("div",{class:"pill",title:"Ore stored in the hangar silo"},["SILO ",this.cargoEl])])]),this.sidebar=b("div",{class:"sidebar"});for(const s of Mv){const r=b("button",{class:"navbtn",onclick:()=>{ve.uiClick(),this.navigate(s.id)},onmouseenter:()=>ve.uiHover()},[b("div",{class:"navico"},[s.icon]),b("span",{},[s.label])]);this.navButtons.set(s.id,r),this.sidebar.appendChild(r)}this.sidebar.appendChild(b("div",{style:{flex:"1"}})),this.sidebar.appendChild(b("div",{class:"mini",style:{padding:"8px",lineHeight:"1.6"}},["CAMERA: drag to orbit · wheel to zoom",b("br",{}),"BUILD: R rotate · click to place",b("br",{}),"FLIGHT: WASD · Space/C · Shift boost"])),this.panelHost=b("div",{class:"panel"});const i=b("div",{class:"layout"},[this.sidebar,this.panelHost]);this.toastStack=b("div",{class:"toastStack"}),this.modalHost=b("div",{style:{position:"absolute",inset:"0",pointerEvents:"none",zIndex:"60"}}),this.layer.append(this.topbar,i,this.toastStack,this.modalHost),e.appendChild(this.layer),this.refreshCurrencies()}navigate(e){var t;this.current=e;for(const[i,s]of this.navButtons)s.classList.toggle("active",i===e);(t=this.onNavigate)==null||t.call(this,e)}setPanelTransparent(e){this.panelHost.style.background=e?"transparent":"rgba(2,4,18,0.74)",this.panelHost.style.pointerEvents=e?"none":"auto",this.panelHost.style.backdropFilter=e?"none":"blur(10px)"}setPanel(e){St(this.panelHost),this.panelHost.appendChild(e),e.animate([{opacity:0,transform:"translateY(10px)"},{opacity:1,transform:"translateY(0)"}],{duration:this.state.settings.reducedMotion?1:240,easing:"cubic-bezier(.2,.8,.2,1)"})}refreshCurrencies(){this.creditsEl.textContent=Ee(this.state.credits),this.crystalsEl.textContent=Ee(this.state.crystals),this.crewEl.textContent=`${this.state.equippedCrew.length}/${this.state.crewSlots}`;const e=Object.values(this.state.ore).reduce((t,i)=>t+i,0);this.cargoEl.textContent=Ee(e)}toast(e,t="info"){var r;const s=b("div",{class:"toast",style:{borderColor:{info:"rgba(0,229,255,0.25)",error:"rgba(255,59,107,0.4)",success:"rgba(0,255,157,0.35)"}[t]}},[e]);for(this.toastStack.appendChild(s),s.animate([{opacity:0,transform:"translateX(24px)"},{opacity:1,transform:"translateX(0)"}],{duration:this.state.settings.reducedMotion?1:200,easing:"ease-out"}),setTimeout(()=>{s.animate([{opacity:1},{opacity:0}],{duration:260}).onfinish=()=>s.remove()},3400);this.toastStack.children.length>5;)(r=this.toastStack.firstChild)==null||r.remove()}modal(e,t={}){const i=b("div",{class:"modalBackdrop",style:{pointerEvents:"auto"}},[e]),s=()=>{var r;i.animate([{opacity:1},{opacity:0}],{duration:180}).onfinish=()=>i.remove(),(r=t.onClose)==null||r.call(t)};return t.dismissable!==!1&&i.addEventListener("click",r=>{r.target===i&&s()}),this.modalHost.appendChild(i),i.animate([{opacity:0},{opacity:1}],{duration:this.state.settings.reducedMotion?1:200}),s}confirm(e,t,i="CONFIRM"){return new Promise(s=>{let r=!1;const a=c=>{r||(r=!0,l(),s(c))},o=b("div",{class:"modal",style:{width:"min(520px,94vw)",padding:"22px"}},[b("h2",{style:{fontFamily:"Orbitron",fontSize:"15px",letterSpacing:"0.1em",marginBottom:"12px"}},[e]),b("p",{style:{opacity:"0.82",lineHeight:"1.6",marginBottom:"18px"}},[t]),b("div",{style:{display:"flex",gap:"10px",justifyContent:"flex-end"}},[b("button",{class:"btn ghost",onclick:()=>a(!1)},["CANCEL"]),b("button",{class:"btn",onclick:()=>a(!0)},[i])])]),l=this.modal(o,{onClose:()=>a(!1)})})}}class xv{constructor(e,t){this.bars={},this.state=e;const i=(l,c,h)=>{const u=b("i",{style:{width:"0%",background:h}}),d=b("span",{class:"mini",style:{fontFamily:"JetBrains Mono"}},["0"]);return this.bars[l]={fill:u,label:d},b("div",{style:{marginBottom:"8px"}},[b("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:"3px"}},[b("span",{class:"mini"},[c]),d]),b("div",{class:"progress"},[u])])};this.radar=document.createElement("canvas"),this.radar.width=220,this.radar.height=220,Object.assign(this.radar.style,{width:"170px",height:"170px",display:"block"}),this.targetBox=b("div",{class:"hudCard",style:{minWidth:"240px"}}),this.warnBox=b("div",{style:{display:"flex",flexDirection:"column",gap:"6px",alignItems:"center"}}),this.oreBox=b("div",{class:"hudCard",style:{minWidth:"200px"}}),this.statBox=b("div",{class:"hudCard",style:{minWidth:"180px"}}),this.objectivesBox=b("div",{class:"hudCard",style:{position:"absolute",right:"14px",top:"210px",width:"250px"}});const s=b("div",{class:"spaceHud",style:{top:"80px",left:"16px",width:"290px"}},[i("hull","HULL INTEGRITY","linear-gradient(90deg,#00ff9d,#00e5ff)"),i("shield","SHIELDS","linear-gradient(90deg,#49b6ff,#7b61ff)"),i("energy","ENERGY","linear-gradient(90deg,#ffd166,#ff8a3c)"),i("cargo","CARGO HOLD","linear-gradient(90deg,#b6ff6e,#00ff9d)"),this.targetBox]),r=b("div",{style:{position:"absolute",right:"14px",top:"80px",display:"flex",flexDirection:"column",gap:"10px",alignItems:"flex-end"}},[b("div",{class:"hudCard",style:{padding:"8px"}},[this.radar]),this.statBox,this.oreBox]),a=b("div",{style:{position:"absolute",left:"50%",bottom:"16px",transform:"translateX(-50%)",display:"flex",gap:"12px",alignItems:"center"}},[b("div",{class:"hudCard",style:{display:"flex",gap:"14px",alignItems:"center"}},[b("span",{class:"mini"},["W/S thrust · A/D strafe · Space/C lift · Q/E roll · X brake · Shift boost"]),b("span",{class:"mini",style:{color:"#00e5ff"}},["LMB weapons · RMB mining laser"])]),b("button",{class:"btn gold",onclick:t},["RETURN TO HANGAR"])]),o=b("div",{style:{position:"absolute",left:"50%",top:"96px",transform:"translateX(-50%)"}},[this.warnBox]);this.root=b("div",{class:"ui-layer"},[s,r,a,o,this.objectivesBox,b("div",{class:"crosshair"})])}update(e){const t=(r,a,o,l)=>{const c=this.bars[r];if(!c)return;const h=o>0?Math.max(0,Math.min(1,a/o)):0;c.fill.style.width=`${h*100}%`,c.label.textContent=l??`${Ee(a)} / ${Ee(o)}`};t("hull",e.hull,e.maxHull),t("shield",e.shield,e.maxShield,e.maxShield>0?void 0:"NO SHIELD GENERATOR"),t("energy",e.energy,e.maxEnergy),t("cargo",e.cargo,e.cargoCap),St(this.targetBox),e.targetName?this.targetBox.append(b("div",{class:"mini"},["TARGET"]),b("b",{style:{fontSize:"12px"}},[e.targetName]),b("div",{class:"progress",style:{marginTop:"6px"}},[b("i",{style:{width:`${Math.max(0,Math.min(100,e.targetHealth/Math.max(1,e.targetMaxHealth)*100))}%`,background:"linear-gradient(90deg,#ff3b6b,#ffb700)"}})])):this.targetBox.append(b("div",{class:"mini"},["NO TARGET LOCKED"])),St(this.statBox),this.statBox.append(b("div",{class:"mini"},[e.sector]),b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini"},["SPEED"]),b("b",{class:"mini"},[`${Ee(e.speed)} m/s`])]),b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini"},["MINED"]),b("b",{class:"mini"},[Ee(e.asteroidsMined)])]),b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini"},["KILLS"]),b("b",{class:"mini"},[Ee(e.enemiesKilled)])]),b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini"},["BOUNTY"]),b("b",{class:"mini",style:{color:"#ffb700"}},[`${Ee(e.credits)} CR`])])),St(this.oreBox);const i=Object.entries(e.ore).filter(([,r])=>r>0);this.oreBox.append(b("div",{class:"mini"},["CARGO MANIFEST"])),i.length||this.oreBox.append(b("div",{class:"mini",style:{opacity:"0.6"}},["Empty"]));for(const[r,a]of i)this.oreBox.append(b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini",style:{color:`#${yt[r].color.toString(16).padStart(6,"0")}`}},[yt[r].name]),b("b",{class:"mini"},[Ee(a)])]));St(this.warnBox);for(const r of e.warnings)this.warnBox.append(b("div",{style:{padding:"6px 14px",borderRadius:"999px",background:"rgba(255,59,107,0.16)",border:"1px solid rgba(255,59,107,0.5)",fontFamily:"Orbitron",fontSize:"10px",letterSpacing:"0.14em",animation:"none"}},[r]));St(this.objectivesBox);const s=this.state.achievements.active.filter(r=>r.period==="minute").slice(0,5);this.objectivesBox.append(b("div",{class:"mini"},["MINUTE OBJECTIVES"]));for(const r of s){const a=this.state.achievements.state.progress[r.key]??0;this.objectivesBox.append(b("div",{style:{marginTop:"6px"}},[b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini"},[r.name]),b("span",{class:"mini",style:{color:a>=r.target?"#00ff9d":"#8aa"}},[`${Ee(Math.min(a,r.target))}/${Ee(r.target)}`])]),b("div",{class:"progress"},[b("i",{style:{width:`${Math.min(100,a/r.target*100)}%`}})])]))}this.drawRadar(e)}drawRadar(e){const t=this.radar.getContext("2d"),i=this.radar.width,s=this.radar.height;t.clearRect(0,0,i,s),t.fillStyle="rgba(2,8,20,0.85)",t.beginPath(),t.arc(i/2,s/2,i/2-2,0,Math.PI*2),t.fill(),t.strokeStyle="rgba(0,229,255,0.35)",t.lineWidth=1.5;for(let r=1;r<=3;r++)t.beginPath(),t.arc(i/2,s/2,(i/2-4)*r/3,0,Math.PI*2),t.stroke();t.beginPath(),t.moveTo(i/2,4),t.lineTo(i/2,s-4),t.moveTo(4,s/2),t.lineTo(i-4,s/2),t.stroke();for(const r of e.radarBlips){const a=i/2+r.x*(i/2-8),o=s/2-r.y*(s/2-8);t.fillStyle=r.type==="enemy"?"#ff3b6b":r.type==="chunk"?"#b6ff6e":"rgba(180,200,230,0.75)",t.beginPath(),t.arc(a,o,r.type==="enemy"?4:2.2,0,Math.PI*2),t.fill()}t.fillStyle="#00e5ff",t.beginPath(),t.moveTo(i/2,s/2-7),t.lineTo(i/2+5,s/2+6),t.lineTo(i/2-5,s/2+6),t.closePath(),t.fill()}}function bv(n){const{state:e,hangar:t}=n;t.setMode("view");const i=e.ship.stats(),s=(a,o,l)=>b("div",{style:{background:"rgba(8,13,30,0.9)",border:"1px solid rgba(0,229,255,0.2)",borderRadius:"12px",padding:"10px 12px",minWidth:"140px"}},[b("div",{class:"mini"},[a]),b("b",{style:{fontSize:"16px",fontFamily:"JetBrains Mono"}},[o]),l?b("div",{class:"mini",style:{opacity:"0.7"}},[l]):null]),r=(a,o)=>b("button",{class:"btn ghost small",onclick:()=>{ve.uiClick(),n.shell.navigate(o)}},[a]);return b("div",{style:{position:"relative",width:"100%",height:"100%",pointerEvents:"none"}},[b("div",{style:{position:"absolute",left:"14px",bottom:"14px",display:"flex",gap:"10px",flexWrap:"wrap",pointerEvents:"auto",maxWidth:"calc(100% - 28px)"}},[s("SHIP MASS",`${Ee(i.mass)} t`,`${i.moduleCount} modules`),s("THRUST / MASS",i.thrustToMass.toFixed(2),i.thrustToMass>.3?"Responsive":"Sluggish - add engines"),s("ENERGY",`${Ee(i.energyGen)}/${Ee(i.energyDraw)}`,i.energyBalance>=0?"Stable":"Deficit!"),s("MINING DPS",Ee(i.miningDps)),s("WEAPON DPS",Ee(i.weaponDps)),s("CREW SLOTS",`${e.equippedCrew.length}/${e.crewSlots}`,`${gh(e.ship.purchasedCount)} cells to next (${Math.round(vh(e.ship.purchasedCount)*100)}%)`)]),b("div",{style:{position:"absolute",right:"14px",bottom:"14px",display:"flex",gap:"8px",pointerEvents:"auto",flexWrap:"wrap",justifyContent:"flex-end",maxWidth:"420px"}},[r("SHIP BUILDER","builder"),r("EQUIPMENT","shop"),r("CREW","crew"),r("PACKS","packs"),r("ACHIEVEMENTS","achievements"),b("button",{class:"btn gold",onclick:()=>{ve.uiClick(),n.shell.navigate("sectors")}},["LAUNCH EXPEDITION"])]),b("div",{style:{position:"absolute",left:"50%",top:"14px",transform:"translateX(-50%)",pointerEvents:"none",textAlign:"center"}},[b("div",{class:"mini",style:{letterSpacing:"0.18em",fontFamily:"Orbitron"}},["DOCK ALPHA · ORBITAL FOUNDRY"]),b("div",{class:"mini",style:{opacity:"0.6"}},["Click a station terminal in the hangar, or use the menu on the left"])])])}function Ev(n){const{state:e,hangar:t}=n;t.setMode("build");const i=b("div",{style:{position:"absolute",left:"14px",top:"14px",width:"268px",maxHeight:"calc(100% - 28px)",overflow:"auto",background:"rgba(8,13,30,0.92)",border:"1px solid rgba(0,229,255,0.22)",borderRadius:"14px",padding:"12px",pointerEvents:"auto",backdropFilter:"blur(10px)"}}),s=b("div",{style:{position:"absolute",right:"14px",top:"14px",width:"280px",background:"rgba(8,13,30,0.92)",border:"1px solid rgba(0,229,255,0.22)",borderRadius:"14px",padding:"12px",pointerEvents:"auto",backdropFilter:"blur(10px)"}}),r=b("div",{style:{position:"absolute",left:"50%",bottom:"18px",transform:"translateX(-50%)",background:"rgba(8,13,30,0.92)",border:"1px solid rgba(0,229,255,0.22)",borderRadius:"12px",padding:"10px 16px",pointerEvents:"auto",display:"flex",gap:"12px",alignItems:"center"}}),a=()=>{St(i),i.appendChild(b("h2",{style:{fontFamily:"Orbitron",fontSize:"12px",letterSpacing:"0.1em",marginBottom:"10px"}},["MODULE INVENTORY"]));const u=Object.entries(e.inventory).filter(([,f])=>f>0);u.length||i.appendChild(b("div",{class:"mini",style:{lineHeight:"1.5"}},["Inventory empty. Buy modules in the Equipment Shop, then place them here."]));for(const[f,g]of u){const v=Je(f),p=t.selectedModule===f;i.appendChild(b("button",{class:"navbtn",style:{marginBottom:"6px",borderColor:p?"rgba(0,229,255,0.7)":"rgba(255,255,255,0.07)",background:p?"rgba(0,229,255,0.16)":"rgba(255,255,255,0.04)"},onclick:()=>{ve.uiClick(),t.selectModule(p?null:f),a()}},[b("div",{class:"navico",style:{background:`#${v.accent.toString(16).padStart(6,"0")}22`}},[String(g)]),b("div",{style:{display:"flex",flexDirection:"column",gap:"2px",textAlign:"left"}},[b("span",{style:{fontSize:"11px"}},[v.name]),b("span",{class:"mini"},[`${gr[v.category]} · ${v.size.join("x")} · ${v.mass}t`])])]))}i.appendChild(b("div",{style:{height:"10px"}})),i.appendChild(b("h2",{style:{fontFamily:"Orbitron",fontSize:"12px",letterSpacing:"0.1em",margin:"8px 0"}},["EXPANSION CELLS"]));const d=mh(e.ship.purchasedCount);i.appendChild(b("div",{class:"mini",style:{lineHeight:"1.5",marginBottom:"8px"}},[`Next cell: ${Ee(d)} CR. Purchased: ${e.ship.purchasedCount}. `,`Every 10 cells unlock 1 crew slot (${gh(e.ship.purchasedCount)} to go).`])),i.appendChild(b("button",{class:t.cellPurchaseMode?"btn":"btn ghost",style:{width:"100%"},onclick:()=>{ve.uiClick(),t.setCellPurchaseMode(!t.cellPurchaseMode),a()}},[t.cellPurchaseMode?"EXIT CELL PURCHASE":"BUY EXPANSION CELLS"]))},o=()=>{St(s);const u=e.ship,d=u.stats(),f=za(u.purchasedCount),g=vh(u.purchasedCount),v=(p,m,M="#e6eaff")=>b("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"11px",padding:"3px 0"}},[b("span",{style:{opacity:"0.7"}},[p]),b("b",{style:{fontFamily:"JetBrains Mono",color:M}},[m])]);s.append(b("h2",{style:{fontFamily:"Orbitron",fontSize:"12px",letterSpacing:"0.1em",marginBottom:"10px"}},["SHIP ANALYSIS"]),v("Modules",String(d.moduleCount)),v("Total mass",`${Ee(d.mass)} t`),v("Centre of mass",d.centerOfMass.map(p=>p.toFixed(2)).join(" / ")),v("Thrust",`${Ee(d.thrust)} kN`),v("Thrust / mass",d.thrustToMass.toFixed(2),d.thrustToMass>.35?"#00ff9d":"#ffb700"),v("Torque",d.torque.toFixed(2)),v("Energy",`${Ee(d.energyGen)} / ${Ee(d.energyDraw)}`,d.energyBalance>=0?"#00ff9d":"#ff3b6b"),v("Hull integrity",Ee(d.hull)),v("Shields",Ee(d.shield)),v("Cargo",Ee(d.cargo)),v("Mining DPS",Ee(d.miningDps)),v("Weapon DPS",Ee(d.weaponDps)),v("Magnet range",`${Ee(d.magnetRange)} m`),b("div",{style:{height:"10px"}}),b("div",{class:"mini"},[`Crew slots: ${f} (${Math.round(g*100)}% to next)`]),b("div",{class:"progress",style:{marginTop:"6px"}},[b("i",{style:{width:`${g*100}%`}})]),b("div",{style:{height:"10px"}}),b("div",{class:"mini",style:{lineHeight:"1.5"}},[d.energyBalance<0?"WARNING: energy deficit - install an Energy Generator or remove draw.":"Energy balance nominal."]))},l=()=>{St(r);const u=hh[t.selectedOrientation];r.append(b("span",{class:"mini"},[t.cellPurchaseMode?"Click a golden cell to purchase it.":t.selectedModule?`Placing ${Je(t.selectedModule).name} · facing ${u}`:"Select a module from the inventory, or click an installed module to remove it."]),b("button",{class:"btn ghost small",onclick:()=>{t.rotateSelection(1),l()}},["ROTATE (R)"]),b("button",{class:"btn ghost small",onclick:()=>{t.selectModule(null),t.setCellPurchaseMode(!1),a(),l()}},["CLEAR SELECTION"]),b("button",{class:"btn",onclick:()=>{ve.uiClick(),n.shell.navigate("sectors")}},["LAUNCH EXPEDITION"]))},c=u=>{u.code==="KeyR"&&(t.rotateSelection(u.shiftKey?-1:1),l()),u.code==="Escape"&&(t.selectModule(null),t.setCellPurchaseMode(!1),a(),l())};window.addEventListener("keydown",c),t.onShipChanged=()=>{a(),o(),n.refresh()},a(),o(),l();const h=b("div",{style:{position:"relative",width:"100%",height:"100%",pointerEvents:"none"}},[i,s,r]);return h.dispose=()=>{window.removeEventListener("keydown",c),t.onShipChanged=null},h}const wv=["all","structure","propulsion","mining","collection","weapon","defense","utility","command","installed"];function Mh(n,e=1){const t=[],i=n.stats,s=(r,a,o="",l=!0)=>{if(!a)return;const c=l?Ht(a,e):a;t.push(`${r}: ${c%1===0?c:c.toFixed(1)}${o}`)};return s("Mining DPS",i.miningDps),s("Mining range",i.miningRange,"m",!1),s("Magnet range",i.magnetRange,"m"),s("Magnet force",i.magnetForce),s("Damage",i.damage),i.fireRate&&t.push(`Fire rate: ${i.fireRate}/s`),s("Weapon range",i.weaponRange,"m",!1),s("Splash",i.splash,"m",!1),s("Thrust",i.thrust," kN"),s("Torque",i.torque),s("Shield",i.shield),s("Shield regen",i.shieldRegen,"/s"),s("Armor",i.armor),s("Repair",i.repair,"/s"),s("Cargo",i.cargo),s("Energy gen",i.energyGen,"/s"),s("Energy buffer",i.energyCap),s("Scan range",i.scanRange,"m",!1),s("Radar range",i.radarRange,"m",!1),i.rareBonus&&t.push(`Rare chance: +${Math.round(i.rareBonus*100)}%`),i.drones&&t.push(`Drones: ${i.drones}`),t}function Tv(n,e,t){const i=n.state.inventory[e.id]??0,s=n.state.ship.modules.filter(a=>a.defId===e.id).length,r=n.state.credits>=e.price;return b("div",{class:"kpiCard",style:{display:"flex",flexDirection:"column",gap:"8px",borderColor:r?"rgba(0,229,255,0.22)":"rgba(255,255,255,0.06)"}},[b("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",gap:"8px"}},[b("b",{style:{fontSize:"12px",letterSpacing:"0.04em",color:"#fff",fontFamily:"Orbitron"}},[e.name]),b("span",{class:"badge"},[gr[e.category]])]),b("div",{class:"mini",style:{lineHeight:"1.45",minHeight:"34px"}},[e.description]),b("div",{class:"mini",style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"2px 10px"}},Mh(e).map(a=>b("div",{},[a]))),b("div",{class:"mini",style:{display:"flex",gap:"10px",flexWrap:"wrap",opacity:"0.75"}},[b("span",{},[`Mass ${e.mass}t`]),b("span",{},[`HP ${e.durability}`]),b("span",{},[`Energy ${e.energy}/s`]),b("span",{},[`Size ${e.size.join("x")}`])]),b("div",{style:{display:"flex",gap:"8px",alignItems:"center",marginTop:"auto"}},[b("b",{style:{color:r?"#ffb700":"#ff6b8a",fontFamily:"JetBrains Mono"}},[`${Ee(e.price)} CR`]),b("span",{class:"mini"},[`stock ${i} · installed ${s}`]),b("button",{class:r?"btn small":"btn ghost small",style:{marginLeft:"auto"},onclick:t,onmouseenter:()=>ve.uiHover()},["BUY"])])])}function Av(n){let e="all";const t=b("div",{class:"shopGrid"}),i=()=>{if(St(t),e==="installed"){const a=n.state.ship.modules;if(!a.length){t.appendChild(b("div",{class:"mini"},["No modules installed yet."]));return}for(const o of a){const l=Je(o.defId),c=o.level>=l.maxLevel,h=ch(l,o.level),u=Math.round(o.health),d=Math.round(n.state.ship.maxHealth(o));t.appendChild(b("div",{class:"kpiCard",style:{display:"flex",flexDirection:"column",gap:"8px"}},[b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("b",{style:{fontFamily:"Orbitron",fontSize:"12px"}},[l.name]),b("span",{class:"badge"},[`LV ${o.level}/${l.maxLevel}`])]),b("div",{class:"mini"},[`Cell ${o.pos.join(",")} · ${gr[l.category]}`]),b("div",{class:"mini"},[`Integrity ${u}/${d} (${Math.round(u/d*100)}%)`]),b("div",{class:"mini",style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"2px 10px"}},Mh(l,o.level).map(f=>b("div",{},[f]))),b("div",{style:{display:"flex",gap:"8px",marginTop:"auto",alignItems:"center"}},[b("b",{style:{color:"#ffb700",fontFamily:"JetBrains Mono"}},[c?"MAX LEVEL":`${Ee(h)} CR`]),b("button",{class:c?"btn ghost small":"btn small",style:{marginLeft:"auto"},onclick:()=>{c||(n.state.upgradeModule(o.uid)?(ve.purchase(),n.notify(`${l.name} upgraded to level ${o.level}.`,"success"),n.hangar.rebuildShip(),n.save(),n.refresh(),i()):(ve.error(),n.notify("Not enough credits for this upgrade.","error")))}},[c?"MAXED":"UPGRADE"])])]))}return}const r=lh.filter(a=>e==="all"?!0:a.category===e).filter(a=>a.price>0||a.category==="command").sort((a,o)=>a.tier-o.tier||a.price-o.price);for(const a of r)t.appendChild(Tv(n,a,()=>{n.state.buyModule(a.id)?(ve.purchase(),n.notify(`${a.name} purchased - install it in the Ship Builder.`,"success"),n.save(),n.refresh(),i()):(ve.error(),n.notify("Not enough credits.","error"))}))},s=b("div",{class:"builderBar"},wv.map(r=>b("button",{class:"btn ghost small",onclick:a=>{e=r;for(const o of Array.from(s.children))o.classList.add("ghost");a.currentTarget.classList.remove("ghost"),ve.uiClick(),i()}},[r==="all"?"ALL":r==="installed"?"INSTALLED":gr[r].toUpperCase()])));return s.firstChild.classList.remove("ghost"),i(),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[b("div",{class:"panelHead"},[b("h2",{},["EQUIPMENT SHOP"]),b("span",{class:"mini"},["Purchased modules go to your inventory - install them in the Ship Builder."])]),s,t])}const Cv={common:{deep:"#0a1020",mid:"#17233d",light:"#31507a",accent:"#8fa5c8",rim:"#cbd5e1",suit:"#5d6a80",suitDark:"#333c4d",visor:"#9fd0ff"},uncommon:{deep:"#06160f",mid:"#0f2e21",light:"#1d5c3f",accent:"#4ade80",rim:"#a7f3c7",suit:"#4c6a5a",suitDark:"#283b31",visor:"#9bffd0"},rare:{deep:"#050d20",mid:"#0d2347",light:"#17417e",accent:"#60a5fa",rim:"#bfdbfe",suit:"#44587e",suitDark:"#222e45",visor:"#9fd8ff"},epic:{deep:"#140725",mid:"#2a1050",light:"#4c1d95",accent:"#c084fc",rim:"#e9d5ff",suit:"#5b4580",suitDark:"#2e2246",visor:"#e0b9ff"},legendary:{deep:"#241405",mid:"#4a2c08",light:"#92600f",accent:"#fbbf24",rim:"#fde68a",suit:"#7a5a2a",suitDark:"#3d2d16",visor:"#ffdf9b"},mythic:{deep:"#250716",mid:"#511036",light:"#9d1f63",accent:"#f472b6",rim:"#fbcfe8",suit:"#7c3f63",suitDark:"#3f1f33",visor:"#ffc7e6"},secret:{deep:"#02100f",mid:"#06302c",light:"#0a6b61",accent:"#00ffd0",rim:"#99fff0",suit:"#17524c",suitDark:"#0b2b28",visor:"#b7fff4"}};function ho(n){return Cv[n]}function de(n,e){const t=parseInt(n.slice(1,3),16),i=parseInt(n.slice(3,5),16),s=parseInt(n.slice(5,7),16);return`rgba(${t},${i},${s},${e})`}function Rv(n,e,t,i){const s=new Lt(e.artSeed),r=ho(e.rarity),a=n.createLinearGradient(0,0,t*.35,i);a.addColorStop(0,r.deep),a.addColorStop(.55,r.mid),a.addColorStop(1,r.deep),n.fillStyle=a,n.fillRect(0,0,t,i);for(let h=0;h<7;h++){const u=s.range(-.1,1.1)*t,d=s.range(-.1,.9)*i,f=s.range(.18,.6)*t,g=n.createRadialGradient(u,d,0,u,d,f),v=h%2===0?r.light:r.accent;g.addColorStop(0,de(v,s.range(.12,.3))),g.addColorStop(1,de(v,0)),n.fillStyle=g,n.fillRect(0,0,t,i)}for(let h=0;h<160;h++){const u=s.range(0,t),d=s.range(0,i*.85),f=Math.pow(s.next(),3)*2.6+.3;n.fillStyle=`rgba(255,255,255,${s.range(.2,.95)})`,n.beginPath(),n.arc(u,d,f,0,Math.PI*2),n.fill()}if(s.chance(.75)){const h=s.range(.1,.9)*t,u=s.range(.1,.4)*i,d=s.range(.08,.2)*t,f=n.createRadialGradient(h-d*.3,u-d*.3,d*.1,h,u,d);f.addColorStop(0,de(r.rim,.9)),f.addColorStop(.6,de(r.light,.6)),f.addColorStop(1,de(r.deep,.9)),n.fillStyle=f,n.beginPath(),n.arc(h,u,d,0,Math.PI*2),n.fill(),s.chance(.4)&&(n.save(),n.translate(h,u),n.rotate(s.range(-.5,.5)),n.strokeStyle=de(r.accent,.45),n.lineWidth=d*.1,n.beginPath(),n.ellipse(0,0,d*1.7,d*.45,0,0,Math.PI*2),n.stroke(),n.restore())}Pv(n,e,s,t,i,r),Lv(n,e,s,t,i,r);const o=n.createLinearGradient(0,i,t,0);o.addColorStop(0,de(r.accent,0)),o.addColorStop(.6,de(r.accent,.08)),o.addColorStop(1,de(r.rim,.16)),n.fillStyle=o,n.fillRect(0,0,t,i);const l=["common","uncommon","rare","epic","legendary","mythic","secret"].indexOf(e.rarity);if(l>=3){n.save(),n.globalCompositeOperation="screen";for(let h=0;h<4+l;h++){const u=s.range(-t*.2,t);n.strokeStyle=de(r.rim,s.range(.05,.16)),n.lineWidth=s.range(2,16),n.beginPath(),n.moveTo(u,-10),n.lineTo(u+t*.45,i+10),n.stroke()}n.restore()}const c=n.createRadialGradient(t/2,i*.45,Math.min(t,i)*.25,t/2,i*.5,Math.max(t,i)*.75);c.addColorStop(0,"rgba(0,0,0,0)"),c.addColorStop(1,"rgba(0,0,0,0.72)"),n.fillStyle=c,n.fillRect(0,0,t,i)}function Pv(n,e,t,i,s,r){switch(n.save(),e.motif){case"miner":{for(let c=0;c<5;c++){const h=t.range(0,i),u=t.range(s*.25,s*.8),d=t.range(i*.05,i*.2);n.fillStyle=de(r.deep,.92),n.beginPath();for(let f=0;f<Math.PI*2;f+=Math.PI/9){const g=d*t.range(.75,1.25),v=h+Math.cos(f)*g,p=u+Math.sin(f)*g*.85;f===0?n.moveTo(v,p):n.lineTo(v,p)}n.closePath(),n.fill(),n.strokeStyle=de(r.accent,.3),n.lineWidth=2,n.stroke()}const a=t.range(i*.1,i*.3),o=t.range(s*.2,s*.45),l=n.createLinearGradient(i*.75,s*.62,a,o);l.addColorStop(0,de("#ff6b4a",0)),l.addColorStop(1,de("#ff9a3c",.65)),n.strokeStyle=l,n.lineWidth=9,n.beginPath(),n.moveTo(i*.75,s*.62),n.lineTo(a,o),n.stroke();break}case"gunner":{for(let c=0;c<9;c++){const h=t.range(s*.15,s*.6);n.strokeStyle=de("#ffd166",t.range(.15,.5)),n.lineWidth=t.range(1.5,4),n.beginPath(),n.moveTo(t.range(0,i*.4),h),n.lineTo(t.range(i*.6,i),h+t.range(-20,20)),n.stroke()}n.fillStyle=de(r.deep,.95),n.beginPath();const a=i*t.range(.6,.85),o=s*t.range(.2,.35),l=i*.09;n.moveTo(a-l,o),n.lineTo(a,o-l*.5),n.lineTo(a+l,o),n.lineTo(a,o+l*.4),n.closePath(),n.fill(),n.fillStyle=de("#ff3b6b",.85),n.beginPath(),n.arc(a,o,l*.14,0,Math.PI*2),n.fill();break}case"pilot":{n.strokeStyle=de(r.accent,.4),n.lineWidth=3;for(let a=0;a<3;a++)n.beginPath(),n.arc(i*.5,s*.52,i*(.3+a*.1),Math.PI*.1,Math.PI*.9),n.stroke();for(let a=0;a<22;a++){const o=t.range(0,s);n.strokeStyle=de(r.rim,t.range(.08,.28)),n.lineWidth=t.range(1,3),n.beginPath(),n.moveTo(t.range(0,i),o),n.lineTo(t.range(0,i)+t.range(40,160),o),n.stroke()}break}case"engineer":{n.strokeStyle=de(r.light,.75),n.lineWidth=i*.035;for(let a=0;a<4;a++){const o=s*(.25+a*.16);n.beginPath(),n.moveTo(-10,o),n.lineTo(i*t.range(.3,.7),o),n.lineTo(i*t.range(.75,1.1),o+t.range(-s*.1,s*.1)),n.stroke()}for(let a=0;a<16;a++){n.fillStyle=de("#ffd166",t.range(.25,.8));const o=t.range(i*.55,i),l=t.range(s*.35,s*.75);n.fillRect(o,l,t.range(2,7),t.range(1,3))}break}case"scientist":{n.strokeStyle=de(r.accent,.3),n.lineWidth=1.5;for(let c=0;c<=14;c++)n.beginPath(),n.moveTo(c/14*i,0),n.lineTo(c/14*i,s),n.stroke(),n.beginPath(),n.moveTo(0,c/14*s),n.lineTo(i,c/14*s),n.stroke();const a=i*.7,o=s*.3,l=i*.14;n.strokeStyle=de(r.rim,.65),n.lineWidth=3;for(let c=0;c<3;c++)n.save(),n.translate(a,o),n.rotate(c*Math.PI/3),n.beginPath(),n.ellipse(0,0,l,l*.4,0,0,Math.PI*2),n.stroke(),n.restore();n.fillStyle=de(r.accent,.8),n.beginPath(),n.arc(a,o,l*.18,0,Math.PI*2),n.fill();break}case"commander":{for(let a=0;a<6;a++){const o=i*(.15+a*.14)+t.range(-10,10),l=s*(.18+a%3*.08),c=i*t.range(.03,.06);n.fillStyle=de(r.deep,.9),n.beginPath(),n.moveTo(o,l-c),n.lineTo(o+c*.8,l+c*.7),n.lineTo(o-c*.8,l+c*.7),n.closePath(),n.fill(),n.strokeStyle=de(r.accent,.5),n.lineWidth=1.5,n.stroke()}n.fillStyle=de(r.accent,.12),n.fillRect(0,s*.42,i,s*.06);break}case"collector":{const a=i*.3,o=s*.42;for(let l=1;l<=4;l++)n.strokeStyle=de(r.accent,.35/l+.08),n.lineWidth=4,n.beginPath(),n.ellipse(a,o,i*.12*l,i*.09*l,.4,0,Math.PI*2),n.stroke();for(let l=0;l<12;l++){const c=t.range(0,Math.PI*2),h=t.range(i*.12,i*.5),u=a+Math.cos(c)*h,d=o+Math.sin(c)*h*.8;n.fillStyle=de(r.rim,t.range(.4,.95)),n.beginPath();const f=t.range(3,11);n.moveTo(u,d-f),n.lineTo(u+f,d),n.lineTo(u,d+f*.8),n.lineTo(u-f*.9,d),n.closePath(),n.fill()}break}default:{const a=i*.52,o=s*.36,l=n.createRadialGradient(a,o,0,a,o,i*.5);l.addColorStop(0,"rgba(0,0,0,0.95)"),l.addColorStop(.35,de(r.accent,.45)),l.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=l,n.beginPath(),n.arc(a,o,i*.5,0,Math.PI*2),n.fill(),n.strokeStyle=de(r.rim,.5);for(let c=0;c<5;c++)n.lineWidth=t.range(1,3.5),n.beginPath(),n.ellipse(a,o,i*(.16+c*.07),i*(.05+c*.03),t.range(-.5,.5),0,Math.PI*2),n.stroke();break}}n.restore()}function Lv(n,e,t,i,s,r){const a=["dome","angular","tvisor","dual","crest","hooded"],o=a[(e.artSeed+e.number*7)%a.length],l=t.range(0,1),h=Math.min(i*.5,s*.62)*(l<.33?t.range(.38,.44):l<.7?t.range(.3,.36):t.range(.24,.29)),u=i*.5+t.range(-.11,.11)*i,d=s*(l<.33?t.range(.34,.4):t.range(.3,.37)),f=t.range(-.08,.08);n.save();const g=n.createRadialGradient(u,d,h*.3,u,d,h*3.6);g.addColorStop(0,de(r.accent,.38)),g.addColorStop(1,de(r.accent,0)),n.fillStyle=g,n.fillRect(0,0,i,s),n.translate(u,d),n.rotate(f),n.translate(-u,-d);const v=d+h*1.42,p=h*2.3,m=n.createLinearGradient(u-p,v,u+p,s);m.addColorStop(0,r.suitDark),m.addColorStop(.45,r.suit),m.addColorStop(1,r.suitDark),n.fillStyle=m,n.beginPath(),n.moveTo(u-p*1.25,s),n.quadraticCurveTo(u-p*1.1,v+h*.5,u-p*.56,v-h*.08),n.lineTo(u+p*.56,v-h*.08),n.quadraticCurveTo(u+p*1.1,v+h*.5,u+p*1.25,s),n.closePath(),n.fill();const M=(e.artSeed>>3)%3;if(n.save(),n.clip(),M===0)n.fillStyle=de(r.accent,.16),n.fillRect(u-p*.18,v-h,p*.36,s);else if(M===1){n.strokeStyle=de(r.rim,.22),n.lineWidth=h*.1;for(let y=0;y<5;y++)n.beginPath(),n.moveTo(u-p*1.4,v+h*(.4+y*.55)),n.lineTo(u+p*1.4,v+h*(.25+y*.55)),n.stroke()}else n.fillStyle=de(r.deep,.45),n.beginPath(),n.moveTo(u-p,s),n.lineTo(u,v),n.lineTo(u+p,s),n.closePath(),n.fill();n.restore();const _=v+h*.5;n.fillStyle=de(r.deep,.78),n.beginPath(),n.roundRect(u-h*.78,_,h*1.56,h*.86,h*.16),n.fill(),n.strokeStyle=de(r.accent,.85),n.lineWidth=h*.06,n.stroke(),Iv(n,e,u,_+h*.43,h*.3,r);for(let y=0;y<3;y++)n.fillStyle=y===e.number%3?de(r.accent,.95):de(r.rim,.45),n.beginPath(),n.arc(u+h*(.45+y*.16),_+h*.2,h*.055,0,Math.PI*2),n.fill();const x=["common","uncommon","rare","epic","legendary","mythic","secret"].indexOf(e.rarity);for(const y of[-1,1]){n.fillStyle=r.suitDark,n.beginPath(),n.ellipse(u+y*p*.82,v+h*.18,h*.56,h*.34,y*.3,0,Math.PI*2),n.fill(),n.strokeStyle=de(r.rim,.45),n.lineWidth=h*.05,n.stroke(),n.strokeStyle=de(r.accent,.8),n.lineWidth=h*.07;for(let S=0;S<Math.min(3,Math.floor(x/2)+1);S++)n.beginPath(),n.moveTo(u+y*p*1,v+h*(.04+S*.2)),n.lineTo(u+y*p*.72,v+h*(.18+S*.2)),n.stroke()}if(n.fillStyle=r.suitDark,n.beginPath(),n.roundRect(u-h*.52,d+h*.6,h*1.04,h*.6,h*.12),n.fill(),(e.artSeed>>5)%2===0){n.strokeStyle=de(r.suitDark,.95),n.lineWidth=h*.13;for(const y of[-1,1])n.beginPath(),n.moveTo(u+y*h*.5,d+h*.78),n.quadraticCurveTo(u+y*h*1.25,d+h*1.2,u+y*h*.95,v+h*.9),n.stroke()}const P=n.createLinearGradient(u-h,d-h,u+h*.8,d+h);switch(P.addColorStop(0,r.rim),P.addColorStop(.3,r.suit),P.addColorStop(1,r.suitDark),n.fillStyle=P,n.beginPath(),o){case"angular":n.moveTo(u-h*.95,d+h*.75),n.lineTo(u-h*1,d-h*.35),n.lineTo(u-h*.5,d-h*1.12),n.lineTo(u+h*.5,d-h*1.12),n.lineTo(u+h*1,d-h*.35),n.lineTo(u+h*.95,d+h*.75),n.quadraticCurveTo(u,d+h*1.2,u-h*.95,d+h*.75);break;case"crest":n.ellipse(u,d,h*.98,h*1.14,0,0,Math.PI*2);break;case"hooded":n.moveTo(u-h*1.15,d+h*.9),n.quadraticCurveTo(u-h*1.3,d-h*.9,u,d-h*1.25),n.quadraticCurveTo(u+h*1.3,d-h*.9,u+h*1.15,d+h*.9),n.closePath();break;default:n.ellipse(u,d,h*1,h*1.15,0,0,Math.PI*2);break}n.fill(),n.strokeStyle=de(r.rim,.55),n.lineWidth=h*.07,n.stroke(),o==="crest"&&(n.fillStyle=r.suitDark,n.beginPath(),n.moveTo(u-h*.1,d-h*1.08),n.quadraticCurveTo(u,d-h*1.75,u+h*.28,d-h*1),n.closePath(),n.fill(),n.strokeStyle=de(r.accent,.8),n.lineWidth=h*.05,n.stroke()),n.save();const w=n.createLinearGradient(u-h*.8,d-h*.6,u+h*.75,d+h*.4);switch(w.addColorStop(0,de(r.visor,.95)),w.addColorStop(.5,de(r.deep,.96)),w.addColorStop(1,de(r.accent,.75)),n.fillStyle=w,n.beginPath(),o){case"tvisor":{const y=h*.78,S=h*.3;n.moveTo(u-y,d-h*.42),n.lineTo(u+y,d-h*.42),n.lineTo(u+y,d-h*.42+S),n.lineTo(u+h*.17,d-h*.42+S),n.lineTo(u+h*.17,d+h*.6),n.lineTo(u-h*.17,d+h*.6),n.lineTo(u-h*.17,d-h*.42+S),n.lineTo(u-y,d-h*.42+S),n.closePath();break}case"dual":{n.ellipse(u-h*.38,d-h*.05,h*.32,h*.26,-.2,0,Math.PI*2),n.ellipse(u+h*.38,d-h*.05,h*.32,h*.26,.2,0,Math.PI*2);break}case"angular":{n.moveTo(u-h*.78,d-h*.3),n.lineTo(u+h*.78,d-h*.3),n.lineTo(u+h*.6,d+h*.34),n.lineTo(u-h*.6,d+h*.34),n.closePath();break}case"hooded":{n.ellipse(u,d+h*.02,h*.72,h*.44,0,0,Math.PI*2);break}default:{n.ellipse(u,d-h*.05,h*.76,h*.56,0,0,Math.PI*2);break}}n.fill(),n.clip();const A=(e.artSeed>>9)%3;A===0?(n.strokeStyle="rgba(255,255,255,0.28)",n.lineWidth=h*.07,n.beginPath(),n.moveTo(u-h*.8,d+h*.26),n.lineTo(u+h*.1,d-h*.52),n.stroke()):A===1?(n.fillStyle=de(r.rim,.22),n.beginPath(),n.arc(u-h*.3,d+h*.45,h*.55,0,Math.PI*2),n.fill(),n.strokeStyle=de(r.rim,.3),n.lineWidth=h*.035,n.beginPath(),n.moveTo(u-h*.9,d+h*.08),n.lineTo(u+h*.9,d-h*.04),n.stroke()):(n.fillStyle="rgba(255,255,255,0.14)",n.beginPath(),n.moveTo(u-h*.85,d+h*.5),n.lineTo(u-h*.1,d-h*.6),n.lineTo(u+h*.12,d-h*.6),n.lineTo(u-h*.55,d+h*.5),n.closePath(),n.fill()),n.strokeStyle=de(r.rim,.5),n.lineWidth=h*.03;for(let y=0;y<4;y++)n.beginPath(),n.moveTo(u-h*.7,d-h*.3+y*h*.2),n.lineTo(u-h*.45,d-h*.3+y*h*.2),n.stroke();if(e.motif==="void"){n.fillStyle=de("#00ffd0",.95);for(const y of[-1,1])n.beginPath(),n.arc(u+y*h*.26,d-h*.02,h*.075,0,Math.PI*2),n.fill()}else if(o!=="tvisor"){n.fillStyle=de(r.rim,.42);for(const y of[-1,1])n.beginPath(),n.ellipse(u+y*h*.25,d+h*.02,h*.1,h*.05,0,0,Math.PI*2),n.fill()}n.restore();const N=(e.artSeed>>7)%3;if(n.strokeStyle=r.suitDark,n.lineWidth=h*.09,N===0)n.beginPath(),n.moveTo(u+h*.8,d-h*.55),n.lineTo(u+h*1.2,d-h*1.2),n.stroke(),n.fillStyle=de(r.accent,.95),n.beginPath(),n.arc(u+h*1.2,d-h*1.22,h*.09,0,Math.PI*2),n.fill();else if(N===1)n.fillStyle=de(r.rim,.9),n.beginPath(),n.roundRect(u-h*1.12,d-h*.3,h*.2,h*.6,h*.06),n.fill(),n.fillStyle=de(r.accent,.8),n.beginPath(),n.arc(u-h*1.02,d+h*.42,h*.1,0,Math.PI*2),n.fill();else{n.strokeStyle=de(r.rim,.6),n.lineWidth=h*.05;for(let y=0;y<4;y++)n.beginPath(),n.moveTo(u+h*(.55+y*.1),d+h*.55),n.lineTo(u+h*(.75+y*.1),d+h*.78),n.stroke()}Dv(n,e,t,i,s,r,u,v,h,d),n.restore()}function Iv(n,e,t,i,s,r){const a=(e.artSeed+e.number)%5;if(n.save(),n.translate(t,i),n.strokeStyle=de(r.rim,.9),n.fillStyle=de(r.accent,.5),n.lineWidth=Math.max(1.2,s*.18),n.beginPath(),a===0){for(let o=0;o<6;o++){const l=o/6*Math.PI*2-Math.PI/2,c=Math.cos(l)*s,h=Math.sin(l)*s;o===0?n.moveTo(c,h):n.lineTo(c,h)}n.closePath()}else if(a===1)n.moveTo(0,-s),n.lineTo(s,s*.8),n.lineTo(-s,s*.8),n.closePath();else if(a===2)n.arc(0,0,s,0,Math.PI*2);else if(a===3)n.moveTo(-s,-s*.5),n.lineTo(s,-s*.5),n.lineTo(0,s),n.closePath();else{for(let o=0;o<8;o++){const l=o/8*Math.PI*2,c=o%2===0?s:s*.45,h=Math.cos(l)*c,u=Math.sin(l)*c;o===0?n.moveTo(h,u):n.lineTo(h,u)}n.closePath()}n.fill(),n.stroke(),n.restore()}function Dv(n,e,t,i,s,r,a,o,l,c){switch(n.save(),e.motif){case"miner":{n.fillStyle=r.suitDark,n.beginPath(),n.roundRect(a+l*1,o-l*.1,l*.7,l*.44,l*.1),n.fill(),n.strokeStyle=de("#ff8a3c",.9),n.lineWidth=l*.16,n.beginPath(),n.moveTo(a+l*1.7,o+l*.1),n.lineTo(a+l*2.6,o-l*.5),n.stroke(),n.fillStyle=de("#ffd166",.95),n.beginPath(),n.arc(a+l*2.6,o-l*.5,l*.16,0,Math.PI*2),n.fill();break}case"gunner":{n.save(),n.translate(a-l*.1,o+l*.75),n.rotate(-.45),n.fillStyle="#1b1f27",n.fillRect(-l*1.5,-l*.14,l*3,l*.28),n.fillStyle=r.suitDark,n.fillRect(-l*.3,-l*.32,l*.7,l*.62),n.fillStyle=de(r.accent,.9),n.fillRect(l*1,-l*.08,l*.5,l*.16),n.restore();break}case"engineer":{n.strokeStyle=de(r.rim,.65),n.lineWidth=l*.1,n.beginPath(),n.moveTo(a-l*2,s),n.quadraticCurveTo(a-l*.6,o+l*1,a+l*.9,s*.96),n.stroke(),n.save(),n.translate(a+l*1.4,o+l*.75),n.rotate(.5),n.fillStyle="#20252f",n.fillRect(-l*.55,-l*.15,l*1.1,l*.3),n.fillStyle=de("#53ffe0",.95),n.fillRect(l*.4,-l*.09,l*.34,l*.18),n.restore();break}case"scientist":{const h=a+l*1.6,u=o-l*.05;n.strokeStyle=de(r.accent,.9),n.lineWidth=l*.07,n.beginPath(),n.arc(h,u,l*.44,0,Math.PI*2),n.stroke(),n.fillStyle=de(r.accent,.28),n.fill(),n.strokeStyle=de(r.rim,.8),n.lineWidth=l*.045;for(let d=0;d<3;d++)n.save(),n.translate(h,u),n.rotate(d*Math.PI/3),n.beginPath(),n.ellipse(0,0,l*.44,l*.16,0,0,Math.PI*2),n.stroke(),n.restore();break}case"commander":{n.fillStyle=de(r.accent,.2),n.beginPath(),n.moveTo(a-l*1.6,s),n.quadraticCurveTo(a-l*2.4,o+l*.6,a-l*1.1,o-l*.1),n.lineTo(a-l*.6,s),n.closePath(),n.fill(),n.strokeStyle=de(r.rim,.8),n.lineWidth=l*.06,n.stroke();break}case"collector":{n.fillStyle=r.suitDark,n.beginPath(),n.roundRect(a+l*.95,o+l*.1,l*.85,l*.42,l*.12),n.fill(),n.strokeStyle=de(r.accent,.9),n.lineWidth=l*.08;for(let h=1;h<=3;h++)n.beginPath(),n.arc(a+l*1.8,o+l*.3,h*l*.28,-.9,.9),n.stroke();break}case"pilot":{n.strokeStyle=r.suitDark,n.lineWidth=l*.24,n.beginPath(),n.moveTo(a+l*.95,s),n.lineTo(a+l*1.15,o+l*.85),n.stroke(),n.fillStyle=de("#ff3b6b",.92),n.beginPath(),n.arc(a+l*1.15,o+l*.8,l*.16,0,Math.PI*2),n.fill();break}default:{for(let h=0;h<12;h++){const u=t.range(0,Math.PI*2),d=t.range(l*1.3,l*3),f=a+Math.cos(u)*d,g=c+Math.sin(u)*d*.85;n.fillStyle=de("#00ffd0",t.range(.25,.85)),n.beginPath(),n.ellipse(f,g,t.range(2,8),t.range(2,5),u,0,Math.PI*2),n.fill()}break}}n.restore()}function Xa(n,e,t=420,i=588){n.width=t,n.height=i;const s=n.getContext("2d"),r=ho(e.rarity);s.clearRect(0,0,t,i);const a=s.createLinearGradient(0,0,0,i);a.addColorStop(0,"#0b1126"),a.addColorStop(1,"#060a18"),s.fillStyle=a,Ui(s,0,0,t,i,18),s.fill();const o=t*.045,l=i*.56;s.save(),Ui(s,o,o,t-o*2,l,14),s.clip(),s.translate(o,o),Rv(s,e,t-o*2,l),s.restore();const c=s.createLinearGradient(o,l+o,t-o,l+o);c.addColorStop(0,de(r.accent,0)),c.addColorStop(.5,de(r.accent,.9)),c.addColorStop(1,de(r.accent,0)),s.fillStyle=c,s.fillRect(o,l+o,t-o*2,Math.max(1.5,t*.005));const h=o*1.6,u=t-o*3.2;let d=l+o*2.5,f=Math.round(t*.062);const g=e.name.toUpperCase();let v=[];for(;f>t*.034&&(s.font=`700 ${f}px Orbitron, Arial, sans-serif`,v=fc(s,g,u),!(v.length<=2));f-=1);s.fillStyle="#ffffff",s.textAlign="left";for(const A of v.slice(0,2))s.fillText(A,h,d),d+=f*1.1;d+=t*.012,s.font=`600 ${Math.round(t*.036)}px "Exo 2", Arial, sans-serif`,s.fillStyle=r.accent,s.fillText(e.role.toUpperCase(),h,d);const p=e.rarity.toUpperCase();s.font=`700 ${Math.round(t*.028)}px Orbitron, Arial, sans-serif`;const m=s.measureText(p).width+t*.055,M=t*.055;s.fillStyle=de(r.accent,.16),Ui(s,t-o*1.6-m,d-M*.75,m,M,M/2),s.fill(),s.strokeStyle=de(r.accent,.8),s.lineWidth=1.4,s.stroke(),s.fillStyle=r.rim,s.textAlign="center",s.fillText(p,t-o*1.6-m/2,d+M*.02),s.textAlign="left",d+=t*.062,s.font=`400 ${Math.round(t*.033)}px "Exo 2", Arial, sans-serif`,s.fillStyle="rgba(214,228,255,0.78)";const _=fc(s,e.description,u).slice(0,3);for(const A of _)s.fillText(A,h,d),d+=t*.045;const x=i-o*3.4;s.fillStyle=de(r.accent,.1),Ui(s,h-t*.012,x-t*.045,u+t*.024,t*.062,8),s.fill(),s.fillStyle=r.rim,s.font=`700 ${Math.round(t*.032)}px "Exo 2", Arial, sans-serif`;const P=e.bonus2?`${xa(e.bonus)}   ·   ${xa(e.bonus2)}`:xa(e.bonus);s.fillText(P,h,x),s.font=`700 ${Math.round(t*.03)}px Orbitron, Arial, sans-serif`,s.fillStyle=de(r.accent,.95),s.fillText(`No. ${String(e.number).padStart(3,"0")} / 044`,h,i-o*1.4),s.textAlign="right",s.fillStyle="rgba(190,206,236,0.55)",s.fillText("SPACE MINER",t-h,i-o*1.4),s.textAlign="left",s.strokeStyle=r.accent,s.lineWidth=3,Ui(s,1.5,1.5,t-3,i-3,18),s.stroke(),s.strokeStyle=de(r.rim,.3),s.lineWidth=1.2,Ui(s,o*.6,o*.6,t-o*1.2,i-o*1.2,14),s.stroke(),s.strokeStyle=de(r.accent,.9),s.lineWidth=2.5;const w=t*.07;for(const[A,N]of[[1,1],[-1,1],[1,-1],[-1,-1]]){const y=A>0?o*.6:t-o*.6,S=N>0?o*.6:i-o*.6;s.beginPath(),s.moveTo(y+A*w,S),s.lineTo(y,S),s.lineTo(y,S+N*w),s.stroke()}}function xa(n){const t={miningMult:"MINING",damageMult:"DAMAGE",lootMult:"LOOT",speedMult:"SPEED",turnMult:"TURN",energyRegenMult:"ENERGY",magnetRangeMult:"MAGNET",shieldMult:"SHIELD",shieldRegenMult:"SHIELD REG",armorMult:"HULL",cargoMult:"CARGO",creditMult:"CREDITS",crystalMult:"CRYSTALS",rareChance:"RARE FIND",fireRateMult:"FIRE RATE",repairMult:"REPAIR",hazardResist:"HAZARD RES"}[n.key]??n.key.toUpperCase();return n.key==="rareChance"||n.key==="hazardResist"?`+${Math.round(n.value*100)}% ${t}`:n.value>=2?`x${n.value%1===0?n.value:n.value.toFixed(1)} ${t}`:`+${Math.round((n.value-1)*100)}% ${t}`}function fc(n,e,t){const i=e.split(" "),s=[];let r="";for(const a of i){const o=r?`${r} ${a}`:a;n.measureText(o).width>t&&r?(s.push(r),r=a):r=o}return r&&s.push(r),s}function Ui(n,e,t,i,s,r){n.beginPath(),n.moveTo(e+r,t),n.lineTo(e+i-r,t),n.quadraticCurveTo(e+i,t,e+i,t+r),n.lineTo(e+i,t+s-r),n.quadraticCurveTo(e+i,t+s,e+i-r,t+s),n.lineTo(e+r,t+s),n.quadraticCurveTo(e,t+s,e,t+s-r),n.lineTo(e,t+r),n.quadraticCurveTo(e,t,e+r,t),n.closePath()}function Uv(n,e,t,i,s,r){const a=new Lt(i),o=ho(t),l=n.createLinearGradient(0,0,s,r);l.addColorStop(0,o.deep),l.addColorStop(1,o.mid),n.fillStyle=l,n.fillRect(0,0,s,r);for(let u=0;u<60;u++)n.fillStyle=`rgba(255,255,255,${a.range(.1,.7)})`,n.beginPath(),n.arc(a.range(0,s),a.range(0,r),a.range(.4,1.6),0,Math.PI*2),n.fill();n.save(),n.translate(s/2,r/2);const c=Math.min(s,r)*.3;switch(n.strokeStyle=o.accent,n.fillStyle=de(o.accent,.22),n.lineWidth=Math.max(2,c*.09),e){case"mining":{n.beginPath();for(let u=0;u<Math.PI*2;u+=Math.PI/7){const d=c*(.7+Math.sin(u*3+i)*.16),f=Math.cos(u)*d,g=Math.sin(u)*d;u===0?n.moveTo(f,g):n.lineTo(f,g)}n.closePath(),n.fill(),n.stroke(),n.strokeStyle="#ff8a3c",n.beginPath(),n.moveTo(-c*1.4,c*1.1),n.lineTo(-c*.2,c*.15),n.stroke();break}case"combat":{n.beginPath(),n.moveTo(0,-c),n.lineTo(c*.75,c*.7),n.lineTo(0,c*.35),n.lineTo(-c*.75,c*.7),n.closePath(),n.fill(),n.stroke();break}case"economy":{n.beginPath(),n.arc(0,0,c*.8,0,Math.PI*2),n.fill(),n.stroke(),n.fillStyle=o.rim,n.font=`700 ${Math.round(c*.9)}px Orbitron, Arial`,n.textAlign="center",n.textBaseline="middle",n.fillText("C",0,c*.04);break}case"exploration":{n.beginPath(),n.arc(0,0,c*.85,0,Math.PI*2),n.stroke(),n.beginPath(),n.moveTo(0,-c*.85),n.lineTo(c*.22,0),n.lineTo(0,c*.85),n.lineTo(-c*.22,0),n.closePath(),n.fill();break}case"engineering":{n.beginPath();for(let u=0;u<8;u++){const d=u/8*Math.PI*2,f=c*.85,g=c*.6;n.lineTo(Math.cos(d)*f,Math.sin(d)*f),n.lineTo(Math.cos(d+.3)*g,Math.sin(d+.3)*g)}n.closePath(),n.fill(),n.stroke();break}default:{for(let u=1;u<=3;u++)n.beginPath(),n.ellipse(0,0,c*.3*u,c*.22*u,.5,0,Math.PI*2),n.stroke();n.beginPath(),n.arc(0,0,c*.2,0,Math.PI*2),n.fill();break}}n.restore();const h=n.createRadialGradient(s/2,r/2,Math.min(s,r)*.2,s/2,r/2,Math.max(s,r)*.7);h.addColorStop(0,"rgba(0,0,0,0)"),h.addColorStop(1,"rgba(0,0,0,0.6)"),n.fillStyle=h,n.fillRect(0,0,s,r)}const pc=new Map;function Nv(n,e=300){const t=pc.get(`${n.id}:${e}`);if(t){const s=new Image;return s.src=t,s.style.width="100%",s.style.display="block",s}const i=document.createElement("canvas");Xa(i,n,e,Math.round(e*1.4)),i.style.width="100%",i.style.display="block";try{pc.set(`${n.id}:${e}`,i.toDataURL("image/png"))}catch{}return i}function Ov(n,e,t,i,s){return b("div",{class:"card3d",style:{width:"100%",height:"auto",borderColor:i?"rgba(0,255,157,0.8)":"rgba(255,255,255,0.12)",filter:t?"none":"grayscale(1) brightness(0.45)",cursor:t?"pointer":"default",position:"relative"},onclick:()=>{t&&(ve.uiClick(),s())},onmouseenter:()=>t&&ve.uiHover()},[Nv(e,300),i?b("div",{style:{position:"absolute",top:"8px",right:"8px",padding:"4px 8px",borderRadius:"999px",background:"rgba(0,255,157,0.85)",color:"#00231a",fontSize:"9px",fontWeight:"700",fontFamily:"Orbitron",letterSpacing:"0.1em"}},["ACTIVE"]):null,t?null:b("div",{style:{position:"absolute",inset:"0",display:"grid",placeItems:"center",background:"rgba(2,5,15,0.55)",fontFamily:"Orbitron",fontSize:"10px",letterSpacing:"0.14em"}},["LOCKED"])])}function Fv(n){const{state:e}=n;let t="",i="all",s="number",r=!1;const a=b("div",{class:"cardGrid"}),o=b("div",{class:"panelHead"}),l=()=>{St(o);const h=e.crewSlots;o.append(b("h2",{},["CREW COLLECTION"]),b("span",{class:"mini"},[`${e.crew.size}/${ui.length} cards collected · ${e.equippedCrew.length}/${h} crew slots in use`]),b("div",{style:{marginLeft:"auto",display:"flex",gap:"8px",alignItems:"center"}},[b("input",{placeholder:"Search name or role…",value:t,style:{padding:"8px 12px",borderRadius:"10px",border:"1px solid rgba(255,255,255,0.14)",background:"rgba(255,255,255,0.05)",color:"#e6eaff",fontSize:"12px",width:"180px"},oninput:u=>{t=u.target.value.toLowerCase(),c()}}),b("select",{style:{padding:"8px",borderRadius:"10px",background:"#0c1430",color:"#e6eaff",border:"1px solid rgba(255,255,255,0.14)",fontSize:"11px"},onchange:u=>{i=u.target.value,c()}},[b("option",{value:"all"},["ALL RARITIES"]),...hn.map(u=>b("option",{value:u},[Lr[u]]))]),b("select",{style:{padding:"8px",borderRadius:"10px",background:"#0c1430",color:"#e6eaff",border:"1px solid rgba(255,255,255,0.14)",fontSize:"11px"},onchange:u=>{s=u.target.value,c()}},[b("option",{value:"number"},["SORT: NUMBER"]),b("option",{value:"rarity"},["SORT: RARITY"]),b("option",{value:"name"},["SORT: NAME"])]),b("button",{class:"btn ghost small",onclick:u=>{r=!r,u.currentTarget.textContent=r?"OWNED ONLY":"SHOW ALL",c()}},["SHOW ALL"])]))},c=()=>{St(a);const h=e.crewSlots,u=b("div",{style:{gridColumn:"1 / -1",display:"flex",gap:"10px",flexWrap:"wrap",padding:"12px",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:"14px"}},[b("div",{style:{width:"100%",fontFamily:"Orbitron",fontSize:"11px",letterSpacing:"0.1em",marginBottom:"4px"}},[`ACTIVE CREW  ·  ${e.equippedCrew.length}/${h} SLOTS`])]);h===0&&u.appendChild(b("div",{class:"mini"},["No crew slots unlocked yet. Purchase 10 ship expansion cells in the Ship Builder to unlock your first slot."]));for(let v=0;v<h;v++){const p=e.equippedCrew[v],m=p?ui.find(M=>M.id===p):void 0;u.appendChild(b("div",{style:{width:"150px",padding:"10px",borderRadius:"12px",border:`1px solid ${m?"rgba(0,255,157,0.45)":"rgba(255,255,255,0.12)"}`,background:m?"rgba(0,255,157,0.08)":"rgba(255,255,255,0.03)"}},m?[b("div",{style:{fontSize:"11px",fontWeight:"700"}},[m.name]),b("div",{class:"mini"},[m.role]),b("div",{class:"mini",style:{color:"#00ff9d"}},[ds(m.bonus.key,m.bonus.value)]),m.bonus2?b("div",{class:"mini",style:{color:"#00ff9d"}},[ds(m.bonus2.key,m.bonus2.value)]):null,b("button",{class:"btn ghost small",style:{marginTop:"6px"},onclick:()=>{e.unequipCrew(m.id),ve.uiBack(),n.save(),n.refresh(),l(),c()}},["UNEQUIP"])]:[b("div",{class:"mini",style:{opacity:"0.6"}},[`SLOT ${v+1}`]),b("div",{class:"mini"},["Empty"])]))}a.appendChild(u);const d=e.bonuses(),f=Object.entries(d);f.length&&a.appendChild(b("div",{style:{gridColumn:"1 / -1",padding:"10px 12px",borderRadius:"12px",background:"rgba(0,229,255,0.07)",border:"1px solid rgba(0,229,255,0.2)",display:"flex",gap:"12px",flexWrap:"wrap"}},[b("b",{style:{fontFamily:"Orbitron",fontSize:"10px",letterSpacing:"0.1em"}},["TOTAL ACTIVE BONUSES"]),...f.map(([v,p])=>b("span",{class:"mini",style:{color:"#9ff"}},[ds(v,p)]))]));let g=[...ui];i!=="all"&&(g=g.filter(v=>v.rarity===i)),r&&(g=g.filter(v=>e.crew.has(v.id))),t&&(g=g.filter(v=>`${v.name} ${v.role} ${v.description}`.toLowerCase().includes(t))),g.sort((v,p)=>s==="rarity"?hn.indexOf(p.rarity)-hn.indexOf(v.rarity)||v.number-p.number:s==="name"?v.name.localeCompare(p.name):v.number-p.number);for(const v of g){const p=e.crew.has(v.id),m=e.equippedCrew.includes(v.id);a.appendChild(Ov(n,v,p,m,()=>{if(m)e.unequipCrew(v.id);else if(e.equippedCrew.length>=e.crewSlots){ve.error(),n.notify(`All ${e.crewSlots} crew slots are full. Unequip someone or expand the ship.`,"error");return}else e.equipCrew(v.id);n.save(),n.refresh(),l(),c()}))}g.length||a.appendChild(b("div",{class:"mini"},["No cards match the current filter."]))};return l(),c(),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[o,b("div",{class:"mini",style:{padding:"0 16px 8px"}},[`Collection value: ${Ee(e.crew.size*100)} prestige · duplicates convert to crystals automatically.`]),a])}const mc=3,Sh=[{id:"standard",name:"Standard Crew Pack",description:"3 crew cards. Baseline odds across all seven rarities.",cost:40,color:4830975},{id:"veteran",name:"Veteran Pack",description:"3 cards. Rare or better guaranteed, epic odds tripled.",cost:130,floor:"rare",weightBoost:{epic:3,legendary:2.2},color:12616956},{id:"legend",name:"Legend Pack",description:"3 cards. Epic or better guaranteed, mythic odds x6.",cost:420,floor:"epic",weightBoost:{legendary:3.5,mythic:6,secret:3},color:16498468}];new Map(Sh.map(n=>[n.id,n]));function kv(n,e,t){const i=e.floor?hn.indexOf(e.floor):0,s=t?Math.max(i,hn.indexOf("rare")):i,r=hn.slice(s),a=r.map(o=>{var l;return fh[o]*(((l=e.weightBoost)==null?void 0:l[o])??1)});return n.weighted(r,a)}function Bv(n){const e=n.floor?hn.indexOf(n.floor):0,t=hn.slice(e),i=t.map(r=>{var a;return fh[r]*(((a=n.weightBoost)==null?void 0:a[r])??1)}),s=i.reduce((r,a)=>r+a,0);return t.map((r,a)=>({rarity:r,chance:i[a]/s}))}function zv(n,e,t,i){const s=[],r=[],a=[];let o=0,l=!1;for(let c=0;c<mc;c++){const h=i.pity>=7&&c===mc-1&&!l,u=kv(e,n,h);hn.indexOf(u)>=hn.indexOf("rare")&&(l=!0);const d=Yg[u],f=e.pick(d);s.push(f),t.has(f.id)||r.includes(f.id)?(a.push(f.id),o+=ph[f.rarity]):r.push(f.id)}return i.pity=l?0:i.pity+1,{cards:s,newCards:r,duplicates:a,crystalsRefunded:o}}const ba=n=>hn.indexOf(n);function Ea(n,e){const t=document.createElement("canvas");t.width=900,t.height=520,Object.assign(t.style,{position:"absolute",inset:"0",width:"100%",height:"100%",pointerEvents:"none"});const i=t.getContext("2d"),s=Array.from({length:Math.floor(70*e)},()=>({x:t.width/2,y:t.height/2,vx:(Math.random()-.5)*18,vy:(Math.random()-.5)*14,life:1,size:Math.random()*5+1.5})),r=`#${n.toString(16).padStart(6,"0")}`,a=()=>{i.clearRect(0,0,t.width,t.height);let o=!1;for(const l of s)l.life-=.016,!(l.life<=0)&&(o=!0,l.x+=l.vx,l.y+=l.vy,l.vy+=.12,l.vx*=.985,l.vy*=.985,i.globalAlpha=Math.max(0,l.life),i.fillStyle=r,i.beginPath(),i.arc(l.x,l.y,l.size*l.life,0,Math.PI*2),i.fill());i.globalAlpha=1,o&&requestAnimationFrame(a)};return requestAnimationFrame(a),t}function Gv(n,e,t,i,s){const r=n.state.settings.reducedMotion||n.state.settings.skipPackAnimation,a=t.reduce((x,P)=>ba(P.rarity)>ba(x.rarity)?P:x,t[0]),o=Mn[a.rarity],l=b("div",{class:"cardPackStage",style:{height:"520px"}}),c=b("div",{style:{display:"flex",gap:"18px",alignItems:"center",justifyContent:"center",position:"relative",zIndex:"2"}}),h=b("div",{class:"pack"}),u=b("button",{class:"btn ghost small",style:{position:"absolute",right:"14px",top:"14px",zIndex:"5"},onclick:()=>m(!0)},["SKIP"]),d=b("div",{style:{padding:"0 18px 18px",display:"none"}}),f=b("div",{class:"modal"},[b("div",{class:"panelHead"},[b("h2",{},[e.name.toUpperCase()]),b("span",{class:"mini"},["3 crew cards · duplicates convert to crystals"])]),l,d]);l.append(h,c,u);const g=n.shell.modal(f,{dismissable:!1});let v=!1;const p=[],m=(x=!1)=>{if(!v){v=!0;for(const P of p)window.clearTimeout(P);h.remove(),St(c);for(const P of t)c.appendChild(_(P,!0));d.style.display="block",St(d),d.append(b("div",{style:{display:"flex",gap:"14px",flexWrap:"wrap",marginBottom:"12px"}},t.map((P,w)=>b("div",{style:{flex:"1 1 220px",padding:"10px 12px",borderRadius:"12px",border:`1px solid ${M(Mn[P.rarity],.5)}`,background:M(Mn[P.rarity],.08)}},[b("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"}},[b("b",{style:{fontSize:"12px"}},[P.name]),b("span",{class:`badge ${P.rarity}`},[Lr[P.rarity]])]),b("div",{class:"mini"},[P.role]),b("div",{class:"mini",style:{color:"#9ff"}},[ds(P.bonus.key,P.bonus.value)]),P.bonus2?b("div",{class:"mini",style:{color:"#9ff"}},[ds(P.bonus2.key,P.bonus2.value)]):null,b("div",{class:"mini",style:{marginTop:"4px",color:i.includes(P.id)?"#00ff9d":"#ffb700"}},[i.includes(P.id)?"NEW CARD":`DUPLICATE  ·  +${ph[P.rarity]} crystals`]),b("span",{class:"mini",style:{display:"none"}},[String(w)])]))),...s>0?[b("div",{class:"mini",style:{marginBottom:"10px",color:"#ffb700"}},[`Duplicates converted into ${s} crystals.`])]:[],b("div",{style:{display:"flex",gap:"10px",justifyContent:"flex-end"}},[b("button",{class:"btn",onclick:()=>{ve.uiClick(),g(),n.refresh()}},["COLLECT"])])),x||ve.achievement()}},M=(x,P)=>{const w=x>>16&255,A=x>>8&255,N=x&255;return`rgba(${w},${A},${N},${P})`},_=(x,P)=>{const w=b("div",{class:"card3d",style:{width:"182px",height:"256px",flex:"0 0 auto",boxShadow:`0 10px 40px ${M(Mn[x.rarity],.45)}`,border:`1px solid ${M(Mn[x.rarity],.8)}`}});if(P){const A=document.createElement("canvas");Xa(A,x,260,364),A.style.width="100%",A.style.height="100%",w.appendChild(A)}else w.appendChild(b("div",{style:{width:"100%",height:"100%",display:"grid",placeItems:"center",background:"linear-gradient(145deg,#141f45,#070c20)",fontFamily:"Orbitron",fontSize:"11px",letterSpacing:"0.2em",color:"rgba(200,220,255,0.7)"}},["SPACE MINER"]));return w};if(r){m(!0);return}ve.uiClick(),h.animate([{transform:"scale(0.6) rotateY(-30deg)",opacity:0},{transform:"scale(1) rotateY(0deg)",opacity:1}],{duration:520,easing:"cubic-bezier(.2,.9,.2,1)"}),p.push(window.setTimeout(()=>{l.appendChild(Ea(8086015,.7)),h.animate([{transform:"translateY(0) rotate(0deg)"},{transform:"translateY(-6px) rotate(-3deg)"},{transform:"translateY(4px) rotate(3deg)"},{transform:"translateY(-8px) rotate(-2deg)"},{transform:"translateY(0) rotate(0deg)"}],{duration:900,iterations:1}),ve.tone(220,.9,"sawtooth",.12,880)},600)),p.push(window.setTimeout(()=>{h.animate([{transform:"scale(1)",opacity:1},{transform:"scale(1.6)",opacity:0}],{duration:320,easing:"ease-in"}),l.appendChild(Ea(o,1.6)),ve.explosion(.5),window.setTimeout(()=>h.remove(),320)},1550)),t.forEach((x,P)=>{p.push(window.setTimeout(()=>{const w=_(x,!1);c.appendChild(w),w.animate([{transform:"translateY(90px) rotateY(0deg) scale(0.7)",opacity:0},{transform:"translateY(0) rotateY(360deg) scale(1)",opacity:1}],{duration:760,easing:"cubic-bezier(.2,.8,.2,1)"}),ve.tone(520+P*90,.18,"triangle",.14),window.setTimeout(()=>{w.animate([{transform:"rotateY(0deg)"},{transform:"rotateY(90deg)"}],{duration:170,easing:"ease-in"}).onfinish=()=>{St(w);const A=document.createElement("canvas");Xa(A,x,260,364),A.style.width="100%",A.style.height="100%",w.appendChild(A),w.animate([{transform:"rotateY(-90deg)"},{transform:"rotateY(0deg)"}],{duration:190,easing:"ease-out"});const N=ba(x.rarity);if(ve.cardReveal(N),N>=2){const y=b("div",{style:{position:"absolute",inset:"-12px",borderRadius:"18px",pointerEvents:"none",boxShadow:`0 0 ${18+N*10}px ${M(Mn[x.rarity],.85)}`}});w.appendChild(y)}N>=3&&l.appendChild(Ea(Mn[x.rarity],.5+N*.25)),N>=5&&(l.style.background=`radial-gradient(600px 400px at 50% 40%, ${M(Mn[x.rarity],.45)}, transparent 70%), #05081a`,l.animate([{filter:"brightness(1)"},{filter:"brightness(1.5)"},{filter:"brightness(1)"}],{duration:1200,iterations:2}))}},700)},1900+P*820))}),p.push(window.setTimeout(()=>m(!1),1900+t.length*820+1400))}function Hv(n){const{state:e}=n,t=b("div",{class:"shopGrid"}),i=()=>{St(t);for(const s of Sh){const r=Bv(s);t.appendChild(b("div",{class:"kpiCard",style:{display:"flex",flexDirection:"column",gap:"10px"}},[b("div",{style:{height:"120px",borderRadius:"12px",position:"relative",overflow:"hidden",background:`linear-gradient(145deg, rgba(${s.color>>16&255},${s.color>>8&255},${s.color&255},0.35), rgba(8,12,30,0.95))`,display:"grid",placeItems:"center"}},[b("div",{style:{width:"72px",height:"100px",borderRadius:"8px",background:"linear-gradient(180deg,#1a2550,#0c1230)",border:"1px solid rgba(255,255,255,0.25)",display:"grid",placeItems:"center",fontFamily:"Orbitron",fontSize:"8px",letterSpacing:"0.1em",textAlign:"center",boxShadow:"0 10px 24px rgba(0,0,0,0.45)"}},["SPACE",b("br",{}),"MINER"])]),b("b",{style:{fontFamily:"Orbitron",fontSize:"12px"}},[s.name]),b("div",{class:"mini",style:{minHeight:"32px"}},[s.description]),b("div",{class:"mini",style:{display:"grid",gap:"2px"}},r.map(a=>b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{style:{color:`#${Mn[a.rarity].toString(16).padStart(6,"0")}`}},[Lr[a.rarity]]),b("span",{},[`${(a.chance*100).toFixed(a.chance<.01?3:1)}%`])]))),b("div",{style:{display:"flex",alignItems:"center",gap:"10px",marginTop:"auto"}},[b("b",{style:{color:e.crystals>=s.cost?"#00e5ff":"#ff6b8a",fontFamily:"JetBrains Mono"}},[`${s.cost} CRYSTALS`]),b("button",{class:"btn",style:{marginLeft:"auto"},onclick:async()=>{if(e.crystals<s.cost){ve.error(),n.notify("Not enough crystals - complete achievements to earn more.","error");return}if(!await n.shell.confirm(`Open ${s.name}?`,`This will spend ${s.cost} crystals and award exactly 3 crew cards. You currently hold ${Ee(e.crystals)} crystals.`,"OPEN PACK"))return;if(!e.spendCrystals(s.cost)){ve.error();return}const o={pity:e.packPity},l=zv(s,Vg,e.crew,o);e.packPity=o.pity;for(const c of l.newCards)e.grantCard(c);l.crystalsRefunded>0&&e.addCrystals(l.crystalsRefunded),e.stats.packsOpened+=1,e.trackStat("packsOpened",1),e.achievements.setStat("cardsOwned",e.crew.size),n.save(),n.refresh(),i(),Gv(n,s,l.cards,l.newCards,l.crystalsRefunded)}},["OPEN PACK"])])]))}};return i(),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[b("div",{class:"panelHead"},[b("h2",{},["CARD PACK STATION"]),b("span",{class:"mini"},[`${Ee(e.crystals)} crystals available · every pack contains exactly 3 cards`])]),t])}const gc=new Map;function Vv(n){const e=`${n.templateId}:${n.rarity}`,t=gc.get(e);if(t){const r=new Image;return r.src=t,Object.assign(r.style,{width:"78px",height:"78px",borderRadius:"10px",display:"block"}),r}const i=document.createElement("canvas");i.width=256,i.height=256;const s=i.getContext("2d");Uv(s,n.motif,n.rarity,n.artSeed,256,256),Object.assign(i.style,{width:"78px",height:"78px",borderRadius:"10px",display:"block"});try{gc.set(e,i.toDataURL("image/png"))}catch{}return i}function Wv(n){const{state:e}=n,t=b("div",{style:{overflow:"auto",flex:"1"}}),i=b("div",{class:"panelHead"});let s=0;const r=()=>{const o=Date.now(),l=e.achievements.refresh(o,e.tier),c=l.filter(u=>!u.claimed&&e.achievements.isComplete(u)).length;St(i),i.append(b("h2",{},["ACHIEVEMENT ALBUM"]),b("span",{class:"mini"},[`${l.length} active · ${e.achievements.state.completedCount} completed all-time · ${Ee(e.achievements.state.totalCrystals)} crystals earned`]),b("button",{class:c?"btn":"btn ghost",style:{marginLeft:"auto"},onclick:()=>{const u=e.achievements.claimAllReady(Date.now());u>0?(e.addCrystals(u),ve.achievement(),n.notify(`Claimed ${u} crystals from completed achievements.`,"success"),n.save(),n.refresh(),r()):(ve.error(),n.notify("No completed achievements ready to claim.","error"))}},[c?`CLAIM ALL (${c})`:"NOTHING TO CLAIM"])),St(t);const h=["minute","hourly","daily","weekly"];for(const u of h){const d=l.filter(v=>v.period===u),f=e.achievements.msUntilReset(u,o);t.appendChild(b("div",{class:"panelHead",style:{borderTop:"1px solid rgba(255,255,255,0.06)"}},[b("h2",{style:{fontSize:"12px"}},[`${Gg[u]} OBJECTIVES`]),b("span",{class:"mini"},[`${d.length} active · resets in ${qg(f)}`])]));const g=b("div",{class:"achGrid"});for(const v of d){const p=e.achievements.state.progress[v.key]??0,m=p>=v.target,M=Mn[v.rarity];g.appendChild(b("div",{class:"achCard",style:{borderColor:v.claimed?"rgba(255,255,255,0.08)":m?"rgba(0,255,157,0.5)":`rgba(${M>>16&255},${M>>8&255},${M&255},0.3)`,opacity:v.claimed?"0.55":"1"}},[Vv(v),b("div",{style:{flex:"1",display:"flex",flexDirection:"column",gap:"4px"}},[b("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",gap:"6px"}},[b("b",{style:{fontSize:"12px"}},[v.name]),b("span",{class:`badge ${v.rarity}`},[Lr[v.rarity]])]),b("div",{class:"mini"},[v.description]),b("div",{class:"progress"},[b("i",{style:{width:`${Math.min(100,p/v.target*100)}%`,background:m?"linear-gradient(90deg,#00ff9d,#00e5ff)":void 0}})]),b("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"}},[b("span",{class:"mini"},[`${Ee(Math.min(p,v.target))} / ${Ee(v.target)}`]),b("span",{class:"mini",style:{color:"#00e5ff"}},[`+${v.crystals} crystals`]),v.claimed?b("span",{class:"mini",style:{color:"#00ff9d"}},["CLAIMED"]):b("button",{class:m?"btn small":"btn ghost small",onclick:()=>{const _=e.achievements.claim(v.key,Date.now());_>0?(e.addCrystals(_),ve.achievement(),n.notify(`${v.name} complete · +${_} crystals`,"success"),n.save(),n.refresh(),r()):ve.error()}},[m?"CLAIM":"IN PROGRESS"])])])]))}t.appendChild(g)}};r(),s=window.setInterval(r,1e3);const a=b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[i,t]);return a.dispose=()=>window.clearInterval(s),a}function Xv(n){const{state:e}=n,t=b("div",{style:{overflow:"auto",padding:"16px",display:"flex",flexDirection:"column",gap:"16px"}}),i=()=>{St(t);const s=e.upgradeSlots,r=b("div",{style:{display:"flex",gap:"12px",flexWrap:"wrap"}});for(let o=0;o<yr;o++){const l=o<s,c=e.activeUpgrades[o],h=c?Ga.find(u=>u.id===c):null;r.appendChild(b("div",{style:{width:"190px",minHeight:"128px",borderRadius:"14px",padding:"12px",border:`1px solid ${l?h?"rgba(0,255,157,0.45)":"rgba(0,229,255,0.3)":"rgba(255,255,255,0.08)"}`,background:l?h?"rgba(0,255,157,0.07)":"rgba(0,229,255,0.05)":"rgba(255,255,255,0.02)",display:"flex",flexDirection:"column",gap:"6px"}},l?[b("div",{class:"mini"},[`SLOT ${o+1}`]),h?b("b",{style:{fontSize:"12px"}},[h.name]):b("b",{style:{fontSize:"12px",opacity:"0.6"}},["Empty"]),h?b("div",{class:"mini"},[h.description]):b("div",{class:"mini"},["Fit an upgrade from the list below."]),h?b("button",{class:"btn ghost small",style:{marginTop:"auto"},onclick:()=>{e.setActiveUpgrade(o,null),ve.uiBack(),n.save(),n.refresh(),i()}},["REMOVE"]):null]:[b("div",{class:"mini"},[`SLOT ${o+1}`]),b("b",{style:{fontSize:"12px",opacity:"0.6"}},["LOCKED"]),b("div",{class:"mini"},[o===3?`Permanent unlock: ${Ee(Zl)} CR`:`Rare reward · ${(oo*100).toFixed(0)}% chance per completed expedition`]),o===3?b("button",{class:"btn small",style:{marginTop:"auto"},onclick:()=>{if(!e.fourthSlotPurchased){if(!e.spendCredits(Zl)){ve.error(),n.notify("Not enough credits for the fourth upgrade slot.","error");return}e.fourthSlotPurchased=!0,ve.purchase(),n.notify("Fourth active upgrade slot unlocked permanently.","success"),n.save(),n.refresh(),i()}}},["PURCHASE"]):null]))}t.append(b("div",{class:"mini"},[`Active upgrade slots: ${s}/${yr}. Upgrades apply to every expedition until removed.`]),r,b("h2",{style:{fontFamily:"Orbitron",fontSize:"12px",letterSpacing:"0.1em",marginTop:"8px"}},["UPGRADE CATALOGUE"]));const a=b("div",{class:"shopGrid",style:{padding:"0"}});for(const o of Ga){const l=!!e.ownedUpgrades[o.id],c=e.activeUpgrades.indexOf(o.id);a.appendChild(b("div",{class:"kpiCard",style:{display:"flex",flexDirection:"column",gap:"8px"}},[b("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"}},[b("b",{style:{fontSize:"12px",fontFamily:"Orbitron"}},[o.name]),b("span",{class:"badge"},[`TIER ${o.tier}`])]),b("div",{class:"mini",style:{minHeight:"34px"}},[o.description]),b("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginTop:"auto"}},[b("b",{style:{color:l?"#00ff9d":"#ffb700",fontFamily:"JetBrains Mono"}},[l?"OWNED":`${Ee(o.price)} CR`]),b("button",{class:"btn small",style:{marginLeft:"auto"},onclick:()=>{if(l)if(c>=0)e.setActiveUpgrade(c,null),ve.uiBack();else{const h=e.activeUpgrades.findIndex((u,d)=>d<e.upgradeSlots&&!u);if(h<0){ve.error(),n.notify("All active upgrade slots are full.","error");return}e.setActiveUpgrade(h,o.id),ve.uiClick()}else{if(!e.spendCredits(o.price)){ve.error(),n.notify("Not enough credits.","error");return}e.ownedUpgrades[o.id]=1,ve.purchase(),n.notify(`${o.name} purchased.`,"success")}n.save(),n.refresh(),i()}},[l?c>=0?"UNEQUIP":"EQUIP":"BUY"])])]))}t.appendChild(a)};return i(),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[b("div",{class:"panelHead"},[b("h2",{},["ACTIVE UPGRADES"]),b("span",{class:"mini"},["Run modifiers kept separate from the physical ship modules."])]),t])}function $v(n,e){const t=document.createElement("canvas");t.width=480,t.height=220;const i=t.getContext("2d"),[s,r]=e,a=(l,c=1)=>`rgba(${l>>16&255},${l>>8&255},${l&255},${c})`,o=i.createLinearGradient(0,0,t.width,t.height);o.addColorStop(0,a(r,.95)),o.addColorStop(1,"#03060f"),i.fillStyle=o,i.fillRect(0,0,t.width,t.height);for(let l=0;l<5;l++){const c=(l*97+n*53)%t.width,h=(l*61+n*37)%t.height,u=40+(l*29+n*11)%90,d=i.createRadialGradient(c,h,0,c,h,u);d.addColorStop(0,a(s,.4)),d.addColorStop(1,a(s,0)),i.fillStyle=d,i.fillRect(0,0,t.width,t.height)}for(let l=0;l<220;l++)i.fillStyle=`rgba(255,255,255,${Math.random()*.8})`,i.beginPath(),i.arc(Math.random()*t.width,Math.random()*t.height,Math.random()*1.4,0,Math.PI*2),i.fill();for(let l=0;l<6;l++){const c=Math.random()*t.width,h=Math.random()*t.height,u=10+Math.random()*28;i.fillStyle="rgba(4,7,16,0.85)",i.beginPath();for(let d=0;d<10;d++){const f=d/10*Math.PI*2,g=u*(.75+Math.random()*.4),v=c+Math.cos(f)*g,p=h+Math.sin(f)*g;d===0?i.moveTo(v,p):i.lineTo(v,p)}i.closePath(),i.fill(),i.strokeStyle=a(s,.5),i.lineWidth=1.4,i.stroke()}return t.style.width="100%",t.style.borderRadius="12px",t.style.display="block",t}function qv(n){const{state:e}=n,t=b("div",{class:"shopGrid"}),i=()=>{St(t);for(const s of _r){const r=e.unlockedSectors.has(s.id),a=e.credits>=s.unlockCost,o=Object.entries(s.resourceTable).sort((l,c)=>c[1]-l[1]).slice(0,4).map(([l,c])=>`${yt[l].name} ${Math.round(c)}%`);t.appendChild(b("div",{class:"kpiCard",style:{display:"flex",flexDirection:"column",gap:"10px",opacity:r?"1":"0.86"}},[$v(s.index,s.nebula),b("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"}},[b("b",{style:{fontFamily:"Orbitron",fontSize:"13px"}},[s.name]),b("span",{class:"badge"},[`DANGER ${s.danger}/5`])]),b("div",{class:"mini"},[s.description]),b("div",{class:"mini"},[`Resources: ${o.join(" · ")}`]),b("div",{class:"mini"},[`Hazard: ${s.hazard.toUpperCase()} · Reward x${s.rewardMultiplier}`]),b("div",{style:{display:"flex",gap:"8px",alignItems:"center",marginTop:"auto"}},[r?b("b",{style:{color:"#00ff9d",fontFamily:"JetBrains Mono"}},["UNLOCKED"]):b("b",{style:{color:a?"#ffb700":"#ff6b8a",fontFamily:"JetBrains Mono"}},[`${Ee(s.unlockCost)} CR`]),b("button",{class:"btn",style:{marginLeft:"auto"},onclick:()=>{if(!r){if(!e.unlockSector(s.id)){ve.error(),n.notify("Not enough credits to chart this sector.","error");return}ve.purchase(),n.notify(`${s.name} charted and unlocked.`,"success"),n.save(),n.refresh(),i();return}const c=e.ship.stats();if(c.thrust<=0){ve.error(),n.notify("Install at least one engine before launching.","error");return}c.miningDps<=0&&c.weaponDps<=0&&n.notify("Warning: no mining laser or weapon installed.","error"),n.launch(s)}},[r?"LAUNCH":"UNLOCK"])])]))}};return i(),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[b("div",{class:"panelHead"},[b("h2",{},["SECTOR MAP"]),b("span",{class:"mini"},["Deeper sectors pay more but field heavier opposition."])]),t])}function Yv(n){const{state:e}=n,t=b("div",{style:{overflow:"auto",padding:"16px",display:"flex",flexDirection:"column",gap:"16px"}}),i=()=>{St(t);const s=e.stats,r=(l,c)=>b("div",{class:"kpiCard"},[b("div",{class:"mini"},[l]),b("b",{style:{fontSize:"18px"}},[c])]);t.appendChild(b("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:"12px"}},[r("ASTEROIDS MINED",Ee(s.asteroidsMined)),r("ENEMIES DESTROYED",Ee(s.enemiesKilled)),r("ORE COLLECTED",Ee(s.oreCollected)),r("CREDITS EARNED",Ee(s.creditsEarned)),r("CRYSTALS EARNED",Ee(s.crystalsEarned)),r("EXPEDITIONS",Ee(s.expeditions)),r("DISTANCE FLOWN",Ee(s.distance)),r("PACKS OPENED",Ee(s.packsOpened)),r("RARE FINDS",Ee(s.rareFinds)),r("DAMAGE DEALT",Ee(s.damageDealt)),r("CREW COLLECTED",`${e.crew.size}/${ui.length}`),r("SHIP MODULES",Ee(e.ship.modules.length)),r("EXPANSION CELLS",Ee(e.ship.purchasedCount)),r("SECTORS UNLOCKED",`${e.unlockedSectors.size}/5`)]));const a=Object.entries(e.ore).filter(([,l])=>l>0),o=a.reduce((l,[c,h])=>l+h*yt[c].value,0);t.appendChild(b("div",{class:"kpiCard"},[b("div",{style:{display:"flex",alignItems:"center",gap:"10px",marginBottom:"8px"}},[b("b",{style:{fontFamily:"Orbitron",fontSize:"12px"}},["ORE SILO"]),b("span",{class:"mini"},[`Market value ${Ee(o)} CR`]),b("button",{class:"btn small",style:{marginLeft:"auto"},onclick:()=>{if(o<=0){ve.error();return}e.addCredits(o),e.ore={},ve.purchase(),n.notify(`Sold the entire silo for ${Ee(o)} credits.`,"success"),n.save(),n.refresh(),i()}},["SELL ALL"])]),b("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:"8px"}},a.length?a.map(([l,c])=>b("div",{style:{padding:"8px",borderRadius:"10px",background:"rgba(255,255,255,0.04)"}},[b("div",{style:{fontSize:"11px",color:`#${yt[l].color.toString(16).padStart(6,"0")}`}},[yt[l].name]),b("div",{class:"mini"},[`${Ee(c)} units · ${Ee(c*yt[l].value)} CR`])])):[b("div",{class:"mini"},["Silo empty - fly an expedition and bring ore home."])])]))};return i(),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[b("div",{class:"panelHead"},[b("h2",{},["LOGBOOK"]),b("span",{class:"mini"},["Career statistics and hangar storage."])]),t])}function jv(n){const{state:e}=n,t=b("div",{style:{overflow:"auto",padding:"16px",display:"flex",flexDirection:"column",gap:"14px",maxWidth:"620px"}}),i=(r,a,o,l,c,h)=>{const u=b("b",{style:{fontFamily:"JetBrains Mono",minWidth:"48px",textAlign:"right"}},[a.toFixed(2)]);return b("div",{class:"kpiCard"},[b("div",{style:{display:"flex",alignItems:"center",gap:"12px"}},[b("span",{style:{fontSize:"12px",flex:"1"}},[r]),u]),b("input",{type:"range",min:String(o),max:String(l),step:String(c),value:String(a),style:{width:"100%",marginTop:"8px"},oninput:d=>{const f=Number(d.target.value);u.textContent=f.toFixed(2),h(f)}})])},s=(r,a,o)=>{const l=b("button",{class:a?"btn small":"btn ghost small"},[a?"ON":"OFF"]);return l.addEventListener("click",()=>{const c=l.textContent==="OFF";l.textContent=c?"ON":"OFF",l.className=c?"btn small":"btn ghost small",o(c),ve.uiClick()}),b("div",{class:"kpiCard",style:{display:"flex",alignItems:"center",gap:"12px"}},[b("span",{style:{fontSize:"12px",flex:"1"}},[r]),l])};return t.append(i("Music volume",e.settings.musicVolume,0,1,.05,r=>{e.settings.musicVolume=r,ve.setVolumes(r,e.settings.sfxVolume),n.save()}),i("Effects volume",e.settings.sfxVolume,0,1,.05,r=>{e.settings.sfxVolume=r,ve.setVolumes(e.settings.musicVolume,r),n.save()}),i("Camera sensitivity",e.settings.cameraSensitivity,.3,2.5,.1,r=>{e.settings.cameraSensitivity=r,n.save()}),s("Invert vertical axis",e.settings.invertY,r=>{e.settings.invertY=r,n.save()}),s("Reduced motion (shorter animations)",e.settings.reducedMotion,r=>{e.settings.reducedMotion=r,n.save()}),s("Skip pack opening animation",e.settings.skipPackAnimation,r=>{e.settings.skipPackAnimation=r,n.save()}),b("div",{class:"kpiCard"},[b("div",{style:{display:"flex",alignItems:"center",gap:"12px"}},[b("span",{style:{fontSize:"12px",flex:"1"}},["Graphics preset"]),...["low","medium","high"].map(r=>b("button",{class:e.settings.quality===r?"btn small":"btn ghost small",onclick:()=>{e.settings.quality=r,n.save(),n.notify("Graphics preset applied - reload the hangar for full effect.","info"),n.refresh()}},[r.toUpperCase()]))])]),b("div",{class:"kpiCard"},[b("div",{class:"mini",style:{marginBottom:"8px"}},["Save data"]),b("div",{style:{display:"flex",gap:"8px",flexWrap:"wrap"}},[b("button",{class:"btn small",onclick:()=>{n.save(),n.notify("Progress saved.","success")}},["SAVE NOW"]),b("button",{class:"btn ghost small",onclick:async()=>{await n.shell.confirm("Reset campaign?","This permanently deletes your ship, crew, cards and progress.","DELETE SAVE")&&(localStorage.removeItem("spaceminer.save.v3"),location.reload())}},["RESET CAMPAIGN"])])]),b("div",{class:"mini",style:{lineHeight:"1.6",opacity:"0.7"}},["Controls — Hangar: drag to orbit, wheel to zoom, click stations to open terminals. ","Builder: select a module, R to rotate, click a cell to place, click an installed module to remove. ","Flight: W/S thrust, A/D strafe, Space/C vertical, Q/E roll, X brake, Shift boost, mouse to steer, ","left mouse to fire weapons, right mouse to fire mining lasers, Escape to return to the hangar."])),b("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},[b("div",{class:"panelHead"},[b("h2",{},["SETTINGS"])]),t])}const fs=document.getElementById("app");function Kv(){const n=b("i",{style:{width:"0%"}}),e=b("div",{class:"mini",style:{marginTop:"10px",letterSpacing:"0.14em"}},["INITIALISING"]),t=b("div",{style:{position:"absolute",inset:"0",zIndex:"999",display:"grid",placeItems:"center",background:"radial-gradient(900px 600px at 50% 35%, #122050, #02040f 70%)"}},[b("div",{style:{textAlign:"center",width:"min(520px, 86vw)"}},[b("div",{style:{fontFamily:"Orbitron",fontWeight:"900",fontSize:"28px",letterSpacing:"0.14em",textShadow:"0 0 24px rgba(0,229,255,0.7)"}},["SPACE MINER"]),b("div",{style:{fontFamily:"Orbitron",fontSize:"13px",letterSpacing:"0.42em",color:"#7b61ff",marginTop:"6px"}},["BUILD & CONQUER"]),b("div",{class:"progress",style:{marginTop:"26px",height:"8px"}},[n]),e])]);return fs.appendChild(t),{setProgress:(i,s)=>{n.style.width=`${Math.round(i*100)}%`,e.textContent=s},done:()=>{t.animate([{opacity:1},{opacity:0}],{duration:520,easing:"ease-out"}).onfinish=()=>t.remove()}}}const ei=Kv();async function Ni(){return new Promise(n=>requestAnimationFrame(()=>n()))}async function Jv(){ei.setProgress(.08,"LOADING SAVE DATA"),await Ni();const n=ri.load();ei.setProgress(.2,"STARTING RENDERER"),await Ni();const e=new Ig(fs,n.settings.quality),t=new Dg(e.canvas);ei.setProgress(.34,"FORGING HANGAR GEOMETRY"),await Ni();const i=new dv(n,t,e.canvas,n.settings.quality);e.setScene(i.scene,i.camera),ei.setProgress(.62,"SYNTHESISING TEXTURES"),await Ni(),ei.setProgress(.78,"BUILDING INTERFACE"),await Ni();const s=new Sv(fs,n);let r=null,a=null,o=null;const l=()=>{n.save()},c=(y,S="info")=>s.toast(y,S),h=()=>s.refreshCurrencies(),u={state:n,shell:s,hangar:i,save:l,refresh:h,notify:c,launch:y=>f(y)};i.onNotify=c,i.onStationClick=y=>{const S={builder:"builder",shop:"shop",crew:"crew",packs:"packs",upgrades:"upgrades",missions:"achievements",launch:"sectors"};s.navigate(S[y]??"hangar")};const d={hangar:()=>bv(u),builder:()=>Ev(u),shop:()=>Av(u),crew:()=>Fv(u),packs:()=>Hv(u),achievements:()=>Wv(u),upgrades:()=>Xv(u),sectors:()=>qv(u),stats:()=>Yv(u),settings:()=>jv(u)};s.onNavigate=y=>{if(a)return;r&&r.dispose&&r.dispose();const S=y==="hangar"||y==="builder";s.setPanelTransparent(S),y!=="builder"&&i.setMode("view");const D=d[y]();r=D,s.setPanel(D),h()};function f(y){a||(s.layer.style.display="none",i.playLaunchSequence(()=>{a=new _v(n,t,y,n.settings.quality),a.onNotify=c,a.start(),e.setScene(a.scene,a.camera),o=new xv(n,()=>g(!1)),fs.appendChild(o.root),o.root.appendChild(s.toastStack),c(`Arrived in ${y.name}. Right mouse to mine, left mouse to fire.`,"success")}))}function g(y){if(!a)return;const S=a.complete(y);v(S),a.dispose(),a=null,o==null||o.root.remove(),o=null,s.layer.appendChild(s.toastStack),s.layer.style.display="",e.setScene(i.scene,i.camera),i.rebuildShip(),s.navigate("hangar"),p(S)}function v(y){n.addCredits(y.credits);for(const[S,D]of Object.entries(y.ore))n.ore[S]=(n.ore[S]??0)+D;n.stats.expeditions+=1,n.stats.asteroidsMined+=y.asteroidsMined,n.stats.enemiesKilled+=y.enemiesKilled,n.stats.oreCollected+=y.oreUnits,n.stats.distance+=y.distance,n.stats.rareFinds+=y.rareFinds,n.stats.damageDealt+=y.damageDealt,n.stats.deepestSector=Math.max(n.stats.deepestSector,y.sector.index),n.trackStat("expeditions",1),n.trackStat("asteroidsMined",y.asteroidsMined),n.trackStat("enemiesKilled",y.enemiesKilled),n.trackStat("oreCollected",y.oreUnits),n.trackStat("chunksCollected",y.chunks),n.trackStat("distance",y.distance),n.trackStat("damageDealt",y.damageDealt),n.trackStat("rareFinds",y.rareFinds),n.trackStat("shieldAbsorbed",y.shieldAbsorbed),!y.failed&&nv(n.fifthSlotUnlocked,Math.random())&&(n.fifthSlotUnlocked=!0,y.fifthSlotUnlocked=!0,c("RARE REWARD: fifth active upgrade slot unlocked!","success"),ve.achievement()),l(),h()}function p(y){const S=Object.entries(y.ore).map(([X,L])=>b("div",{style:{display:"flex",justifyContent:"space-between"}},[b("span",{class:"mini",style:{color:`#${yt[X].color.toString(16).padStart(6,"0")}`}},[yt[X].name]),b("b",{class:"mini"},[`${Ee(L)} · ${Ee(L*yt[X].value)} CR`])])),D=b("div",{class:"modal",style:{width:"min(620px,94vw)",padding:"20px"}},[b("h2",{style:{fontFamily:"Orbitron",fontSize:"16px",letterSpacing:"0.1em",marginBottom:"4px",color:y.failed?"#ff6b8a":"#00ff9d"}},[y.failed?"EMERGENCY EXTRACTION":"EXPEDITION COMPLETE"]),b("div",{class:"mini",style:{marginBottom:"14px"}},[`${y.sector.name} · ${Math.round(y.duration)}s in the field`]),b("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:"10px",marginBottom:"14px"}},[b("div",{class:"kpiCard"},[b("div",{class:"mini"},["CREDITS EARNED"]),b("b",{},[Ee(y.credits)])]),b("div",{class:"kpiCard"},[b("div",{class:"mini"},["ORE DELIVERED"]),b("b",{},[Ee(y.oreUnits)])]),b("div",{class:"kpiCard"},[b("div",{class:"mini"},["ASTEROIDS MINED"]),b("b",{},[Ee(y.asteroidsMined)])]),b("div",{class:"kpiCard"},[b("div",{class:"mini"},["HOSTILES DESTROYED"]),b("b",{},[Ee(y.enemiesKilled)])]),b("div",{class:"kpiCard"},[b("div",{class:"mini"},["RARE FINDS"]),b("b",{},[Ee(y.rareFinds)])]),b("div",{class:"kpiCard"},[b("div",{class:"mini"},["DISTANCE"]),b("b",{},[Ee(y.distance)])])]),S.length?b("div",{class:"kpiCard",style:{marginBottom:"14px"}},[b("div",{class:"mini",style:{marginBottom:"6px"}},["CARGO DELIVERED TO SILO"]),...S]):null,y.fifthSlotUnlocked?b("div",{class:"kpiCard",style:{marginBottom:"14px",borderColor:"rgba(255,183,0,0.6)",background:"rgba(255,183,0,0.1)"}},[b("b",{style:{color:"#ffb700"}},["RARE CARD REWARD"]),b("div",{class:"mini"},[`Fifth active upgrade slot unlocked (${(oo*100).toFixed(0)}% chance).`])]):null,b("div",{style:{display:"flex",justifyContent:"flex-end",gap:"10px"}},[b("button",{class:"btn ghost",onclick:()=>{F(),s.navigate("shop")}},["SPEND CREDITS"]),b("button",{class:"btn",onclick:()=>F()},["CONTINUE"])])]),F=s.modal(D)}let m=performance.now(),M=0;e.onFrame(y=>{a?(a.update(y),o==null||o.update(a.hud),t.down("Escape")&&g(!1),M+=y,M>1&&(M=0,n.achievements.refresh(Date.now(),n.tier))):i.update(y),t.endFrame(),n.stats.playTimeMs+=y*1e3,performance.now()-m>2e4&&(m=performance.now(),l())});let _=0,x=0,P=0,w=0;setInterval(()=>{if(!a)return;const y=a.hud;y.asteroidsMined>_&&(n.trackStat("asteroidsMined",y.asteroidsMined-_),_=y.asteroidsMined),y.enemiesKilled>x&&(n.trackStat("enemiesKilled",y.enemiesKilled-x),x=y.enemiesKilled);const S=Object.values(y.ore).reduce((F,X)=>F+X,0);S>P&&(n.trackStat("oreCollected",S-P),n.trackStat("chunksCollected",1),P=S);const D=Math.round(y.elapsed*y.speed*.1);D>w&&(n.trackStat("distance",D-w),w=D)},500);const A=u.launch;u.launch=y=>{_=0,x=0,P=0,w=0,A(y)},n.achievements.onRotate=y=>{y!=="minute"&&c(`${y.toUpperCase()} objectives refreshed.`,"info")},n.achievements.refresh(Date.now(),n.tier),n.achievements.setStat("cardsOwned",n.crew.size),n.achievements.setStat("cellsPurchased",n.ship.purchasedCount);const N=()=>{ve.init(),ve.setVolumes(n.settings.musicVolume,n.settings.sfxVolume),window.removeEventListener("pointerdown",N),window.removeEventListener("keydown",N)};if(window.addEventListener("pointerdown",N),window.addEventListener("keydown",N),window.addEventListener("beforeunload",()=>l()),ei.setProgress(1,"READY"),await Ni(),e.start(),s.navigate("hangar"),ei.done(),n.loadWarning&&c(n.loadWarning,"error"),n.crew.size===0){const y=ui.find(S=>S.id==="c_driller");y&&(n.grantCard(y.id),c(`Welcome aboard: ${y.name} joined your roster.`,"success"),l())}window.SPACE_MINER={state:n,engine:e,hangar:i,get space(){return a},endExpedition:()=>g(!1),version:"1.0.0",three:Sr}}Jv().catch(n=>{console.error(n),fs.appendChild(b("div",{style:{position:"absolute",inset:"0",display:"grid",placeItems:"center",padding:"24px",background:"#05070f",color:"#ff6b8a",fontFamily:"JetBrains Mono, monospace",textAlign:"center"}},[`Startup failure: ${String(n)}`]))});
